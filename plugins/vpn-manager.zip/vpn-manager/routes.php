<?php

/** @var \FBL\Router $router */

$router->get('/my-vpn', static function (): string {
    $user = get_user();
    $userId = is_array($user) ? (int)($user['id'] ?? 0) : 0;
    $repo = FireballPluginVpnManager::repository();

    return plugin_view('vpn-manager', 'my-vpn', FireballPluginVpnManager::viewData('dashboard', [
        'title' => FireballPluginVpnManager::t('vpn_manager_my_vpn_title'),
        'subscriptions' => $repo->mySubscriptions($userId),
    ]));
})->middleware(['auth']);

$router->get('/vpn/subscription/(?P<token>[a-zA-Z0-9._-]+)/?', static function (): string {
    $token = (string)get_route_param('token');
    $repo = FireballPluginVpnManager::repository();
    $subscription = $repo->subscriptionByToken($token);
    if (!$subscription) {
        response()->setResponseCode(404);

        return 'VPN subscription not found.';
    }

    $nodes = $repo->subscriptionNodes((int)$subscription['id']);
    $activeNodes = array_filter($nodes, static fn(array $node): bool => (string)($node['status'] ?? '') === 'active' && trim((string)($node['remote_client_id'] ?? '')) !== '');
    if (!$activeNodes) {
        return 'VPN subscription is not ready yet.';
    }

    return 'VPN subscription delivery is prepared for active clients.';
});
