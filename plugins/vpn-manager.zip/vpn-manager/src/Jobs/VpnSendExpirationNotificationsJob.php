<?php

namespace Fireball\VpnManager\Jobs;

use Fireball\VpnManager\Services\NotificationScheduler;

final class VpnSendExpirationNotificationsJob
{
    public function handle(): array
    {
        $scheduler = new NotificationScheduler();
        $queued = $scheduler->queueExpirationNotifications();
        $sent = $scheduler->sendPending(['expires_3_days', 'expires_today', 'subscription_expired', 'manual_reminder']);

        return array_merge(['queued' => (int)($queued['created'] ?? 0)], $sent);
    }
}
