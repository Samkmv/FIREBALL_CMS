<?php

namespace Fireball\VpnManager\Jobs;

use Fireball\VpnManager\Services\SubscriptionAutomationService;

final class VpnCheckExpirationsJob
{
    public function handle(): array
    {
        return (new SubscriptionAutomationService())->expireDueSubscriptions();
    }
}
