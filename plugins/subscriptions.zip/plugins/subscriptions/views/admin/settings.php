<?php require __DIR__ . '/shell-open.php'; ?>
    <form class="border rounded-4 p-4 p-lg-5" method="post" action="<?= htmlSC(base_href('/admin/subscriptions/settings/save')) ?>" autocomplete="off" data-subscriptions-settings-form>
        <?= get_csrf_field() ?>
        <div class="alert alert-info"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_settings_urls_hint')) ?></div>
        <?php $gatewayReady = trim((string)$settings['merchant_login']) !== '' && !empty($settings['password1_configured']) && !empty($settings['password2_configured']); ?>
        <div class="alert <?= $gatewayReady ? 'alert-success' : 'alert-danger' ?>" role="status">
            <?= htmlSC(FireballPluginSubscriptions::t($gatewayReady ? 'subscriptions_settings_credentials_ready' : 'subscriptions_settings_credentials_missing')) ?>
            <?php if ($gatewayReady): ?>
                <div class="small mt-2">
                    <?= htmlSC(FireballPluginSubscriptions::t(!empty($settings['test_mode']) ? 'subscriptions_payment_mode_test' : 'subscriptions_payment_mode_live')) ?>
                    · <?= htmlSC(FireballPluginSubscriptions::t('subscriptions_hash_algorithm')) ?>: <?= htmlSC(strtoupper((string)$settings['hash_algorithm'])) ?>
                    · IsTest=<?= !empty($settings['test_mode']) ? '1' : '0' ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_merchant_login')) ?></label><input class="form-control" name="merchant_login" value="<?= htmlSC((string)$settings['merchant_login']) ?>" required></div>
            <div class="col-md-3"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_hash_algorithm')) ?></label><select class="form-select" name="hash_algorithm"><?php foreach (['md5', 'ripemd160', 'sha1', 'sha256', 'sha384', 'sha512'] as $algorithm): ?><option value="<?= $algorithm ?>" <?= $settings['hash_algorithm'] === $algorithm ? 'selected' : '' ?>><?= strtoupper($algorithm) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-3"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_field_currency')) ?></label><input class="form-control" name="currency" maxlength="3" value="<?= htmlSC((string)$settings['currency']) ?>"></div>
            <div class="col-md-6"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_password1')) ?></label><input class="form-control" type="password" name="password1" value="" autocomplete="new-password" placeholder="<?= $settings['password1_configured'] ? '••••••••' : '' ?>" <?= $settings['password1_configured'] ? '' : 'required' ?>><div class="form-text"><?= htmlSC(FireballPluginSubscriptions::t($settings['password1_configured'] ? 'subscriptions_secret_hint' : 'subscriptions_secret_required_hint')) ?></div></div>
            <div class="col-md-6"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_password2')) ?></label><input class="form-control" type="password" name="password2" value="" autocomplete="new-password" placeholder="<?= $settings['password2_configured'] ? '••••••••' : '' ?>" <?= $settings['password2_configured'] ? '' : 'required' ?>><div class="form-text"><?= htmlSC(FireballPluginSubscriptions::t($settings['password2_configured'] ? 'subscriptions_secret_hint' : 'subscriptions_secret_required_hint')) ?></div></div>
            <div class="col-md-4"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_payment_timeout')) ?></label><input class="form-control" type="number" name="payment_timeout_minutes" min="5" value="<?= (int)$settings['payment_timeout_minutes'] ?>"></div>
            <div class="col-md-4"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_media_ttl')) ?></label><input class="form-control" type="number" name="media_token_ttl" min="60" max="1800" value="<?= (int)$settings['media_token_ttl'] ?>"></div>
        </div>
        <div class="row g-3 mt-2">
            <?php foreach ([['test_mode', 'subscriptions_test_mode'], ['recurring_enabled', 'subscriptions_recurring_enabled'], ['receipt_enabled', 'subscriptions_receipt_enabled']] as [$key, $label]): ?><div class="col-md-4"><label class="form-check"><input class="form-check-input" type="checkbox" name="<?= $key ?>" value="1" <?= !empty($settings[$key]) ? 'checked' : '' ?>><span class="form-check-label"><?= htmlSC(FireballPluginSubscriptions::t($label)) ?></span></label></div><?php endforeach; ?>
        </div>
        <div class="row g-3 mt-2">
            <?php $taxLabels = ['none' => 'subscriptions_receipt_tax_none', 'vat0' => 'subscriptions_receipt_tax_vat0', 'vat5' => 'subscriptions_receipt_tax_vat5', 'vat7' => 'subscriptions_receipt_tax_vat7', 'vat10' => 'subscriptions_receipt_tax_vat10', 'vat20' => 'subscriptions_receipt_tax_vat20']; ?>
            <?php $methodLabels = ['full_payment' => 'subscriptions_receipt_method_full_payment', 'prepayment' => 'subscriptions_receipt_method_prepayment', 'prepayment_full' => 'subscriptions_receipt_method_prepayment_full', 'advance' => 'subscriptions_receipt_method_advance']; ?>
            <?php $objectLabels = ['service' => 'subscriptions_receipt_object_service', 'commodity' => 'subscriptions_receipt_object_commodity', 'payment' => 'subscriptions_receipt_object_payment', 'another' => 'subscriptions_receipt_object_another']; ?>
            <div class="col-md-4"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_receipt_tax')) ?></label><select class="form-select" name="receipt_tax"><?php foreach ($taxLabels as $item => $label): ?><option value="<?= $item ?>" <?= $settings['receipt_tax'] === $item ? 'selected' : '' ?>><?= htmlSC(FireballPluginSubscriptions::t($label)) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-4"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_receipt_method')) ?></label><select class="form-select" name="receipt_payment_method"><?php foreach ($methodLabels as $item => $label): ?><option value="<?= $item ?>" <?= $settings['receipt_payment_method'] === $item ? 'selected' : '' ?>><?= htmlSC(FireballPluginSubscriptions::t($label)) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-4"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_receipt_object')) ?></label><select class="form-select" name="receipt_payment_object"><?php foreach ($objectLabels as $item => $label): ?><option value="<?= $item ?>" <?= $settings['receipt_payment_object'] === $item ? 'selected' : '' ?>><?= htmlSC(FireballPluginSubscriptions::t($label)) ?></option><?php endforeach; ?></select></div>
        </div>
        <hr class="my-4">
        <?php foreach (['result_url' => 'subscriptions_result_url', 'success_url' => 'subscriptions_success_url', 'fail_url' => 'subscriptions_fail_url'] as $key => $label): ?><div class="mb-3"><label class="form-label"><?= htmlSC(FireballPluginSubscriptions::t($label)) ?></label><input class="form-control font-monospace" value="<?= htmlSC((string)$settings[$key]) ?>" readonly></div><?php endforeach; ?>
        <button class="btn btn-dark rounded-pill" type="submit" name="save_robokassa_settings" value="1"><?= htmlSC(FireballPluginSubscriptions::t('subscriptions_save')) ?></button>
    </form>
<?php require __DIR__ . '/shell-close.php'; ?>
