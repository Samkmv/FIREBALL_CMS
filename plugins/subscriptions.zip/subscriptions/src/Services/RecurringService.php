<?php

namespace Fireball\Subscriptions\Services;

use Fireball\Subscriptions\Payments\RobokassaGateway;
use Fireball\Subscriptions\Repositories\PlanRepository;
use Fireball\Subscriptions\Repositories\ProfileRepository;

final class RecurringService
{
    public function processDue(int $limit = 25): array
    {
        $limit = max(1, min(100, $limit));
        $rows = db()->query(
            "SELECT id FROM subscriptions
             WHERE archived_at IS NULL
               AND auto_renew = 1
               AND status IN ('active', 'grace_period', 'past_due')
               AND next_billing_at IS NOT NULL
               AND next_billing_at <= NOW()
             ORDER BY next_billing_at ASC, id ASC LIMIT {$limit}"
        )->get() ?: [];
        $result = ['initiated' => 0, 'failed' => 0];
        foreach ($rows as $row) {
            try {
                if ($this->initiate((int)$row['id'])) {
                    $result['initiated']++;
                }
            } catch (\Throwable $exception) {
                $result['failed']++;
                log_error_details('Subscription recurring payment failed', ['subscription_id' => (int)$row['id']], $exception);
            }
        }

        return $result;
    }

    public function initiate(int $subscriptionId): bool
    {
        $preflight = db()->query('SELECT id, user_id, status, auto_renew, next_billing_at, archived_at FROM subscriptions WHERE id = ? LIMIT 1', [$subscriptionId])->getOne();
        if (!$preflight || !empty($preflight['archived_at']) || empty($preflight['auto_renew']) || empty($preflight['next_billing_at'])
            || !in_array($preflight['status'], ['active', 'grace_period', 'past_due'], true)) {
            return false;
        }
        try {
            (new SubscriptionEligibilityService())->assertEligible((int)$preflight['user_id'], 'recurring_preflight');
        } catch (\DomainException) {
            $this->blockRenewalForAddress($preflight);

            return false;
        }

        $subscription = $preflight;
        db()->beginTransaction();
        try {
            $subscription = db()->query('SELECT * FROM subscriptions WHERE id = ? LIMIT 1 FOR UPDATE', [$subscriptionId])->getOne();
            if (!$subscription || !empty($subscription['archived_at']) || empty($subscription['auto_renew']) || empty($subscription['next_billing_at'])
                || !in_array($subscription['status'], ['active', 'grace_period', 'past_due'], true) || strtotime((string)$subscription['next_billing_at']) > time()) {
                db()->commit();
                return false;
            }
            $periodStart = (string)$subscription['next_billing_at'];
            $existing = db()->query(
                "SELECT id, status, failed_at, provider_transaction FROM subscription_payments WHERE subscription_id = ? AND payment_type = 'recurring' AND billing_period_start = ? LIMIT 1",
                [$subscriptionId, $periodStart]
            )->getOne();
            if ($existing) {
                db()->commit();

                $retryAt = !empty($existing['failed_at'])
                    ? strtotime((string)$existing['failed_at']) + 1800
                    : PHP_INT_MAX;

                if ((string)$existing['status'] === 'failed'
                    && empty($existing['provider_transaction'])
                    && $retryAt <= time()) {
                    return $this->retryFailedAttempt((int)$existing['id'], $subscription);
                }

                return false;
            }
            $plans = new PlanRepository();
            $plan = $plans->find((int)$subscription['plan_id']);
            $parent = db()->query("SELECT * FROM subscription_payments WHERE id = ? AND status = 'paid' LIMIT 1", [(int)$subscription['parent_payment_id']])->getOne();
            if (!$plan || !$parent) {
                throw new \RuntimeException('A paid parent payment is required for recurring billing.');
            }
            $parentOrder = db()->query('SELECT * FROM subscription_orders WHERE id = ? LIMIT 1', [(int)$parent['order_id']])->getOne();
            try {
                $snapshot = (new ProfileRepository())->snapshot((int)$subscription['user_id'], (int)$subscription['plan_id']);
                $snapshotJson = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            } catch (\Throwable) {
                $snapshotJson = (string)($parentOrder['customer_snapshot'] ?? '{}');
            }
            (new SubscriptionEligibilityService())->assertEligible((int)$subscription['user_id'], 'recurring_before_order');
            $invoiceId = $this->uniqueInvoiceId();
            $now = date('Y-m-d H:i:s');
            $renewalPlanSnapshot = $plans->purchaseSnapshot($plan);
            $renewalPlanSnapshot['auto_renew_enabled'] = !empty($subscription['auto_renew']);
            $renewalPlanSnapshot['is_recurring'] = !empty($subscription['auto_renew']);
            db()->query(
                "INSERT INTO subscription_orders (invoice_id, user_id, plan_id, subscription_id, amount_minor, currency, plan_snapshot, customer_snapshot, consent_snapshot, status, expires_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)",
                [
                    $invoiceId, (int)$subscription['user_id'], (int)$subscription['plan_id'], $subscriptionId,
                    (int)$plan['price_minor'], (string)$plan['currency'],
                    json_encode($renewalPlanSnapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    $snapshotJson,
                    (string)($parentOrder['consent_snapshot'] ?? '{}'), date('Y-m-d H:i:s', time() + 86400), $now, $now,
                ]
            );
            $orderId = (int)db()->getInsertId();
            db()->query(
                "INSERT INTO subscription_payments (order_id, subscription_id, user_id, plan_id, provider, invoice_id, parent_payment_id, parent_invoice_id, amount_minor, currency, status, payment_type, billing_period_start, created_at, updated_at) VALUES (?, ?, ?, ?, 'robokassa', ?, ?, ?, ?, ?, 'pending', 'recurring', ?, ?, ?)",
                [
                    $orderId, $subscriptionId, (int)$subscription['user_id'], (int)$subscription['plan_id'],
                    $invoiceId, (int)$parent['id'], (int)$parent['invoice_id'], (int)$plan['price_minor'], (string)$plan['currency'],
                    $periodStart, $now, $now,
                ]
            );
            $paymentId = (int)db()->getInsertId();
            db()->commit();
        } catch (\Throwable $exception) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            if ($exception instanceof \DomainException
                && $exception->getMessage() === \FireballPluginSubscriptions::t('subscriptions_address_included_in_utilities')) {
                $this->blockRenewalForAddress($subscription ?: $preflight);

                return false;
            }
            throw $exception;
        }

        $order = db()->query('SELECT * FROM subscription_orders WHERE id = ?', [$orderId])->getOne() ?: [];
        try {
            $response = (new RobokassaGateway())->initiateRecurring($order, $plan, $parent);
            $graceDays = max(0, (int)$plan['grace_period_days']);
            $graceEnd = $graceDays > 0
                ? (new \DateTimeImmutable((string)$subscription['ends_at']))->add(new \DateInterval('P' . $graceDays . 'D'))->format('Y-m-d H:i:s')
                : null;
            $pendingStatus = $graceEnd !== null && strtotime($graceEnd) > time() ? 'grace_period' : 'past_due';
            if (!$this->persistAttemptResult($subscription, $plan, $paymentId, $orderId, $response)) return true;
            (new SubscriptionService())->event('payment.recurring_initiated', $subscriptionId, $paymentId, (int)$subscription['user_id'], null, 'pending', ['invoice_id' => $invoiceId]);
            return true;
        } catch (\Throwable $exception) {
            if ($exception instanceof \Fireball\Subscriptions\Support\RecurringCancelledException) {
                $now = date('Y-m-d H:i:s');
                db()->query("UPDATE subscription_payments SET status = 'cancelled', error_message = ?, updated_at = ? WHERE id = ? AND status <> 'paid'", ['Auto-renew disabled before dispatch', $now, $paymentId]);
                db()->query("UPDATE subscription_orders SET status = 'cancelled', updated_at = ? WHERE id = ? AND status <> 'paid'", [$now, $orderId]);
                (new SubscriptionService())->event('payment.recurring_cancelled', $subscriptionId, $paymentId, (int)$subscription['user_id'], 'pending', 'cancelled');
                return false;
            }
            if ($exception instanceof \DomainException
                && $exception->getMessage() === \FireballPluginSubscriptions::t('subscriptions_address_included_in_utilities')) {
                $this->markEligibilityBlocked($subscription, $paymentId, $orderId, $exception);
            } else {
                $this->markFailed($subscription, $plan, $paymentId, $orderId, $exception);
            }
            throw $exception;
        }
    }

    private function retryFailedAttempt(int $paymentId, array $subscription): bool
    {
        db()->beginTransaction();
        try {
            $payment = db()->query(
                "SELECT * FROM subscription_payments WHERE id = ? AND payment_type = 'recurring' LIMIT 1 FOR UPDATE",
                [$paymentId]
            )->getOne();
            if (!$payment || (string)$payment['status'] !== 'failed' || !empty($payment['provider_transaction'])) {
                db()->commit();
                return false;
            }

            $failedAt = !empty($payment['failed_at']) ? strtotime((string)$payment['failed_at']) : 0;
            if ($failedAt <= 0 || ($failedAt + 1800) > time()) {
                db()->commit();
                return false;
            }

            $failureCount = (int)db()->query(
                "SELECT COUNT(*) FROM subscription_events WHERE payment_id = ? AND event_key = 'payment.recurring_failed'",
                [$paymentId]
            )->getColumn();
            if ($failureCount >= 3) {
                db()->commit();
                return false;
            }

            $freshSubscription = db()->query(
                'SELECT * FROM subscriptions WHERE id = ? LIMIT 1 FOR UPDATE',
                [(int)$payment['subscription_id']]
            )->getOne();
            if (!$freshSubscription
                || !empty($freshSubscription['archived_at'])
                || empty($freshSubscription['auto_renew'])
                || empty($freshSubscription['next_billing_at'])
                || !in_array((string)$freshSubscription['status'], ['active', 'grace_period', 'past_due'], true)) {
                db()->commit();
                return false;
            }

            (new SubscriptionEligibilityService())->assertEligible(
                (int)$freshSubscription['user_id'],
                'recurring_retry'
            );

            $order = db()->query(
                'SELECT * FROM subscription_orders WHERE id = ? LIMIT 1 FOR UPDATE',
                [(int)$payment['order_id']]
            )->getOne();
            $plan = (new PlanRepository())->find((int)$freshSubscription['plan_id']);
            $parent = db()->query(
                "SELECT * FROM subscription_payments WHERE id = ? AND status = 'paid' LIMIT 1",
                [(int)$payment['parent_payment_id']]
            )->getOne();

            if ($order && in_array((string)$order['status'], ['paid', 'cancelled'], true)) {
                db()->commit();
                return false;
            }
            if (!$order || !$plan || !$parent) {
                throw new \RuntimeException('Recurring retry is missing its order, plan, or paid parent payment.');
            }

            $now = date('Y-m-d H:i:s');
            db()->query(
                "UPDATE subscription_payments
                 SET status = 'pending', error_message = NULL, failed_at = NULL, updated_at = ?
                 WHERE id = ? AND status = 'failed'",
                [$now, $paymentId]
            );
            db()->query(
                "UPDATE subscription_orders
                 SET status = 'pending', expires_at = ?, updated_at = ?
                 WHERE id = ? AND status <> 'paid'",
                [date('Y-m-d H:i:s', time() + 86400), $now, (int)$order['id']]
            );

            db()->commit();
            $subscription = $freshSubscription;
        } catch (\Throwable $exception) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }

            if ($exception instanceof \DomainException
                && $exception->getMessage() === \FireballPluginSubscriptions::t('subscriptions_address_included_in_utilities')) {
                $this->blockRenewalForAddress($subscription);
                return false;
            }

            throw $exception;
        }

        try {
            $response = (new RobokassaGateway())->initiateRecurring($order, $plan, $parent);
            $graceDays = max(0, (int)$plan['grace_period_days']);
            $graceEnd = $graceDays > 0
                ? (new \DateTimeImmutable((string)$subscription['ends_at']))
                    ->add(new \DateInterval('P' . $graceDays . 'D'))
                    ->format('Y-m-d H:i:s')
                : null;
            $pendingStatus = $graceEnd !== null && strtotime($graceEnd) > time()
                ? 'grace_period'
                : 'past_due';
            $now = date('Y-m-d H:i:s');

            if (!$this->persistAttemptResult($subscription, $plan, $paymentId, (int)$order['id'], $response)) return true;
            (new SubscriptionService())->event(
                'payment.recurring_retried',
                (int)$subscription['id'],
                $paymentId,
                (int)$subscription['user_id'],
                (string)$subscription['status'],
                $pendingStatus,
                ['invoice_id' => (int)$order['invoice_id']]
            );

            return true;
        } catch (\Throwable $exception) {
            if ($exception instanceof \Fireball\Subscriptions\Support\RecurringCancelledException) {
                $now = date('Y-m-d H:i:s');
                db()->query(
                    "UPDATE subscription_payments SET status = 'cancelled', error_message = ?, updated_at = ? WHERE id = ? AND status <> 'paid'",
                    ['Auto-renew disabled before retry dispatch', $now, $paymentId]
                );
                db()->query(
                    "UPDATE subscription_orders SET status = 'cancelled', updated_at = ? WHERE id = ? AND status <> 'paid'",
                    [$now, (int)$order['id']]
                );
                (new SubscriptionService())->event(
                    'payment.recurring_cancelled',
                    (int)$subscription['id'],
                    $paymentId,
                    (int)$subscription['user_id'],
                    (string)$subscription['status'],
                    'cancelled'
                );
                return false;
            }

            if ($exception instanceof \DomainException
                && $exception->getMessage() === \FireballPluginSubscriptions::t('subscriptions_address_included_in_utilities')) {
                $this->markEligibilityBlocked(
                    $subscription,
                    $paymentId,
                    (int)$order['id'],
                    $exception
                );
            } else {
                $this->markFailed(
                    $subscription,
                    $plan,
                    $paymentId,
                    (int)$order['id'],
                    $exception
                );
            }

            throw $exception;
        }
    }

    private function markEligibilityBlocked(array $subscription, int $paymentId, int $orderId, \Throwable $exception): void
    {
        $now = date('Y-m-d H:i:s');
        if (!$this->persistAttemptResult($subscription, [], $paymentId, $orderId, null, $exception, true)) return;
        (new SubscriptionService())->event(
            'subscription.auto_renew_blocked_by_address',
            (int)$subscription['id'],
            $paymentId,
            (int)$subscription['user_id'],
            (string)$subscription['status'],
            (string)$subscription['status'],
            ['reason' => SubscriptionEligibilityService::REASON_ADDRESS_INCLUDED_IN_UTILITIES]
        );
    }

    private function blockRenewalForAddress(array $subscription): void
    {
        $now = date('Y-m-d H:i:s');
        db()->query(
            'UPDATE subscriptions SET auto_renew = 0, next_billing_at = NULL, updated_at = ? WHERE id = ?',
            [$now, (int)$subscription['id']]
        );
        (new SubscriptionService())->event(
            'subscription.auto_renew_blocked_by_address',
            (int)$subscription['id'],
            null,
            (int)$subscription['user_id'],
            (string)$subscription['status'],
            (string)$subscription['status'],
            ['reason' => SubscriptionEligibilityService::REASON_ADDRESS_INCLUDED_IN_UTILITIES]
        );
    }

    private function markFailed(array $subscription, array $plan, int $paymentId, int $orderId, \Throwable $exception): void
    {
        $now = date('Y-m-d H:i:s');
        $graceDays = max(0, (int)$plan['grace_period_days']);
        $graceEnd = $graceDays > 0
            ? (new \DateTimeImmutable((string)$subscription['ends_at']))->add(new \DateInterval('P' . $graceDays . 'D'))->format('Y-m-d H:i:s')
            : null;
        $status = $graceEnd !== null && strtotime($graceEnd) > time() ? 'grace_period' : 'past_due';
        if (!$this->persistAttemptResult($subscription, $plan, $paymentId, $orderId, null, $exception)) return;
        (new SubscriptionService())->event('payment.recurring_failed', (int)$subscription['id'], $paymentId, (int)$subscription['user_id'], (string)$subscription['status'], $status, ['error_class' => get_class($exception)]);
        try {
            notification_create([
                'user_id' => (int)$subscription['user_id'],
                'title' => \FireballPluginSubscriptions::t('subscriptions_notification_recurring_failed_title'),
                'message' => \FireballPluginSubscriptions::t('subscriptions_notification_recurring_failed_message'),
                'type' => 'subscription',
                'action_url' => base_href('/account/subscription'),
                'icon' => 'ci-alert-triangle',
                'source' => 'subscriptions',
                'priority' => 'high',
                'metadata' => [
                    'subscription_id' => (int)$subscription['id'],
                    'subscription_notification' => 'recurring_failed',
                ],
            ]);
        } catch (\Throwable $notificationException) {
            log_error_details('Recurring failure notification failed', ['subscription_id' => (int)$subscription['id']], $notificationException);
        }
    }

    /** Lock in callback order; an older worker must never undo a paid result. */
    private function persistAttemptResult(array $subscription, array $plan, int $paymentId, int $orderId, ?string $response, ?\Throwable $error = null, bool $blocked = false): bool
    {
        $database = db();
        $database->beginTransaction();
        try {
            $payment = $database->query('SELECT * FROM subscription_payments WHERE id = ? LIMIT 1 FOR UPDATE', [$paymentId])->getOne();
            $order = $database->query('SELECT * FROM subscription_orders WHERE id = ? LIMIT 1 FOR UPDATE', [$orderId])->getOne();
            if (!$payment || !$order || $payment['status'] === 'paid' || $order['status'] === 'paid'
                || $payment['status'] === 'cancelled' || $order['status'] === 'cancelled') {
                $database->commit();
                return false;
            }
            $current = $database->query('SELECT * FROM subscriptions WHERE id = ? LIMIT 1 FOR UPDATE', [(int)$subscription['id']])->getOne();
            $now = date('Y-m-d H:i:s');
            if ($error === null) {
                $database->query("UPDATE subscription_payments SET status = 'pending', provider_transaction = ?, error_message = NULL, failed_at = NULL, updated_at = ? WHERE id = ? AND status <> 'paid'", [$response, $now, $paymentId]);
            } else {
                $database->query("UPDATE subscription_payments SET status = 'failed', error_message = ?, failed_at = ?, updated_at = ? WHERE id = ? AND status <> 'paid'", [mb_substr($error->getMessage(), 0, 2000), $now, $now, $paymentId]);
                $database->query("UPDATE subscription_orders SET status = 'failed', updated_at = ? WHERE id = ? AND status <> 'paid'", [$now, $orderId]);
            }
            // Another invoice may already have extended this subscription.
            if ($current && empty($current['archived_at']) && !empty($current['auto_renew'])
                && (string)($current['ends_at'] ?? '') === (string)($subscription['ends_at'] ?? '')) {
                if ($blocked) {
                    $database->query('UPDATE subscriptions SET auto_renew = 0, next_billing_at = NULL, updated_at = ? WHERE id = ?', [$now, (int)$subscription['id']]);
                } else {
                    $days = max(0, (int)($plan['grace_period_days'] ?? 0));
                    $graceEnd = $days > 0 && !empty($current['ends_at'])
                        ? (new \DateTimeImmutable((string)$current['ends_at']))->add(new \DateInterval('P' . $days . 'D'))->format('Y-m-d H:i:s') : null;
                    $status = $graceEnd !== null && strtotime($graceEnd) > time() ? 'grace_period' : 'past_due';
                    $database->query('UPDATE subscriptions SET status = ?, grace_ends_at = ?, updated_at = ? WHERE id = ? AND auto_renew = 1 AND archived_at IS NULL', [$status, $graceEnd, $now, (int)$subscription['id']]);
                }
            }
            $database->commit();
            return true;
        } catch (\Throwable $exception) {
            if ($database->inTransaction()) $database->rollBack();
            throw $exception;
        }
    }

    private function uniqueInvoiceId(): int
    {
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $invoiceId = random_int(100000, 2147483646);
            if (!db()->query('SELECT id FROM subscription_orders WHERE invoice_id = ? LIMIT 1', [$invoiceId])->getOne()) {
                return $invoiceId;
            }
        }
        throw new \RuntimeException('Could not allocate a recurring invoice ID.');
    }
}
