<?php

namespace Fireball\Subscriptions\Payments;

use Fireball\Subscriptions\Services\SettingsService;
use Fireball\Subscriptions\Support\Money;

final class RobokassaGateway implements PaymentGatewayInterface
{
    private const PAYMENT_URL = 'https://auth.robokassa.ru/Merchant/Index.aspx';
    private const RECURRING_URL = 'https://auth.robokassa.ru/Merchant/Recurring';

    public function __construct(private readonly SettingsService $settings = new SettingsService())
    {
    }

    public function checkoutUrl(array $order, array $plan, array $profile): string
    {
        (new \Fireball\Subscriptions\Services\SubscriptionEligibilityService())->assertEligible(
            (int)($order['user_id'] ?? 0),
            'gateway_checkout'
        );
        $config = $this->settings->assertGatewayReady();
        $invoiceId = (string)(int)$order['invoice_id'];
        $outSum = Money::decimal((int)$order['amount_minor']);

        $params = [
            'MerchantLogin' => $config['merchant_login'],
            'OutSum' => $outSum,
            'InvId' => $invoiceId,
            'Description' => mb_substr((string)$plan['name'], 0, 100),
            'Culture' => $this->culture(),
            'Encoding' => 'utf-8',
            'Email' => (string)$profile['email'],
            'IsTest' => !empty($config['test_mode']) ? '1' : '0',
        ];

        $signatureParts = [$config['merchant_login'], $outSum, $invoiceId];
        if (!empty($config['receipt_enabled'])) {
            $receipt = rawurlencode($this->receipt($plan, $order, $config));
            $params['Receipt'] = $receipt;
            $signatureParts[] = $receipt;
        }
        $signatureParts[] = $config['password1'];

        $params['SignatureValue'] = $this->hash(implode(':', $signatureParts), $config['hash_algorithm']);

        $consents = json_decode((string)($order['consent_snapshot'] ?? ''), true);
        $autoRenewRequired = !empty($plan['auto_renew_enabled'] ?? $plan['is_recurring'] ?? false);

        if ($autoRenewRequired) {
            if (!is_array($consents) || empty($consents['recurring']) || empty($consents['auto_renew'])) {
                throw new \RuntimeException(
                    \FireballPluginSubscriptions::t('subscriptions_error_recurring_consent')
                );
            }

            // Never silently downgrade an auto-renewing tariff to a one-time payment.
            $params['Recurring'] = 'true';

            // Robokassa recurring charges require the parent payment to be completed by bank card.
            $params['IncCurrLabel'] = 'BankCard';
        }

        return self::PAYMENT_URL . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }

    public function verifyResult(array $payload): bool
    {
        $config = $this->settings->assertGatewayReady();

        return $this->verifyCallback($payload, (string)$config['password2'], (string)$config['hash_algorithm']);
    }

    public function verifySuccess(array $payload): bool
    {
        $config = $this->settings->assertGatewayReady();

        return $this->verifyCallback($payload, (string)$config['password1'], (string)$config['hash_algorithm']);
    }

    public function expectedResultResponse(int|string $invoiceId): string
    {
        return 'OK' . (int)$invoiceId;
    }

    public function initiateRecurring(array $order, array $plan, array $parentPayment): string
    {
        db()->beginTransaction();
        try {
            $subscription = db()->query(
                'SELECT * FROM subscriptions WHERE id = ? AND user_id = ? AND plan_id = ? LIMIT 1 FOR UPDATE',
                [(int)($order['subscription_id'] ?? 0), (int)($order['user_id'] ?? 0), (int)($order['plan_id'] ?? 0)]
            )->getOne();
            if (!$subscription || !empty($subscription['archived_at']) || empty($subscription['auto_renew'])
                || empty($subscription['next_billing_at']) || !in_array($subscription['status'], ['active', 'grace_period', 'past_due'], true)) {
                throw new \Fireball\Subscriptions\Support\RecurringCancelledException('Automatic renewal is no longer enabled.');
            }
            // Serialize the final dispatch with opt-out: cancellation wins if it acquired this lock first.
            $response = $this->sendRecurring($order, $plan, $parentPayment);
            db()->commit();
            return $response;
        } catch (\Throwable $exception) {
            if (db()->inTransaction()) db()->rollBack();
            throw $exception;
        }
    }

    private function sendRecurring(array $order, array $plan, array $parentPayment): string
    {
        (new \Fireball\Subscriptions\Services\SubscriptionEligibilityService())->assertEligible(
            (int)($order['user_id'] ?? 0),
            'gateway_recurring'
        );
        $config = $this->settings->assertGatewayReady();
        $invoiceId = (string)(int)$order['invoice_id'];
        $outSum = Money::decimal((int)$order['amount_minor']);

        $signatureParts = [
            $config['merchant_login'],
            $outSum,
            $invoiceId,
        ];

        $params = [
            'MerchantLogin' => $config['merchant_login'],
            'OutSum' => $outSum,
            'InvoiceID' => $invoiceId,
            'PreviousInvoiceID' => (string)(int)$parentPayment['invoice_id'],
            'Description' => mb_substr((string)$plan['name'], 0, 100),
            'IsTest' => !empty($config['test_mode']) ? '1' : '0',
        ];

        if (!empty($config['receipt_enabled'])) {
            $receipt = rawurlencode($this->receipt($plan, $order, $config));
            $params['Receipt'] = $receipt;
            $signatureParts[] = $receipt;
        }

        // PreviousInvoiceID intentionally does not participate in SignatureValue.
        // Receipt, when present, must participate before Password #1.
        $signatureParts[] = $config['password1'];

        $params['SignatureValue'] = $this->hash(
            implode(':', $signatureParts),
            $config['hash_algorithm']
        );

        $body = http_build_query($params, '', '&', PHP_QUERY_RFC3986);
        if (function_exists('curl_init')) {
            $curl = curl_init(self::RECURRING_URL);
            curl_setopt_array($curl, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
            ]);
            $response = curl_exec($curl);
            $error = curl_error($curl);
            $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);
            if (!is_string($response) || $response === '' || $status < 200 || $status >= 300) {
                throw new \RuntimeException('Robokassa recurring request failed' . ($error !== '' ? ': ' . $error : '.'));
            }
        } else {
            $context = stream_context_create(['http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                'content' => $body,
                'timeout' => 30,
                'ignore_errors' => true,
            ]]);
            $response = @file_get_contents(self::RECURRING_URL, false, $context);
            if (!is_string($response) || $response === '') {
                throw new \RuntimeException('Robokassa recurring request failed.');
            }
        }
        $response = trim($response);
        if ($response !== 'OK+' . $invoiceId && $response !== 'OK' . $invoiceId) {
            throw new \RuntimeException('Robokassa rejected the recurring request.');
        }

        return $response;
    }

    private function verifyCallback(array $payload, string $password, string $algorithm): bool
    {
        $outSum = trim((string)($payload['OutSum'] ?? $payload['outSum'] ?? ''));
        $invoiceId = trim((string)($payload['InvId'] ?? $payload['InvoiceID'] ?? $payload['invoiceID'] ?? ''));
        $received = strtolower(trim((string)($payload['SignatureValue'] ?? $payload['signatureValue'] ?? '')));
        if ($outSum === '' || !ctype_digit($invoiceId) || $received === '') {
            return false;
        }

        $parts = [$outSum, $invoiceId, $password];
        foreach ($this->shp($payload) as $key => $value) {
            $parts[] = $key . '=' . $value;
        }
        $expected = $this->hash(implode(':', $parts), $algorithm);

        return hash_equals($expected, $received);
    }

    private function shp(array $payload): array
    {
        $shp = [];
        foreach ($payload as $key => $value) {
            if (is_string($key) && str_starts_with($key, 'Shp_') && is_scalar($value)) {
                $shp[$key] = (string)$value;
            }
        }
        ksort($shp, SORT_STRING);

        return $shp;
    }

    private function receipt(array $plan, array $order, array $config): string
    {
        $name = trim((string)($plan['name'] ?? ''));
        $amountMinor = (int)($order['amount_minor'] ?? 0);

        if ($name === '') {
            throw new \RuntimeException('Robokassa receipt item name is empty.');
        }

        if ($amountMinor <= 0) {
            throw new \RuntimeException('Robokassa receipt amount must be greater than zero.');
        }

        $tax = (string)($config['receipt_tax'] ?? '');
        $paymentMethod = (string)($config['receipt_payment_method'] ?? '');
        $paymentObject = (string)($config['receipt_payment_object'] ?? '');

        if (!in_array($tax, ['none', 'vat0', 'vat5', 'vat7', 'vat10', 'vat20', 'vat105', 'vat107', 'vat110', 'vat120'], true)) {
            throw new \RuntimeException('Invalid Robokassa receipt tax.');
        }

        if (!in_array($paymentMethod, ['full_payment', 'prepayment', 'full_prepayment', 'advance'], true)) {
            throw new \RuntimeException('Invalid Robokassa receipt payment method.');
        }

        if (!in_array($paymentObject, ['service', 'commodity', 'payment', 'another'], true)) {
            throw new \RuntimeException('Invalid Robokassa receipt payment object.');
        }

        $payload = [
            'items' => [[
                'name' => mb_substr($name, 0, 128),
                'quantity' => 1,
                'sum' => Money::decimal($amountMinor),
                'tax' => $tax,
                'payment_method' => $paymentMethod,
                'payment_object' => $paymentObject,
            ]],
        ];

        return (string)json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
    }

    private function hash(string $value, string $algorithm): string
    {
        return strtolower(hash($algorithm, $value));
    }

    private function culture(): string
    {
        return str_starts_with(strtolower((string)current_locale()), 'ru') ? 'ru' : 'en';
    }
}
