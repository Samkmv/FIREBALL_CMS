<?php

namespace Fireball\Subscriptions\Controllers;

use Fireball\Subscriptions\Repositories\PlanRepository;
use Fireball\Subscriptions\Repositories\ProfileRepository;
use Fireball\Subscriptions\Repositories\ContentRuleRepository;
use Fireball\Subscriptions\Repositories\AddressExclusionRepository;
use Fireball\Subscriptions\Services\SettingsService;
use Fireball\Subscriptions\Services\AddressSuggestionService;
use Fireball\Subscriptions\Services\AddressCatalogImportService;
use Fireball\Subscriptions\Services\PaymentService;
use Fireball\Subscriptions\Services\SubscriptionService;
use Fireball\Subscriptions\Support\SubscriptionStatus;

final class AdminController
{
    public function dashboard(): string
    {
        $activeSql = SubscriptionStatus::activeSql();
        $stats = [
            'active' => (int)db()->query("SELECT COUNT(*) FROM subscriptions s WHERE {$activeSql}")->getColumn(),
            'expiring' => (int)db()->query("SELECT COUNT(*) FROM subscriptions s WHERE {$activeSql} AND s.status IN ('active', 'cancelled') AND s.ends_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)")->getColumn(),
        ] + (new PaymentService())->visibleHistoryStats();
        $byPlan = db()->query(
            "SELECT p.name, COUNT(s.id) AS total FROM subscription_plans p LEFT JOIN subscriptions s ON s.plan_id = p.id AND {$activeSql} GROUP BY p.id, p.name ORDER BY total DESC, p.name"
        )->get() ?: [];

        return $this->view('admin/dashboard', 'overview', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_title'),
            'stats' => $stats,
            'by_plan' => $byPlan,
        ]);
    }

    public function plans(): string
    {
        return $this->view('admin/plans', 'plans', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_plans'),
            'plans' => (new PlanRepository())->all(),
        ]);
    }

    public function planForm(): string
    {
        $id = (int)get_route_param('id');
        $repository = new PlanRepository();
        if (request()->isPost()) {
            try {
                $repository->save(request()->getData(), $id > 0 ? $id : null);
                session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_plan_saved'));
                response()->redirect(base_href('/admin/subscriptions/plans'));
            } catch (\Throwable $exception) {
                session()->setFlash('error', $exception->getMessage());
                session()->set('subscriptions.plan_data', request()->getData());
                response()->redirect($id > 0 ? base_href('/admin/subscriptions/plans/edit/' . $id) : base_href('/admin/subscriptions/plans/create'));
            }
        }
        $plan = $id > 0 ? $repository->find($id) : null;
        if ($id > 0 && !$plan) {
            abort();
        }

        $formData = (array)session()->get('subscriptions.plan_data', []);
        session()->remove('subscriptions.plan_data');

        return $this->view('admin/plan-form', 'plans', [
            'title' => $id > 0 ? \FireballPluginSubscriptions::t('subscriptions_plan_edit') : \FireballPluginSubscriptions::t('subscriptions_plan_create'),
            'plan' => $plan,
            'form_data' => $formData,
            'permissions' => PlanRepository::PERMISSIONS,
        ]);
    }

    public function planAction(): never
    {
        try {
            $id = (int)request()->post('id');
            $action = (string)request()->post('action');
            $repository = new PlanRepository();
            match ($action) {
                'toggle_active' => $repository->toggle($id, 'is_active'),
                'toggle_public' => $repository->toggle($id, 'is_public'),
                'clone' => $repository->clone($id),
                default => throw new \InvalidArgumentException('Invalid plan action.'),
            };
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_plan_saved'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/plans'));
    }

    public function subscribers(): string
    {
        $effectiveStatusSql = SubscriptionStatus::effectiveSql();
        $search = trim((string)request()->get('q', ''));
        $status = trim((string)request()->get('status', ''));
        $where = ['s.archived_at IS NULL'];
        $params = [];
        if ($search !== '') {
            $where[] = '(u.name LIKE ? OR u.email LIKE ?)';
            $like = '%' . $search . '%';
            $params = [$like, $like];
        }
        if (in_array($status, ['active', 'disabled', 'pending', 'cancelled', 'grace_period', 'past_due', 'expired'], true)) {
            $where[] = '(' . $effectiveStatusSql . ') = ?';
            $params[] = $status;
        } else {
            $status = '';
        }
        $whereSql = 'WHERE ' . implode(' AND ', $where);
        $total = (int)db()->query("SELECT COUNT(*) FROM subscriptions s INNER JOIN users u ON u.id = s.user_id {$whereSql}", $params)->getColumn();
        $pagination = new \FBL\Pagination($total, 20);
        $offset = $pagination->getOffset();
        $rows = db()->query(
            "SELECT s.*, {$effectiveStatusSql} AS effective_status, u.name AS user_name, u.email AS user_email, p.name AS plan_name,
                    NOT EXISTS (
                        SELECT 1 FROM subscriptions active_s
                        WHERE active_s.user_id = s.user_id AND active_s.archived_at IS NULL
                          AND (
                               (active_s.status IN ('active', 'cancelled') AND active_s.starts_at <= NOW() AND (active_s.ends_at IS NULL OR active_s.ends_at > NOW()))
                               OR (active_s.status = 'grace_period' AND active_s.starts_at <= NOW() AND COALESCE(active_s.grace_ends_at, active_s.ends_at) > NOW())
                          )
                    ) AS can_archive_subscriber
             FROM subscriptions s INNER JOIN users u ON u.id = s.user_id INNER JOIN subscription_plans p ON p.id = s.plan_id
             {$whereSql} ORDER BY s.created_at DESC LIMIT {$offset}, 20",
            $params
        )->get() ?: [];
        $profiles = new ProfileRepository();
        $rows = $this->attachSubscriberDetails($rows, $profiles);

        return $this->view('admin/subscribers', 'subscribers', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_subscribers'),
            'subscriptions' => $rows,
            'profile_fields' => $profiles->fields(),
            'plans' => (new PlanRepository())->all(),
            'users' => db()->query('SELECT id, name, email FROM users ORDER BY name, email LIMIT 1000')->get() ?: [],
            'pagination' => $pagination,
            'total' => $total,
            'search' => $search,
            'status_filter' => $status,
        ]);
    }

    public function grant(): never
    {
        try {
            (new SubscriptionService())->grant(
                (int)request()->post('user_id'), (int)request()->post('plan_id'),
                max(1, (int)request()->post('duration_value', 30)), (string)request()->post('duration_unit', 'days'),
                (int)(get_user()['id'] ?? 0), (string)request()->post('comment', ''), (string)request()->post('source', 'manual')
            );
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_grant_saved'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/subscribers'));
    }

    public function updateSubscriber(): never
    {
        try {
            (new SubscriptionService())->updateManaged(
                (int)request()->post('id'),
                (int)request()->post('plan_id'),
                (string)request()->post('status', 'disabled'),
                (string)request()->post('ends_at', ''),
                (int)(get_user()['id'] ?? 0)
            );
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_subscriber_saved'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/subscribers'));
    }

    public function deleteSubscriber(): never
    {
        try {
            (new SubscriptionService())->archiveInactiveSubscriber(
                (int)request()->post('user_id'),
                (int)(get_user()['id'] ?? 0)
            );
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_subscriber_deleted'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/subscribers'));
    }

    public function deleteDisabledSubscriber(): never
    {
        try {
            (new SubscriptionService())->archiveDisabledSubscription(
                (int)request()->post('subscription_id'),
                (int)(get_user()['id'] ?? 0)
            );
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_subscriber_disabled_deleted'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/subscribers'));
    }

    public function exclusions(): string
    {
        $search = trim((string)request()->get('q', ''));
        $perPage = 25;
        $repository = new AddressExclusionRepository();
        $total = $repository->count($search);
        $pagination = new \FBL\Pagination($total, $perPage);
        $result = $repository->paginated($search, $perPage, $pagination->getOffset(), $total);

        return $this->view('admin/exclusions', 'exclusions', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_exclusions'),
            'exclusions' => $result['items'],
            'total' => $result['total'],
            'pagination' => $pagination,
            'search' => $search,
        ]);
    }

    public function exclusionForm(): string
    {
        $id = (int)get_route_param('id');
        $repository = new AddressExclusionRepository();
        if (request()->isPost()) {
            $submitted = request()->getData();
            $submitted['is_active'] = !empty($submitted['is_active']);
            try {
                $repository->save($submitted, $id > 0 ? $id : null, (int)(get_user()['id'] ?? 0));
                session()->setFlash('success', \FireballPluginSubscriptions::t($id > 0 ? 'subscriptions_exclusion_updated' : 'subscriptions_exclusion_added'));
                response()->redirect(base_href('/admin/subscriptions/exclusions'));
            } catch (\Throwable $exception) {
                session()->setFlash('error', $exception->getMessage());
                session()->set('subscriptions.exclusion_data', $submitted);
                response()->redirect($id > 0
                    ? base_href('/admin/subscriptions/exclusions/edit/' . $id)
                    : base_href('/admin/subscriptions/exclusions/create'));
            }
        }
        $exclusion = $id > 0 ? $repository->find($id) : null;
        if ($id > 0 && !$exclusion) {
            abort();
        }
        $formData = (array)session()->get('subscriptions.exclusion_data', []);
        session()->remove('subscriptions.exclusion_data');

        return $this->view('admin/exclusion-form', 'exclusions', [
            'title' => \FireballPluginSubscriptions::t($id > 0 ? 'subscriptions_exclusion_edit' : 'subscriptions_exclusion_create'),
            'exclusion' => $exclusion,
            'form_data' => $formData,
            'matched_users' => $id > 0 ? $repository->matchedUsers($id) : [],
        ]);
    }

    public function deleteExclusion(): never
    {
        try {
            (new AddressExclusionRepository())->delete(
                (int)request()->post('id'),
                (int)(get_user()['id'] ?? 0)
            );
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_exclusion_deleted'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/exclusions'));
    }

    public function payments(): string
    {
        (new PaymentService())->expirePending();
        $search = trim((string)request()->get('q', ''));
        $where = ['sp.cleared_at IS NULL'];
        $params = [];
        if ($search !== '') {
            $where[] = '(u.name LIKE ? OR u.email LIKE ? OR CAST(sp.invoice_id AS CHAR) LIKE ?)';
            $like = '%' . $search . '%';
            $params = [$like, $like, $like];
        }
        $whereSql = 'WHERE ' . implode(' AND ', $where);
        $total = (int)db()->query("SELECT COUNT(*) FROM subscription_payments sp INNER JOIN users u ON u.id = sp.user_id {$whereSql}", $params)->getColumn();
        $pagination = new \FBL\Pagination($total, 25);
        $offset = $pagination->getOffset();
        $rows = db()->query(
            "SELECT sp.*, u.name AS user_name, u.email AS user_email, p.name AS plan_name,
                    o.status AS order_status, o.customer_snapshot, o.consent_snapshot, o.plan_snapshot,
                    we.processing_status AS webhook_status,
                    we.signature_verified AS webhook_signature_verified,
                    we.error_message AS webhook_error_message,
                    we.created_at AS webhook_created_at,
                    we.processed_at AS webhook_processed_at
             FROM subscription_payments sp
             INNER JOIN users u ON u.id = sp.user_id
             INNER JOIN subscription_plans p ON p.id = sp.plan_id
             INNER JOIN subscription_orders o ON o.id = sp.order_id
             LEFT JOIN subscription_webhook_events we ON we.id = (
                 SELECT latest_we.id
                 FROM subscription_webhook_events latest_we
                 WHERE latest_we.provider = sp.provider AND latest_we.invoice_id = sp.invoice_id
                 ORDER BY latest_we.id DESC
                 LIMIT 1
             )
             {$whereSql} ORDER BY sp.created_at DESC LIMIT {$offset}, 25",
            $params
        )->get() ?: [];
        foreach ($rows as &$row) {
            $row['payer_snapshot'] = $this->decodeSnapshot((string)($row['customer_snapshot'] ?? ''));
            $row['consents'] = $this->decodeSnapshot((string)($row['consent_snapshot'] ?? ''));
        }
        unset($row);

        return $this->view('admin/payments', 'payments', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_payments'),
            'payments' => $rows,
            'profile_fields' => (new ProfileRepository())->fields(),
            'pagination' => $pagination,
            'total' => $total,
            'search' => $search,
        ]);
    }

    public function clearPayments(): never
    {
        (new PaymentService())->clearHistory();
        session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_payments_cleared'));
        response()->redirect(base_href('/admin/subscriptions/payments'));
    }

    public function retryPaymentWebhook(): never
    {
        try {
            (new PaymentService())->retryVerifiedWebhook((int)request()->post('payment_id'));
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_webhook_retry_success'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/payments'));
    }

    public function refreshPayments(): never
    {
        try {
            $payments = new PaymentService();
            $expired = $payments->expirePending();
            $retried = $payments->retryFailedWebhooks();
            session()->setFlash($retried['failed'] > 0 ? 'warning' : 'success', str_replace(
                [':expired', ':processed', ':failed'],
                [(string)$expired, (string)$retried['processed'], (string)$retried['failed']],
                \FireballPluginSubscriptions::t('subscriptions_payments_refreshed')
            ));
        } catch (\Throwable $exception) {
            log_error_details('Subscription payment status refresh failed', [], $exception);
            session()->setFlash('error', \FireballPluginSubscriptions::t('subscriptions_payments_refresh_failed'));
        }
        response()->redirect(base_href('/admin/subscriptions/payments'));
    }

    public function contentAccess(): string
    {
        $search = trim((string)request()->get('q', ''));
        $access = trim((string)request()->get('access', ''));
        $result = (new ContentRuleRepository())->paginatedPosts($search, $access);

        return $this->view('admin/content', 'content', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_content'),
            'posts' => $result['items'],
            'total' => $result['total'],
            'pagination' => $result['pagination'],
            'plans' => (new PlanRepository())->all(),
            'search' => $search,
            'access_filter' => $access,
        ]);
    }

    public function saveContentAccess(): never
    {
        $entries = request()->post('content', null);
        if (!is_array($entries)) {
            $legacyPostId = (int)request()->post('id');
            $entries = $legacyPostId > 0 ? [
                $legacyPostId => [
                    'subscription_access_mode' => request()->post('subscription_access_mode', 'public'),
                    'subscription_plan_ids' => (array)request()->post('subscription_plan_ids', []),
                ],
            ] : [];
        }

        $database = db();
        try {
            $repository = new ContentRuleRepository();
            $database->beginTransaction();
            foreach ($entries as $postId => $entry) {
                $postId = (int)$postId;
                if ($postId <= 0 || !is_array($entry)) {
                    continue;
                }

                $current = $repository->find('post', $postId) ?: [
                    'show_title' => 1, 'show_excerpt' => 1, 'show_image' => 1,
                    'hide_video' => 0, 'required_permission' => 'posts.view_paid',
                ];
                $repository->save('post', $postId, [
                    'subscription_access_mode' => (string)($entry['subscription_access_mode'] ?? 'public'),
                    'subscription_plan_ids' => (array)($entry['subscription_plan_ids'] ?? []),
                    'subscription_show_title' => !empty($current['show_title']) ? '1' : '',
                    'subscription_show_excerpt' => !empty($current['show_excerpt']) ? '1' : '',
                    'subscription_show_image' => !empty($current['show_image']) ? '1' : '',
                    'subscription_hide_video' => !empty($current['hide_video']) ? '1' : '',
                    'subscription_required_permission' => (string)($current['required_permission'] ?? 'posts.view_paid'),
                ]);
            }
            $database->commit();
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_content_saved'));
        } catch (\Throwable $exception) {
            if ($database->inTransaction()) {
                $database->rollBack();
            }
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/content'));
    }

    public function fields(): string
    {
        return $this->view('admin/fields', 'fields', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_profile_fields'),
            'fields' => (new ProfileRepository())->fields(),
        ]);
    }

    public function fieldForm(): string
    {
        $id = (int)get_route_param('id');
        $profiles = new ProfileRepository();
        if (request()->isPost()) {
            try {
                $profiles->saveField(request()->getData(), $id > 0 ? $id : null);
                session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_field_saved'));
                response()->redirect(base_href('/admin/subscriptions/profile-fields'));
            } catch (\Throwable $exception) {
                session()->setFlash('error', $exception->getMessage());
                response()->redirect($id ? base_href('/admin/subscriptions/profile-fields/edit/' . $id) : base_href('/admin/subscriptions/profile-fields/create'));
            }
        }
        $field = null;
        foreach ($profiles->fields() as $candidate) {
            if ((int)$candidate['id'] === $id) {
                $field = $candidate;
                break;
            }
        }
        if ($id > 0 && !$field) {
            abort();
        }

        return $this->view('admin/field-form', 'fields', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_field_edit'),
            'field' => $field,
            'field_types' => ProfileRepository::FIELD_TYPES,
            'plans' => (new PlanRepository())->all(),
        ]);
    }

    public function deleteField(): never
    {
        try {
            (new ProfileRepository())->deleteField((int)request()->post('id'));
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_field_deleted'));
        } catch (\Throwable $exception) {
            session()->setFlash('error', $exception->getMessage());
        }
        response()->redirect(base_href('/admin/subscriptions/profile-fields'));
    }

    public function settings(): string
    {
        $settings = new SettingsService();

        return $this->view('admin/settings', 'settings', [
            'title' => \FireballPluginSubscriptions::t('subscriptions_admin_settings'),
            'settings' => $settings->current(),
            'offer_pages' => (new \Fireball\Subscriptions\Services\PublicOfferService())->pages(),
            'address_catalog_stats' => (new AddressSuggestionService())->stats(),
            'address_import_limit' => AddressCatalogImportService::requestLimit(),
        ]);
    }

    public function saveSettings(): never
    {
        $data = request()->getData();
        $database = db();

        try {
            $database->beginTransaction();
            (new SettingsService())->save($data);
            $database->commit();
            session()->setFlash('success', \FireballPluginSubscriptions::t('subscriptions_settings_saved'));
        } catch (\Throwable $exception) {
            if ($database->inTransaction()) {
                $database->rollBack();
            }
            log_error_details('Subscription settings save failed', [
                'Submitted keys' => array_values(array_diff(array_keys($data), ['password1', 'password2', 'needCSRFToken'])),
                'Merchant login provided' => trim((string)($data['merchant_login'] ?? '')) !== '',
                'Password 1 provided' => (string)($data['password1'] ?? '') !== '',
                'Password 2 provided' => (string)($data['password2'] ?? '') !== '',
            ], $exception);
            $messageKey = str_starts_with($exception->getMessage(), SettingsService::CREDENTIALS_NOT_CONFIGURED)
                ? 'subscriptions_settings_credentials_missing'
                : 'subscriptions_settings_save_failed';
            session()->setFlash('error', $exception instanceof \InvalidArgumentException
                && !str_starts_with($exception->getMessage(), SettingsService::CREDENTIALS_NOT_CONFIGURED)
                ? $exception->getMessage() : \FireballPluginSubscriptions::t($messageKey));
        }

        response()->redirect(base_href('/admin/subscriptions/settings'));
    }

    public function addressCatalogImport(): never
    {
        try {
            $file = is_array($_FILES['address_catalog'] ?? null)
                ? $_FILES['address_catalog']
                : [];

            $result = (new AddressSuggestionService())->importUploaded(
                $file,
                !empty(request()->post('replace_catalog'))
            );

            session()->setFlash(
                'success',
                'Локальный справочник импортирован. Строк: '
                . (int)$result['processed']
                . ', пропущено: '
                . (int)$result['skipped']
            );
        } catch (\Throwable $exception) {
            log_error_details('Local address catalog import failed', [], $exception);
            session()->setFlash('error', $exception->getMessage());
        }

        response()->redirect(base_href('/admin/subscriptions/settings'));
    }

    public function addressCatalogClear(): never
    {
        try {
            (new AddressSuggestionService())->clear();
            session()->setFlash('success', 'Локальный справочник адресов очищен.');
        } catch (\Throwable $exception) {
            log_error_details('Local address catalog clear failed', [], $exception);
            session()->setFlash('error', $exception->getMessage());
        }

        response()->redirect(base_href('/admin/subscriptions/settings'));
    }

    public function addressCatalogBatch(): never
    {
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > AddressCatalogImportService::requestLimit()) {
            response()->json(['ok' => false, 'message' => 'Порция файла превышает лимит загрузки. Обновите страницу настроек.'], 413);
        }
        try {
            response()->json((new AddressCatalogImportService())->handle(request()->getData()));
        } catch (\InvalidArgumentException $exception) {
            response()->json(['ok' => false, 'message' => $exception->getMessage()], 422);
        } catch (\Throwable $exception) {
            log_error_details('Address catalog batch import failed', [], $exception);
            response()->json(['ok' => false, 'message' => 'Не удалось обработать порцию справочника. Повторите попытку; подробности записаны в журнал сервера.'], 500);
        }
    }


    private function attachSubscriberDetails(array $subscriptions, ProfileRepository $profiles): array
    {
        if ($subscriptions === []) {
            return [];
        }

        $profileRows = $profiles->profilesForUsers(array_column($subscriptions, 'user_id'));
        $subscriptionIds = array_values(array_unique(array_filter(
            array_map(static fn(array $row): int => (int)($row['id'] ?? 0), $subscriptions),
            static fn(int $id): bool => $id > 0
        )));
        $ordersBySubscription = [];
        if ($subscriptionIds !== []) {
            $placeholders = implode(',', array_fill(0, count($subscriptionIds), '?'));
            $orders = db()->query(
                "SELECT * FROM subscription_orders
                 WHERE subscription_id IN ({$placeholders})
                 ORDER BY subscription_id ASC, CASE WHEN status = 'paid' THEN 0 ELSE 1 END ASC, id DESC",
                $subscriptionIds
            )->get() ?: [];
            foreach ($orders as $order) {
                $subscriptionId = (int)($order['subscription_id'] ?? 0);
                if ($subscriptionId > 0 && !isset($ordersBySubscription[$subscriptionId])) {
                    $ordersBySubscription[$subscriptionId] = $order;
                }
            }
        }

        foreach ($subscriptions as &$subscription) {
            $subscriptionId = (int)($subscription['id'] ?? 0);
            $userId = (int)($subscription['user_id'] ?? 0);
            $order = $ordersBySubscription[$subscriptionId] ?? [];
            $snapshot = $this->decodeSnapshot((string)($order['customer_snapshot'] ?? ''));
            $snapshotSource = $snapshot !== [] ? 'order' : 'profile';
            if ($snapshot === [] && isset($profileRows[$userId])) {
                $snapshot = $profiles->snapshotFromProfile($profileRows[$userId]);
            }
            $subscription['payer_snapshot'] = $snapshot;
            $subscription['payer_snapshot_source'] = $snapshot !== [] ? $snapshotSource : 'none';
            $subscription['payer_custom_fields'] = (array)($profileRows[$userId]['custom_fields'] ?? []);
            $subscription['purchase_order'] = $order;
        }
        unset($subscription);

        return $subscriptions;
    }

    private function decodeSnapshot(string $value): array
    {
        if (trim($value) === '') {
            return [];
        }

        $decoded = json_decode($value, true);

        return is_array($decoded) ? $decoded : [];
    }

    private function view(string $view, string $tab, array $data): string
    {
        return plugin_view('subscriptions', $view, \FireballPluginSubscriptions::viewData($data + [
            'tabs' => \FireballPluginSubscriptions::tabs($tab),
        ]));
    }
}
