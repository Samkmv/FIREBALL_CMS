<?php

namespace App\Services;

use App\Models\SiteSetting;
use RuntimeException;

/**
 * Проверяет удалённую ветку Git-репозитория и обновляет CMS из source code.
 */
class UpdateCenter
{
    protected const AUTO_CHECK_INTERVAL_SECONDS = 21600;
    protected const PRE_UPDATE_BACKUP_RETENTION = 2;
    protected const PRE_UPDATE_BACKUP_PATTERNS = [
        'db-backup-*.sql',
        'files-backup-*.zip',
    ];

    protected SiteSetting $siteSettings;
    protected array $engineRelease;
    protected bool $installationMutated = false;

    public function __construct(?SiteSetting $siteSettings = null)
    {
        $this->siteSettings = $siteSettings ?? new SiteSetting();
        $this->reloadEngineRelease();
    }

    /**
     * Собирает данные для карточки центра обновлений в админке.
     */
    public function getDashboardData(): array
    {
        $this->reloadEngineRelease();
        $this->checkForUpdatesIfStale();

        $settings = $this->siteSettings->all();
        $localGitState = $this->getLocalGitState();
        $repository = $this->resolveRepository($settings, $localGitState['origin_url'] ?? '');
        $branch = $this->resolveBranch($settings, $localGitState['branch'] ?? '');
        $channel = $this->resolveUpdateChannel($settings);
        $lastCheck = $this->lastCheckForChannel($settings);
        $storedCommit = $this->getStoredInstalledCommit($settings);
        $displayCommit = (string)($localGitState['commit_hash'] ?? '') !== ''
            ? (string)$localGitState['commit_hash']
            : $storedCommit;
        $displayShortCommit = (string)($localGitState['short_commit'] ?? '') !== ''
            ? (string)$localGitState['short_commit']
            : ($storedCommit !== '' ? substr($storedCommit, 0, 7) : '');

        return [
            'config' => [
                'repository' => $repository,
                'branch' => $branch,
                'channel' => $channel,
                'source' => $channel === 'dev' ? 'main_branch' : 'github_releases',
                'has_token' => trim((string)($settings['updater_github_token'] ?? '')) !== '',
                'last_checked_at' => trim((string)($lastCheck['checked_at'] ?? '')),
                'last_updated_at' => trim((string)($settings['updater_last_updated_at'] ?? '')),
                'rollback_commit' => trim((string)($settings['updater_rollback_commit'] ?? '')),
            ],
            'local' => [
                'name' => (string)($this->engineRelease['name'] ?? 'FIREBALL_CMS'),
                'version' => (string)($this->engineRelease['version'] ?? '0.0.0'),
                'released_at' => (string)($this->engineRelease['released_at'] ?? ''),
                'summary' => (string)($this->engineRelease['summary'] ?? ''),
                'changes' => is_array($this->engineRelease['changes'] ?? null) ? $this->engineRelease['changes'] : [],
                'origin_url' => $localGitState['origin_url'],
                'branch' => $branch,
                'commit_hash' => $displayCommit,
                'short_commit' => $displayShortCommit,
                'git_tag' => $localGitState['git_tag'],
                'git_describe' => $localGitState['git_describe'],
                'is_git_repo' => $localGitState['is_git_repo'],
                'git_available' => $localGitState['git_available'],
                'is_clean' => $localGitState['is_clean'],
                'is_update_clean' => $localGitState['is_update_clean'],
                'dirty_files' => $localGitState['dirty_files'],
                'blocking_dirty_files' => $localGitState['blocking_dirty_files'],
                'ignored_dirty_files' => $localGitState['ignored_dirty_files'],
            ],
            'last_check' => $lastCheck,
            'update_blockers' => $this->buildUpdateBlockers($repository, $localGitState, $channel),
        ];
    }

    /**
     * Проверяет наличие новой версии в удалённой ветке и сохраняет результат.
     */
    public function checkForUpdates(): array
    {
        $this->reloadEngineRelease();

        $settings = $this->siteSettings->all();
        $localGitState = $this->getLocalGitState();
        $repository = $this->resolveRepository($settings, $localGitState['origin_url'] ?? '');
        $branch = $this->resolveBranch($settings, $localGitState['branch'] ?? '');
        $channel = $this->resolveUpdateChannel($settings);
        $storedCommit = $this->getStoredInstalledCommit($settings);
        $localCommit = !empty($localGitState['is_git_repo'])
            ? (string)($localGitState['commit_hash'] ?? '')
            : $storedCommit;

        $basePayload = [
            'status' => 'error',
            'checked_at' => date('Y-m-d H:i:s'),
            'message' => '',
            'repository' => $repository,
            'branch' => $branch,
            'channel' => $channel,
            'local_version' => (string)($this->engineRelease['version'] ?? '0.0.0'),
            'local_commit' => $localCommit,
            'remote_version' => '',
            'remote_commit' => '',
            'branch_status' => 'not_applicable',
            'git_update_available' => false,
            'version_update_available' => false,
            'update_available' => false,
            'release' => null,
        ];

        try {
            if ($repository === '') {
                throw new RuntimeException(return_translation('admin_update_repository_required'));
            }

            if ($channel !== 'dev') {
                return $this->checkStableRelease(
                    $basePayload,
                    $repository,
                    (string)($settings['updater_github_token'] ?? '')
                );
            }

            $release = null;
            $branchState = [
                'status' => 'not_applicable',
                'remote_commit_hash' => '',
            ];
            $remoteVersion = '';
            $versionUpdateAvailable = false;
            $gitUpdateAvailable = false;

            if (!empty($localGitState['is_git_repo'])) {
                $this->fetchRemoteBranch($branch);
                $branchState = $this->getBranchStateFromGit($branch);
                $gitUpdateAvailable = in_array((string)($branchState['status'] ?? 'unknown'), ['behind', 'no_local_commit'], true);

                $release = $this->tryFetchLatestRelease($repository, (string)($settings['updater_github_token'] ?? ''), $branch);
                $remoteVersion = $this->resolveRemoteVersion($release, $branch, (string)($branchState['remote_commit_hash'] ?? ''));

                if ($remoteVersion !== '') {
                    $comparison = $this->compareVersions(
                        (string)($this->engineRelease['version'] ?? '0.0.0'),
                        $remoteVersion
                    );
                    $versionUpdateAvailable = $comparison !== null && $comparison < 0;
                }

                $updateAvailable = $gitUpdateAvailable;
            } else {
                $remoteVersionFile = $this->fetchRemoteVersionMetadata(
                    $repository,
                    $branch,
                    (string)($settings['updater_github_token'] ?? '')
                );
                $branchState = $this->fetchBranchState(
                    $repository,
                    $branch,
                    $storedCommit,
                    (string)($settings['updater_github_token'] ?? '')
                );
                if ($storedCommit === '') {
                    $branchState['status'] = 'not_applicable';
                }

                $release = $this->buildBranchRelease(
                    $repository,
                    $branch,
                    $remoteVersionFile,
                    (string)($branchState['remote_commit_hash'] ?? ''),
                    (string)($settings['updater_github_token'] ?? '')
                );
                $remoteVersion = trim((string)($remoteVersionFile['version'] ?? ''));
                $comparison = $this->compareVersions(
                    (string)($this->engineRelease['version'] ?? '0.0.0'),
                    $remoteVersion
                );
                $versionUpdateAvailable = $comparison === null
                    ? $this->fallbackReleaseComparison(
                        (string)($this->engineRelease['released_at'] ?? ''),
                        (string)($remoteVersionFile['released_at'] ?? '')
                    )
                    : $comparison < 0;

                $branchUpdateAvailable = $storedCommit !== ''
                    && in_array((string)($branchState['status'] ?? 'unknown'), ['behind', 'no_local_commit'], true);
                $updateAvailable = $versionUpdateAvailable || $branchUpdateAvailable;
            }

            $payload = array_merge($basePayload, [
                'status' => 'ok',
                'message' => $this->resolveCheckMessage((string)($branchState['status'] ?? 'unknown'), $updateAvailable),
                'remote_version' => $remoteVersion,
                'remote_commit' => (string)($branchState['remote_commit_hash'] ?? ''),
                'branch_status' => (string)($branchState['status'] ?? 'unknown'),
                'git_update_available' => $gitUpdateAvailable,
                'version_update_available' => $versionUpdateAvailable,
                'update_available' => $updateAvailable,
                'release' => $release,
            ]);

            $this->persistLastCheck($payload);

            return $payload;
        } catch (\Throwable $exception) {
            $payload = array_merge($basePayload, [
                'message' => $exception->getMessage(),
            ]);
            $this->persistLastCheck($payload);
            throw new RuntimeException($exception->getMessage(), 0, $exception);
        }
    }

    /**
     * Проверяет опубликованные релизы: Stable либо Stable + prerelease для создателя.
     */
    protected function checkStableRelease(array $basePayload, string $repository, string $token): array
    {
        $release = $this->fetchUpdateRelease($repository, $token);

        if ($release === null) {
            $payload = array_merge($basePayload, [
                'status' => 'ok',
                'message' => return_translation('admin_update_no_releases'),
                'branch_status' => 'not_applicable',
            ]);
            $this->persistLastCheck($payload);

            return $payload;
        }

        $remoteVersion = $this->extractReleaseVersion($release);
        $comparison = $this->compareVersions(
            (string)($this->engineRelease['version'] ?? '0.0.0'),
            $remoteVersion
        );
        $updateAvailable = $comparison === null
            ? $this->fallbackReleaseComparison(
                (string)($this->engineRelease['released_at'] ?? ''),
                (string)($release['published_at'] ?? '')
            )
            : $comparison < 0;

        $payload = array_merge($basePayload, [
            'status' => 'ok',
            'message' => return_translation(($basePayload['channel'] ?? '') === 'beta'
                ? ($updateAvailable ? 'admin_update_release_available' : 'admin_update_release_none')
                : ($updateAvailable ? 'admin_update_stable_available' : 'admin_update_stable_none')),
            'remote_version' => $remoteVersion,
            'branch_status' => 'not_applicable',
            'version_update_available' => $updateAvailable,
            'update_available' => $updateAvailable,
            'release' => $release,
        ]);
        $this->persistLastCheck($payload);

        return $payload;
    }

    /**
     * Возвращает сохранённый результат последней проверки обновлений.
     */
    public function getLastCheckPayload(): ?array
    {
        $settings = $this->siteSettings->all();

        return $this->lastCheckForChannel($settings);
    }

    /**
     * Автоматически проверяет обновления, только если прошлый результат устарел.
     */
    public function checkForUpdatesIfStale(int $intervalSeconds = self::AUTO_CHECK_INTERVAL_SECONDS): ?array
    {
        if (function_exists('get_user') && !in_array(get_user()['role'] ?? '', ['creator', 'admin'], true)) {
            return null;
        }
        $settings = $this->siteSettings->all();
        $localGitState = $this->getLocalGitState();
        $repository = $this->resolveRepository($settings, $localGitState['origin_url'] ?? '');
        $lastCheck = $this->lastCheckForChannel($settings);
        $lastCheckedAt = trim((string)($lastCheck['checked_at'] ?? ''));
        $intervalSeconds = max(300, $intervalSeconds);

        if ($repository === '') {
            return null;
        }

        $lastCheckedTimestamp = $lastCheckedAt !== '' ? strtotime($lastCheckedAt) : false;
        if (is_array($lastCheck) && $lastCheckedTimestamp !== false && time() >= $lastCheckedTimestamp
            && (time() - $lastCheckedTimestamp) < $intervalSeconds) {
            return $lastCheck;
        }

        $lock = $this->acquireAutomaticCheckLock('core-' . $this->resolveUpdateChannel($settings));
        if ($lock === null) {
            return $lastCheck;
        }
        try {
            return $this->checkForUpdates();
        } catch (\Throwable) {
            return $this->getLastCheckPayload();
        } finally {
            $this->releaseAutomaticCheckLock($lock);
        }
    }

    /**
     * Обновляет код сайта через GitHub Release/tag, git pull или ZIP fallback.
     */
    public function runUpdate(): array
    {
        $fromVersion = (string)($this->engineRelease['version'] ?? '0.0.0');
        $user = function_exists('get_user') ? (get_user() ?: []) : [];
        $lock = $this->acquireUpdateLock();
        $completed = false;
        $this->installationMutated = false;
        try {
            $this->enableMaintenanceMode($user);
            $result = $this->performUpdate();
            $this->reloadEngineRelease();
            $this->writeUpdateLog(
                $user,
                $fromVersion,
                (string)($this->engineRelease['version'] ?? $fromVersion),
                (string)($result['status'] ?? 'success')
            );

            $completed = true;
            return $result;
        } catch (\Throwable $exception) {
            $this->writeUpdateLog($user, $fromVersion, null, 'error', $exception->getMessage());
            throw $exception;
        } finally {
            try {
                if ($completed || !$this->installationMutated) $this->disableMaintenanceMode();
            } finally { $this->releaseUpdateLock($lock); }
        }
    }

    protected function performUpdate(): array
    {
        $settings = $this->siteSettings->all();
        $localGitState = $this->getLocalGitState();
        $repository = $this->resolveRepository($settings, $localGitState['origin_url'] ?? '');
        $branch = $this->resolveBranch($settings, $localGitState['branch'] ?? '');
        $channel = $this->resolveUpdateChannel($settings);

        foreach ($this->buildUpdateBlockers($repository, $localGitState, $channel) as $blocker) {
            throw new RuntimeException($blocker);
        }

        if ($channel !== 'dev') {
            if (!empty($localGitState['is_git_repo'])) {
                return $this->runStableReleaseGitUpdate(
                    $repository,
                    $branch,
                    (string)($settings['updater_github_token'] ?? '')
                );
            }

            return $this->runStableReleaseUpdate(
                $repository,
                (string)($settings['updater_github_token'] ?? '')
            );
        }

        if (empty($localGitState['is_git_repo'])) {
            return $this->runArchiveUpdate(
                $repository,
                $branch,
                (string)($settings['updater_github_token'] ?? '')
            );
        }

        $previousCommit = (string)($localGitState['commit_hash'] ?? '');
        $this->fetchRemoteBranch($branch);
        $manifest = $this->loadRemoteGitManifest($branch);
        $this->validateUpdateManifest($manifest);
        $branchState = $this->getBranchStateFromGit($branch);

        if (($branchState['status'] ?? '') === 'identical') {
            $this->refreshLastCheckAfterUpdate();

            return [
                'status' => 'success',
                'message' => return_translation('admin_update_already_latest'),
                'release' => $this->tryFetchLatestRelease($repository, (string)($settings['updater_github_token'] ?? ''), $branch),
            ];
        }

        if (($branchState['status'] ?? '') === 'ahead') {
            throw new RuntimeException(return_translation('admin_update_branch_ahead'));
        }

        if (($branchState['status'] ?? '') === 'diverged') {
            throw new RuntimeException(return_translation('admin_update_branch_diverged'));
        }

            $this->validateGitDiffAgainstManifest($branch, $manifest);
            $this->createPreUpdateBackups();
            $this->siteSettings->setMany(['updater_rollback_commit' => $previousCommit]);
            try {
            $this->installationMutated = true;
            $pullResult = $this->runCommand(
                'git pull --ff-only origin ' . escapeshellarg($branch),
                ROOT
            );

            if ($pullResult['exit_code'] !== 0) {
                throw new RuntimeException($this->formatCommandError($pullResult, return_translation('admin_update_pull_failed')));
            }

            $currentCommit = trim($this->runCommand('git rev-parse HEAD', ROOT)['stdout']);
            if ($previousCommit !== '' && $currentCommit !== '' && $previousCommit !== $currentCommit) {
                $this->restorePreservedGitPaths($previousCommit, $currentCommit, $manifest);
                $this->runComposerIfNeeded($previousCommit, $currentCommit);
            }

            $this->runPendingMigrations();
            $this->clearRuntimeCache();
            $this->siteSettings->setMany([
                'updater_last_updated_at' => date('Y-m-d H:i:s'),
                'updater_last_installed_commit' => $currentCommit,
            ]);
            $this->refreshLastCheckAfterUpdate();
        } catch (\Throwable $exception) {
            log_error_details('Git update requires snapshot recovery', ['Commit' => $previousCommit], $exception);
            throw $exception;
        }

        return [
            'status' => 'success',
            'message' => return_translation('admin_update_success'),
            'release' => $this->tryFetchLatestRelease($repository, (string)($settings['updater_github_token'] ?? ''), $branch),
        ];
    }

    /**
     * Возвращает список причин, по которым запуск обновления нужно заблокировать.
     */
    protected function buildUpdateBlockers(string $repository, array $localGitState, ?string $channel = null): array
    {
        $blockers = [];
        $canRunProcesses = $this->canRunProcesses();
        $isGitRepo = !empty($localGitState['is_git_repo']);
        $channel = $channel ?? $this->resolveUpdateChannel($this->siteSettings->all());

        if ($repository === '') {
            $blockers[] = return_translation('admin_update_repository_required');
        }

        if ($channel !== 'dev') {
            if ($isGitRepo && !($localGitState['is_update_clean'] ?? false)) {
                $blockers[] = return_translation('admin_update_dirty_worktree');
            }
            if ($isGitRepo && !$canRunProcesses) {
                $blockers[] = return_translation('admin_update_process_disabled');
            }
            if ($isGitRepo && $canRunProcesses && empty($localGitState['git_available'])) {
                $blockers[] = return_translation('admin_update_git_missing');
            }
            if ($isGitRepo) {
                $localBranch = trim((string)($localGitState['branch'] ?? ''));
                $targetBranch = $this->resolveBranch($this->siteSettings->all(), $localBranch);
                if ($localBranch === '' || $localBranch !== $targetBranch) {
                    $blockers[] = str_replace(
                        [':local', ':target'],
                        [$localBranch !== '' ? $localBranch : 'HEAD', $targetBranch],
                        return_translation('admin_update_branch_mismatch')
                    );
                }
            }
            if (!$this->supportsZipUpdates()) {
                $blockers[] = return_translation('admin_update_zip_missing');
            }
            if (!$this->isWritablePath(ROOT . '/tmp')) {
                $blockers[] = return_translation('admin_update_tmp_not_writable');
            }
            if (!$this->isWritablePath(ROOT)) {
                $blockers[] = return_translation('admin_update_root_not_writable');
            }
            if (!$this->isWritablePath(CONFIG)) {
                $blockers[] = return_translation('admin_update_config_not_writable');
            }

            return $blockers;
        }

        if ($isGitRepo) {
            if (!$canRunProcesses) {
                $blockers[] = return_translation('admin_update_process_disabled');
            }
            if ($canRunProcesses && empty($localGitState['git_available'])) {
                $blockers[] = return_translation('admin_update_git_missing');
            }

            $localBranch = trim((string)($localGitState['branch'] ?? ''));
            $targetBranch = $this->resolveBranch($this->siteSettings->all(), $localBranch);
            if ($localBranch === '' || $localBranch !== $targetBranch) {
                $blockers[] = str_replace(
                    [':local', ':target'],
                    [$localBranch !== '' ? $localBranch : 'HEAD', $targetBranch],
                    return_translation('admin_update_branch_mismatch')
                );
            }
            if (!($localGitState['is_update_clean'] ?? false)) {
                $dirtyPreview = implode(', ', array_slice($localGitState['blocking_dirty_files'] ?? [], 0, 5));
                $message = return_translation('admin_update_dirty_worktree');
                if ($dirtyPreview !== '') {
                    $message .= ' ' . $dirtyPreview;
                }
                $blockers[] = $message;
            }

            return $blockers;
        }

        if (!$this->supportsZipUpdates()) {
            $blockers[] = return_translation('admin_update_zip_missing');
        }
        if (!$this->isWritablePath(ROOT . '/tmp')) {
            $blockers[] = return_translation('admin_update_tmp_not_writable');
        }
        if (!$this->isWritablePath(ROOT)) {
            $blockers[] = return_translation('admin_update_root_not_writable');
        }
        if (!$this->isWritablePath(CONFIG)) {
            $blockers[] = return_translation('admin_update_config_not_writable');
        }

        return $blockers;
    }

    /**
     * Обновляет ZIP-установку архивом исходников целевой ветки.
     */
    protected function runArchiveUpdate(string $repository, string $branch, string $token = ''): array
    {
        $workspace = ROOT . '/tmp/update-' . date('YmdHis') . '-' . bin2hex(random_bytes(4));
        $archivePath = $workspace . '/package.zip';
        $extractPath = $workspace . '/extract';
        $remoteCommit = '';
        $composerFingerprintBefore = $this->captureDependencyFingerprint();
        $storedCommit = $this->getStoredInstalledCommit($this->siteSettings->all());

        try {
            $this->ensureDirectory($workspace);
            $this->ensureDirectory($extractPath);

            $branchState = $this->fetchBranchState(
                $repository,
                $branch,
                $storedCommit,
                $token
            );
            $remoteCommit = (string)($branchState['remote_commit_hash'] ?? '');
            $release = $this->buildBranchRelease(
                $repository,
                $branch,
                $this->fetchRemoteVersionMetadata($repository, $branch, $token),
                $remoteCommit,
                $token
            );

            if ($storedCommit !== '' && ($branchState['status'] ?? '') === 'identical') {
                $this->refreshLastCheckAfterUpdate();

                return [
                    'status' => 'success',
                    'message' => return_translation('admin_update_already_latest'),
                    'release' => $release,
                ];
            }

            $archive = $this->resolveReleaseArchive($release, $repository);

            $this->downloadFile(
                (string)($archive['download_url'] ?? ''),
                $archivePath,
                $this->buildGithubDownloadHeaders($token, (string)($archive['download_mode'] ?? 'direct'))
            );

            $packageRoot = $this->extractArchive($archivePath, $extractPath);
            $manifest = $this->loadUpdateManifest($packageRoot);
            $this->validateUpdateManifest($manifest, $packageRoot);
            $this->assertPackageComposerReady($packageRoot, $composerFingerprintBefore);
            $this->createPreUpdateBackups();
            $this->ensureLocalConfigExists();
            $this->installationMutated = true;
            $this->copyPackageToRoot($packageRoot, ROOT, $manifest);

            $this->runComposerIfDependencyFilesChanged($composerFingerprintBefore);
            $this->runPendingMigrations();
            $this->clearRuntimeCache();

            $this->siteSettings->setMany([
                'updater_last_updated_at' => date('Y-m-d H:i:s'),
                'updater_last_installed_commit' => $remoteCommit,
            ]);
            $this->refreshLastCheckAfterUpdate();

            return [
                'status' => 'success',
                'message' => return_translation('admin_update_success'),
                'release' => $release,
            ];
        } finally {
            $this->deleteDirectory($workspace);
        }
    }

    /**
     * Обновляет Git-установку до commit опубликованного стабильного GitHub Release.
     */
    protected function runStableReleaseGitUpdate(string $repository, string $branch, string $token = ''): array
    {
        $release = $this->fetchUpdateRelease($repository, $token);
        if ($release === null) {
            throw new RuntimeException(return_translation('admin_update_no_releases'));
        }

        $tagName = trim((string)($release['tag_name'] ?? ''));
        $this->validateGitTagName($tagName);

        $previousCommit = trim($this->runCommand('git rev-parse HEAD', ROOT)['stdout']);
        if ($previousCommit === '') {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $this->fetchRemoteBranch($branch);
        $this->fetchReleaseTag($tagName);

        $releaseRef = 'refs/tags/' . $tagName;
        $releaseCommitResult = $this->runCommand(
            'git rev-list -n 1 ' . escapeshellarg($releaseRef),
            ROOT
        );
        $releaseCommit = trim((string)$releaseCommitResult['stdout']);
        if ($releaseCommitResult['exit_code'] !== 0 || preg_match('/^[a-f0-9]{40}$/i', $releaseCommit) !== 1) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $release['commit_hash'] = $releaseCommit;
        if ($previousCommit === $releaseCommit) {
            $this->refreshLastCheckAfterUpdate();

            return [
                'status' => 'success',
                'message' => return_translation('admin_update_already_latest'),
                'release' => $release,
            ];
        }

        $remoteBranchRef = 'refs/remotes/origin/' . $branch;
        $belongsToBranch = $this->runCommand(
            'git merge-base --is-ancestor '
                . escapeshellarg($releaseCommit)
                . ' '
                . escapeshellarg($remoteBranchRef),
            ROOT
        );
        if ($belongsToBranch['exit_code'] !== 0) {
            throw new RuntimeException(return_translation('admin_update_release_not_on_branch'));
        }

        $canFastForward = $this->runCommand(
            'git merge-base --is-ancestor '
                . escapeshellarg($previousCommit)
                . ' '
                . escapeshellarg($releaseCommit),
            ROOT
        );
        if ($canFastForward['exit_code'] !== 0) {
            $releaseIsOlder = $this->runCommand(
                'git merge-base --is-ancestor '
                    . escapeshellarg($releaseCommit)
                    . ' '
                    . escapeshellarg($previousCommit),
                ROOT
            );
            if ($releaseIsOlder['exit_code'] === 0) {
                $this->refreshLastCheckAfterUpdate();

                return [
                    'status' => 'success',
                    'message' => return_translation('admin_update_already_latest'),
                    'release' => $release,
                ];
            }

            throw new RuntimeException(return_translation('admin_update_release_diverged'));
        }

        $manifest = $this->loadGitManifestAtRef($releaseCommit);
        $this->validateUpdateManifest($manifest);
        $releaseVersion = $this->normalizeComparableVersion($this->extractReleaseVersion($release));
        if ($releaseVersion !== '' && $releaseVersion !== (string)($manifest['version'] ?? '')) {
            throw new RuntimeException(return_translation('admin_update_release_version_mismatch'));
        }
        $this->validateGitDiffAgainstRef($releaseCommit, $manifest);
        $this->createPreUpdateBackups();
        $this->siteSettings->setMany(['updater_rollback_commit' => $previousCommit]);

        try {
            $this->installationMutated = true;
            $mergeResult = $this->runCommand(
                'git merge --ff-only ' . escapeshellarg($releaseCommit),
                ROOT
            );
            if ($mergeResult['exit_code'] !== 0) {
                throw new RuntimeException($this->formatCommandError($mergeResult, return_translation('admin_update_pull_failed')));
            }

            $this->restorePreservedGitPaths($previousCommit, $releaseCommit, $manifest);
            $this->runComposerIfNeeded($previousCommit, $releaseCommit);
            $this->runPendingMigrations();
            $this->clearRuntimeCache();
            $this->siteSettings->setMany([
                'updater_last_updated_at' => date('Y-m-d H:i:s'),
                'updater_last_installed_commit' => $releaseCommit,
            ]);
            $this->refreshLastCheckAfterUpdate();
        } catch (\Throwable $exception) {
            log_error_details('Stable update requires snapshot recovery', ['Commit' => $previousCommit], $exception);
            throw $exception;
        }

        return [
            'status' => 'success',
            'message' => return_translation('admin_update_success'),
            'release' => $release,
        ];
    }

    /**
     * Устанавливает Stable-обновление из ZIP-asset для установки без локального Git.
     */
    protected function runStableReleaseUpdate(string $repository, string $token = ''): array
    {
        $release = $this->fetchUpdateRelease($repository, $token);
        if ($release === null) {
            throw new RuntimeException(return_translation('admin_update_no_releases'));
        }

        $remoteVersion = $this->extractReleaseVersion($release);
        $comparison = $this->compareVersions(
            (string)($this->engineRelease['version'] ?? '0.0.0'),
            $remoteVersion
        );
        if ($comparison !== null && $comparison >= 0) {
            $this->refreshLastCheckAfterUpdate();

            return [
                'status' => 'success',
                'message' => return_translation('admin_update_already_latest'),
                'release' => $release,
            ];
        }

        $workspace = ROOT . '/tmp/update-' . date('YmdHis') . '-' . bin2hex(random_bytes(4));
        $archivePath = $workspace . '/package.zip';
        $extractPath = $workspace . '/extract';
        $composerFingerprintBefore = $this->captureDependencyFingerprint();

        try {
            $this->ensureDirectory($workspace);
            $this->ensureDirectory($extractPath);
            $archive = $this->resolveReleaseArchive($release, $repository, false);
            $localGitState = $this->getLocalGitState();
            if (!empty($localGitState['is_git_repo']) && trim((string)($localGitState['commit_hash'] ?? '')) !== '') {
                $this->siteSettings->setMany([
                    'updater_rollback_commit' => (string)$localGitState['commit_hash'],
                ]);
            }

            $this->downloadFile(
                (string)($archive['download_url'] ?? ''),
                $archivePath,
                $this->buildGithubDownloadHeaders($token, (string)($archive['download_mode'] ?? 'direct'))
            );

            $packageRoot = $this->extractArchive($archivePath, $extractPath);
            $manifest = $this->loadUpdateManifest($packageRoot);
            $this->validateUpdateManifest($manifest, $packageRoot);
            $this->assertPackageComposerReady($packageRoot, $composerFingerprintBefore);
            $this->createPreUpdateBackups();
            $this->ensureLocalConfigExists();
            $this->installationMutated = true;
            $this->copyPackageToRoot($packageRoot, ROOT, $manifest);

            $this->runComposerIfDependencyFilesChanged($composerFingerprintBefore);
            $this->runPendingMigrations();
            $this->clearRuntimeCache();
            $this->siteSettings->setMany([
                'updater_last_updated_at' => date('Y-m-d H:i:s'),
                'updater_last_installed_commit' => '',
            ]);
            $this->refreshLastCheckAfterUpdate();

            return [
                'status' => 'success',
                'message' => return_translation('admin_update_success'),
                'release' => $release,
            ];
        } finally {
            $this->deleteDirectory($workspace);
        }
    }

    /**
     * Возвращает git-установку к коммиту, сохранённому перед последним обновлением.
     */
    public function runRollback(): array
    {
        throw new RuntimeException('Restore a failed update offline with php bin/recover-update.php --confirm. Code-only rollback after database migrations is unsafe.');
    }

    /**
     * Пытается получить релиз GitHub, но не валит git-based проверку, если API недоступен.
     */
    protected function tryFetchLatestRelease(string $repository, string $token, string $branch): ?array
    {
        if ($repository === '') {
            return null;
        }

        try {
            return $this->fetchLatestRelease($repository, $token);
        } catch (\Throwable) {
            return [
                'name' => $branch,
                'tag_name' => '',
                'html_url' => 'https://github.com/' . $repository . '/tree/' . rawurlencode($branch),
                'published_at' => '',
                'body' => '',
                'excerpt' => return_translation('admin_update_source_repo_fallback'),
                'zipball_url' => '',
                'assets' => [],
            ];
        }
    }

    /**
     * Обновляет сохранённый результат последней проверки после попытки обновления.
     */
    protected function refreshLastCheckAfterUpdate(): void
    {
        try {
            $this->checkForUpdates();
        } catch (\Throwable) {
            $this->siteSettings->setMany([
                'updater_last_check_payload' => '',
                'updater_last_checked_at' => '',
            ]);
        }
    }

    /**
     * Перечитывает локальный metadata-файл движка после обновления файлов.
     */
    protected function reloadEngineRelease(): void
    {
        $payload = require CONFIG . '/version.php';

        $this->engineRelease = is_array($payload) ? $payload : [];
    }

    /**
     * Получает информацию о последнем релизе репозитория через GitHub API.
     */
    protected function fetchLatestRelease(string $repository, string $token = ''): array
    {
        $response = $this->httpGet(
            $this->buildGithubApiUrl($repository, '/releases/latest'),
            $this->buildGithubHeaders($token)
        );
        $payload = json_decode($response['body'], true);

        if ($response['status_code'] === 404) {
            return $this->fetchLatestTag($repository, $token);
        }

        if (!is_array($payload)) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        if ($response['status_code'] < 200 || $response['status_code'] >= 300) {
            throw new RuntimeException(return_translation('admin_update_release_fetch_failed') . ' ' . $payload['message']);
        }

        return [
            'name' => trim((string)($payload['name'] ?? '')),
            'tag_name' => trim((string)($payload['tag_name'] ?? '')),
            'html_url' => trim((string)($payload['html_url'] ?? '')),
            'published_at' => trim((string)($payload['published_at'] ?? '')),
            'body' => trim((string)($payload['body'] ?? '')),
            'excerpt' => $this->buildReleaseExcerpt((string)($payload['body'] ?? '')),
            'zipball_url' => trim((string)($payload['zipball_url'] ?? '')),
            'assets' => $this->normalizeReleaseAssets($payload['assets'] ?? []),
        ];
    }

    /**
     * Возвращает последний стабильный Release без fallback на tags или ветки.
     */
    protected function fetchLatestStableRelease(string $repository, string $token = ''): ?array
    {
        $response = $this->httpGet(
            $this->buildGithubApiUrl($repository, '/releases/latest'),
            $this->buildGithubHeaders($token)
        );
        $payload = json_decode($response['body'], true);

        if ($response['status_code'] === 404) {
            return null;
        }
        if ($response['status_code'] < 200 || $response['status_code'] >= 300 || !is_array($payload)) {
            $message = is_array($payload) ? (string)($payload['message'] ?? '') : '';
            throw new RuntimeException(trim(return_translation('admin_update_release_fetch_failed') . ' ' . $message));
        }
        if (!empty($payload['draft']) || !empty($payload['prerelease'])
            || $this->isPrereleaseVersion((string)($payload['tag_name'] ?? ''))) {
            return null;
        }

        return [
            'name' => trim((string)($payload['name'] ?? '')),
            'tag_name' => trim((string)($payload['tag_name'] ?? '')),
            'html_url' => trim((string)($payload['html_url'] ?? '')),
            'published_at' => trim((string)($payload['published_at'] ?? '')),
            'body' => trim((string)($payload['body'] ?? '')),
            'excerpt' => $this->buildReleaseExcerpt((string)($payload['body'] ?? '')),
            'zipball_url' => '',
            'assets' => $this->normalizeReleaseAssets($payload['assets'] ?? []),
        ];
    }

    /** Published beta releases never fall back to an arbitrary branch or draft. */
    protected function fetchUpdateRelease(string $repository, string $token = ''): ?array
    {
        $best = $this->fetchLatestStableRelease($repository, $token);
        if ($this->resolveUpdateChannel($this->siteSettings->all()) !== 'beta') {
            return $best;
        }

        // /latest excludes prereleases. Include the published releases list as well.
        for ($page = 1; $page <= 10; $page++) {
            $response = $this->httpGet(
                $this->buildGithubApiUrl($repository, '/releases?per_page=100&page=' . $page),
                $this->buildGithubHeaders($token)
            );
            $releases = json_decode($response['body'], true);
            if ($response['status_code'] < 200 || $response['status_code'] >= 300
                || !is_array($releases) || !array_is_list($releases)) {
                throw new RuntimeException(return_translation('admin_update_release_fetch_failed'));
            }
            foreach ($releases as $release) {
                if (!is_array($release) || !empty($release['draft'])
                    || trim((string)($release['published_at'] ?? '')) === ''
                    || trim((string)($release['tag_name'] ?? '')) === '') {
                    continue;
                }
                $version = $this->extractReleaseVersion($release);
                if ($this->normalizeComparableVersion($version) === '') continue;
                $comparison = $best !== null ? $this->compareVersions($this->extractReleaseVersion($best), $version) : -1;
                if ($comparison !== null && $comparison >= 0) continue;
                $best = [
                    'name' => trim((string)($release['name'] ?? '')),
                    'tag_name' => trim((string)$release['tag_name']),
                    'html_url' => trim((string)($release['html_url'] ?? '')),
                    'published_at' => trim((string)$release['published_at']),
                    'prerelease' => !empty($release['prerelease']) || $this->isPrereleaseVersion($version),
                    'body' => trim((string)($release['body'] ?? '')),
                    'excerpt' => $this->buildReleaseExcerpt((string)($release['body'] ?? '')),
                    'zipball_url' => '',
                    'assets' => $this->normalizeReleaseAssets($release['assets'] ?? []),
                ];
            }
            if (count($releases) < 100) break;
        }
        return $best;
    }

    protected function isPrereleaseVersion(string $version): bool
    {
        return preg_match('~^\d+(?:\.\d+)+-~', $this->normalizeComparableVersion($version)) === 1;
    }

    /** Nonblocking locks prevent concurrent notification polls from duplicating checks. */
    protected function acquireAutomaticCheckLock(string $scope): mixed
    {
        $directory = STORAGE . '/update-checks';
        if (!is_dir($directory) && !@mkdir($directory, 0775, true) && !is_dir($directory)) return null;
        $handle = @fopen($directory . '/' . hash('sha256', $scope) . '.lock', 'c');
        if ($handle === false) return null;
        if (!flock($handle, LOCK_EX | LOCK_NB)) {
            fclose($handle);
            return null;
        }
        return $handle;
    }

    protected function releaseAutomaticCheckLock(mixed $handle): void
    {
        if (is_resource($handle)) {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    /**
     * Если GitHub Release не опубликован, берёт последний доступный тег.
     */
    protected function fetchLatestTag(string $repository, string $token = ''): array
    {
        $response = $this->httpGet(
            $this->buildGithubApiUrl($repository, '/tags'),
            $this->buildGithubHeaders($token)
        );
        $payload = json_decode($response['body'], true);

        if ($response['status_code'] === 404) {
            throw new RuntimeException(return_translation('admin_update_repository_not_found'));
        }

        if ($response['status_code'] < 200 || $response['status_code'] >= 300 || !is_array($payload)) {
            $message = is_array($payload) ? (string)($payload['message'] ?? '') : '';
            throw new RuntimeException(trim(return_translation('admin_update_release_fetch_failed') . ' ' . $message));
        }

        $latestTag = $payload[0] ?? null;
        if (!is_array($latestTag) || trim((string)($latestTag['name'] ?? '')) === '') {
            throw new RuntimeException(return_translation('admin_update_no_releases_or_tags'));
        }

        $tagName = trim((string)($latestTag['name'] ?? ''));

        return [
            'name' => $tagName,
            'tag_name' => $tagName,
            'html_url' => 'https://github.com/' . $repository . '/releases/tag/' . rawurlencode($tagName),
            'published_at' => '',
            'body' => '',
            'excerpt' => return_translation('admin_update_using_tag_fallback'),
            'zipball_url' => $this->buildGithubApiUrl($repository, '/zipball/' . rawurlencode($tagName)),
            'assets' => [],
        ];
    }

    /**
     * Загружает metadata из config/version.php выбранной ветки GitHub.
     */
    protected function fetchRemoteVersionMetadata(string $repository, string $branch, string $token = ''): array
    {
        if (trim($token) === '') {
            $response = $this->httpGet(
                $this->buildGithubRawUrl($repository, $branch, 'config/version.php'),
                [
                    'Accept: text/plain',
                    'User-Agent: FIREBALL_CMS-Updater',
                ]
            );

            if ($response['status_code'] === 404) {
                throw new RuntimeException(return_translation('admin_update_repository_not_found'));
            }
            if ($response['status_code'] < 200 || $response['status_code'] >= 300) {
                throw new RuntimeException(return_translation('admin_update_release_fetch_failed'));
            }

            return $this->parseVersionPhpPayload((string)$response['body']);
        }

        $response = $this->httpGet(
            $this->buildGithubApiUrl($repository, '/contents/config/version.php?ref=' . rawurlencode($branch)),
            $this->buildGithubHeaders($token)
        );
        $payload = json_decode($response['body'], true);

        if ($response['status_code'] === 404) {
            throw new RuntimeException(return_translation('admin_update_repository_not_found'));
        }

        if ($response['status_code'] < 200 || $response['status_code'] >= 300 || !is_array($payload)) {
            $message = is_array($payload) ? (string)($payload['message'] ?? '') : '';
            throw new RuntimeException(trim(return_translation('admin_update_release_fetch_failed') . ' ' . $message));
        }

        $content = (string)($payload['content'] ?? '');
        $encoding = trim((string)($payload['encoding'] ?? ''));
        if ($content === '' || $encoding !== 'base64') {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $decodedContent = base64_decode(str_replace(["\r", "\n"], '', $content), true);
        if ($decodedContent === false || trim($decodedContent) === '') {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        return $this->parseVersionPhpPayload($decodedContent);
    }

    /**
     * Преобразует содержимое config/version.php в metadata без исполнения удалённого PHP-кода.
     */
    protected function parseVersionPhpPayload(string $contents): array
    {
        $contents = $this->stripPhpComments($contents);
        if (trim($contents) === '' || !str_contains($contents, 'return')) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $version = $this->extractPhpArrayStringValue($contents, 'version');
        if ($version === '') {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        return [
            'name' => $this->extractPhpArrayStringValue($contents, 'name') ?: 'FIREBALL_CMS',
            'version' => $version,
            'released_at' => $this->extractPhpArrayStringValue($contents, 'released_at'),
            'summary' => $this->extractPhpArrayStringValue($contents, 'summary'),
            'changes' => $this->extractPhpArrayStringList($contents, 'changes'),
        ];
    }

    /**
     * Убирает PHP-комментарии перед безопасным разбором metadata.
     */
    protected function stripPhpComments(string $contents): string
    {
        $tokens = token_get_all($contents);
        $clean = '';

        foreach ($tokens as $token) {
            if (is_array($token)) {
                if (in_array($token[0], [T_COMMENT, T_DOC_COMMENT], true)) {
                    continue;
                }

                $clean .= $token[1];
                continue;
            }

            $clean .= $token;
        }

        return $clean;
    }

    /**
     * Извлекает строковое значение верхнего уровня из простого PHP array metadata-файла.
     */
    protected function extractPhpArrayStringValue(string $contents, string $key): string
    {
        $quotedKey = preg_quote($key, '~');
        if (preg_match('~[\'"]' . $quotedKey . '[\'"]\s*=>\s*([\'"])((?:\\\\.|(?!\1).)*)\1~su', $contents, $matches) !== 1) {
            return '';
        }

        return trim(stripcslashes((string)$matches[2]));
    }

    /**
     * Извлекает список строк из простого array-значения metadata-файла.
     */
    protected function extractPhpArrayStringList(string $contents, string $key): array
    {
        $quotedKey = preg_quote($key, '~');
        if (preg_match('~[\'"]' . $quotedKey . '[\'"]\s*=>\s*\[(.*?)\]\s*,?~su', $contents, $matches) !== 1) {
            return [];
        }

        preg_match_all('~([\'"])((?:\\\\.|(?!\1).)*)\1~su', (string)$matches[1], $stringMatches);

        return array_values(array_filter(array_map(static function (string $value): string {
            return trim(stripcslashes($value));
        }, $stringMatches[2] ?? [])));
    }

    /**
     * Собирает псевдо-release для обновления напрямую из ветки репозитория.
     */
    protected function buildBranchRelease(
        string $repository,
        string $branch,
        array $versionFile,
        string $remoteCommitHash = '',
        string $token = ''
    ): array
    {
        $changes = array_values(array_filter(array_map('trim', is_array($versionFile['changes'] ?? null) ? $versionFile['changes'] : [])));
        $body = implode("\n", $changes);
        $excerpt = trim((string)($versionFile['summary'] ?? ''));

        if ($excerpt === '' && $body !== '') {
            $excerpt = $this->buildReleaseExcerpt($body);
        }
        if ($excerpt === '') {
            $excerpt = return_translation('admin_update_source_repo_fallback');
        }

        return [
            'name' => trim((string)($versionFile['version'] ?? '')) !== ''
                ? trim((string)$versionFile['version'])
                : ($remoteCommitHash !== '' ? substr($remoteCommitHash, 0, 7) : $branch),
            'tag_name' => '',
            'html_url' => 'https://github.com/' . $repository . '/tree/' . rawurlencode($branch),
            'published_at' => trim((string)($versionFile['released_at'] ?? '')),
            'body' => $body,
            'excerpt' => $excerpt,
            'zipball_url' => trim($token) !== ''
                ? $this->buildGithubApiUrl($repository, '/zipball/' . rawurlencode($branch))
                : $this->buildGithubCodeloadUrl($repository, $branch),
            'assets' => [],
        ];
    }

    /**
     * Получает состояние локальной ветки относительно head выбранной ветки на GitHub.
     */
    protected function fetchBranchState(string $repository, string $branch, string $localCommitHash, string $token = ''): array
    {
        if (trim($token) === '') {
            $remoteCommitHash = $this->fetchPublicBranchHead($repository, $branch);
            if ($remoteCommitHash !== '') {
                return $this->buildArchiveBranchState($localCommitHash, $remoteCommitHash);
            }
        }

        $headers = $this->buildGithubHeaders($token);
        $branchResponse = $this->httpGet(
            $this->buildGithubApiUrl($repository, '/commits/' . rawurlencode($branch)),
            $headers
        );
        $branchPayload = json_decode($branchResponse['body'], true);

        if ($branchResponse['status_code'] === 404) {
            throw new RuntimeException(return_translation('admin_update_repository_not_found'));
        }

        if ($branchResponse['status_code'] < 200 || $branchResponse['status_code'] >= 300 || !is_array($branchPayload)) {
            if ($this->isGithubRateLimitResponse($branchResponse['status_code'], $branchPayload)) {
                return [
                    'status' => 'unknown',
                    'remote_commit_hash' => '',
                ];
            }

            $message = is_array($branchPayload) ? (string)($branchPayload['message'] ?? '') : '';
            throw new RuntimeException(trim(return_translation('admin_update_branch_fetch_failed') . ' ' . $message));
        }

        $remoteCommitHash = trim((string)($branchPayload['sha'] ?? ''));
        if ($remoteCommitHash === '') {
            throw new RuntimeException(return_translation('admin_update_branch_fetch_failed'));
        }

        if ($localCommitHash === '') {
            return [
                'status' => 'no_local_commit',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        if ($localCommitHash === $remoteCommitHash) {
            return [
                'status' => 'identical',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        $compareResponse = $this->httpGet(
            $this->buildGithubApiUrl($repository, '/compare/' . rawurlencode($localCommitHash) . '...' . rawurlencode($branch)),
            $headers
        );
        $comparePayload = json_decode($compareResponse['body'], true);

        if ($compareResponse['status_code'] >= 200 && $compareResponse['status_code'] < 300 && is_array($comparePayload)) {
            return [
                'status' => trim((string)($comparePayload['status'] ?? 'unknown')) ?: 'unknown',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        return [
            'status' => 'unknown',
            'remote_commit_hash' => $remoteCommitHash,
        ];
    }

    /**
     * Получает head публичной ветки без GitHub REST API и его общего IP-лимита.
     */
    protected function fetchPublicBranchHead(string $repository, string $branch): string
    {
        try {
            $response = $this->httpGet(
                'https://github.com/' . $repository . '.git/info/refs?service=git-upload-pack',
                [
                    'Accept: application/x-git-upload-pack-advertisement',
                    'User-Agent: FIREBALL_CMS-Updater',
                ]
            );
        } catch (\Throwable) {
            return '';
        }

        if ($response['status_code'] < 200 || $response['status_code'] >= 300) {
            return '';
        }

        $ref = 'refs/heads/' . $branch;
        if (preg_match(
            '~([a-f0-9]{40})\s+' . preg_quote($ref, '~') . '(?:\x00|[\r\n])~i',
            (string)$response['body'],
            $matches
        ) !== 1) {
            return '';
        }

        return mb_strtolower((string)$matches[1]);
    }

    /**
     * Для ZIP-установки отличие от сохранённого commit означает новую ревизию ветки.
     */
    protected function buildArchiveBranchState(string $localCommitHash, string $remoteCommitHash): array
    {
        $localCommitHash = mb_strtolower(trim($localCommitHash));
        $remoteCommitHash = mb_strtolower(trim($remoteCommitHash));

        if ($localCommitHash === '') {
            return [
                'status' => 'no_local_commit',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        return [
            'status' => hash_equals($localCommitHash, $remoteCommitHash) ? 'identical' : 'behind',
            'remote_commit_hash' => $remoteCommitHash,
        ];
    }

    /**
     * Отличает исчерпание квоты GitHub от ошибок репозитория и ветки.
     */
    protected function isGithubRateLimitResponse(int $statusCode, mixed $payload): bool
    {
        if (!in_array($statusCode, [403, 429], true)) {
            return false;
        }

        $message = is_array($payload) ? mb_strtolower((string)($payload['message'] ?? '')) : '';

        return str_contains($message, 'rate limit');
    }

    /**
     * Обновляет локальные refs для целевой ветки и тегов.
     */
    protected function fetchRemoteBranch(string $branch): void
    {
        $fetchResult = $this->runCommand(
            'git fetch --tags origin ' . escapeshellarg($branch),
            ROOT
        );

        if ($fetchResult['exit_code'] !== 0) {
            throw new RuntimeException($this->formatCommandError($fetchResult, return_translation('admin_update_branch_fetch_failed')));
        }
    }

    protected function validateGitTagName(string $tagName): void
    {
        if ($tagName === ''
            || strlen($tagName) > 200
            || str_starts_with($tagName, '-')
            || str_contains($tagName, '..')
            || str_contains($tagName, '@{')
            || preg_match('#[\s\\\\~^:?*\[]#', $tagName) === 1
            || str_ends_with($tagName, '.')
            || str_ends_with($tagName, '/')
        ) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $check = $this->runCommand(
            'git check-ref-format ' . escapeshellarg('refs/tags/' . $tagName),
            ROOT
        );
        if ($check['exit_code'] !== 0) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }
    }

    protected function fetchReleaseTag(string $tagName): void
    {
        $ref = 'refs/tags/' . $tagName;
        $result = $this->runCommand(
            'git fetch origin ' . escapeshellarg($ref . ':' . $ref),
            ROOT
        );
        if ($result['exit_code'] !== 0) {
            throw new RuntimeException($this->formatCommandError($result, return_translation('admin_update_branch_fetch_failed')));
        }
    }

    /**
     * Определяет состояние локальной ветки относительно origin/branch после git fetch.
     */
    protected function getBranchStateFromGit(string $branch): array
    {
        $remoteRef = 'refs/remotes/origin/' . $branch;
        $remoteCommitResult = $this->runCommand(
            'git rev-parse --verify ' . escapeshellarg($remoteRef),
            ROOT
        );

        if ($remoteCommitResult['exit_code'] !== 0) {
            throw new RuntimeException(return_translation('admin_update_branch_fetch_failed'));
        }

        $remoteCommitHash = trim($remoteCommitResult['stdout']);
        $localCommitHash = trim($this->runCommand('git rev-parse HEAD', ROOT)['stdout']);

        if ($localCommitHash === '') {
            return [
                'status' => 'no_local_commit',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        if ($localCommitHash === $remoteCommitHash) {
            return [
                'status' => 'identical',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        $mergeBaseResult = $this->runCommand(
            'git merge-base HEAD ' . escapeshellarg($remoteRef),
            ROOT
        );
        $mergeBase = trim($mergeBaseResult['stdout']);

        if ($mergeBase !== '' && $mergeBase === $localCommitHash) {
            return [
                'status' => 'behind',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        if ($mergeBase !== '' && $mergeBase === $remoteCommitHash) {
            return [
                'status' => 'ahead',
                'remote_commit_hash' => $remoteCommitHash,
            ];
        }

        return [
            'status' => 'diverged',
            'remote_commit_hash' => $remoteCommitHash,
        ];
    }

    /**
     * Возвращает список zip-asset'ов релиза в удобном формате.
     */
    protected function normalizeReleaseAssets($assets): array
    {
        if (!is_array($assets)) {
            return [];
        }

        $normalized = [];

        foreach ($assets as $asset) {
            if (!is_array($asset)) {
                continue;
            }

            $normalized[] = [
                'name' => trim((string)($asset['name'] ?? '')),
                'download_url' => trim((string)($asset['browser_download_url'] ?? '')),
                'api_url' => trim((string)($asset['url'] ?? '')),
                'content_type' => trim((string)($asset['content_type'] ?? '')),
            ];
        }

        return $normalized;
    }

    /**
     * Выбирает ZIP-архив, который будет использоваться для обновления.
     */
    protected function resolveReleaseArchive(array $release, string $repository, bool $allowZipball = true): array
    {
        foreach ($release['assets'] ?? [] as $asset) {
            $name = trim((string)($asset['name'] ?? ''));
            $downloadUrl = trim((string)($asset['download_url'] ?? ''));
            $apiUrl = trim((string)($asset['api_url'] ?? ''));

            if ($name !== '' && preg_match('/\.zip$/i', $name) === 1) {
                return [
                    'name' => $name,
                    'download_url' => $downloadUrl !== '' ? $downloadUrl : $apiUrl,
                    'download_mode' => $downloadUrl === '' && $apiUrl !== '' ? 'release_asset_api' : 'direct',
                ];
            }
        }

        $zipballUrl = trim((string)($release['zipball_url'] ?? ''));
        if ($allowZipball && $zipballUrl !== '') {
            $tagName = trim((string)($release['tag_name'] ?? 'release'));
            $downloadMode = str_starts_with($zipballUrl, 'https://api.github.com/')
                ? 'repository_zipball_api'
                : 'direct';

            return [
                'name' => $tagName . '.zip',
                'download_url' => $zipballUrl,
                'download_mode' => $downloadMode,
            ];
        }

        throw new RuntimeException(return_translation('admin_update_release_asset_missing'));
    }

    /**
     * Выполняет GET-запрос и возвращает тело и HTTP-код.
     */
    protected function assertGithubTransferUrl(string $url): void
    {
        $parts = parse_url($url);
        $host = strtolower((string)($parts['host'] ?? ''));
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass'])
            || (int)($parts['port'] ?? 443) !== 443
            || !in_array($host, ['api.github.com', 'github.com', 'codeload.github.com', 'release-assets.githubusercontent.com', 'objects.githubusercontent.com', 'raw.githubusercontent.com'], true)) {
            throw new RuntimeException('Untrusted GitHub transfer URL.');
        }
    }

    /** Bounded HTTPS transfer; check every redirect before sending another request. */
    protected function githubTransfer(string $url, array $headers, $output, int $limit, int $timeout): array
    {
        if (!function_exists('curl_init')) throw new RuntimeException('cURL is required for safe GitHub updates.');
        $originalHost = parse_url($url, PHP_URL_HOST);
        for ($redirect = 0; $redirect <= 3; $redirect++) {
            $this->assertGithubTransferUrl($url);
            $requestHeaders = $headers;
            if (parse_url($url, PHP_URL_HOST) !== $originalHost) {
                $requestHeaders = array_values(array_filter($headers, static fn(string $header): bool => !preg_match('/^(?:authorization|cookie):/i', $header)));
            }
            if (is_resource($output)) { rewind($output); if (!ftruncate($output, 0)) throw new RuntimeException('Unable to reset download file.'); }
            $body = '';
            $bytes = 0;
            $location = '';
            $ch = curl_init($url);
            try {
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => false,
                    CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                    CURLOPT_HTTPHEADER => $requestHeaders,
                    CURLOPT_TIMEOUT => $timeout,
                    CURLOPT_CONNECTTIMEOUT => min(10, $timeout),
                    CURLOPT_MAXFILESIZE_LARGE => $limit,
                    CURLOPT_HEADERFUNCTION => static function ($handle, string $line) use (&$location): int {
                        if (str_starts_with(strtolower($line), 'location:')) $location = trim(substr($line, 9));
                        return strlen($line);
                    },
                    CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use (&$body, &$bytes, $output, $limit): int {
                        $length = strlen($chunk);
                        if ($bytes + $length > $limit) return 0;
                        $bytes += $length;
                        if (is_resource($output)) return fwrite($output, $chunk) ?: 0;
                        $body .= $chunk;
                        return $length;
                    },
                ]);
                $raw = curl_exec($ch);
                $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $error = curl_error($ch);
            } finally { curl_close($ch); }
            if ($raw === false) throw new RuntimeException('GitHub transfer failed or exceeded its size limit: ' . $error);
            if (is_string($raw) && $body === '' && !is_resource($output)) $body = $raw;
            if (strlen($body) > $limit) throw new RuntimeException('GitHub response exceeded its size limit.');
            if (in_array($status, [301, 302, 303, 307, 308], true)) {
                if ($location === '' || $redirect === 3) throw new RuntimeException('Invalid GitHub redirect.');
                $url = str_starts_with($location, '/') && !str_starts_with($location, '//')
                    ? 'https://' . parse_url($url, PHP_URL_HOST) . $location : $location;
                continue;
            }
            return ['body' => $body, 'status_code' => $status];
        }
        throw new RuntimeException('Too many GitHub redirects.');
    }

    protected function httpGet(string $url, array $headers = []): array
    {
        return $this->githubTransfer($url, $headers, null, 2097152, 20);
    }

    protected function downloadFile(string $url, string $destination, array $headers = []): void
    {
        $handle = @fopen($destination, 'wb');
        if (!is_resource($handle)) throw new RuntimeException('Unable to create download file.');
        $successful = false;
        try {
            $result = $this->githubTransfer($url, $headers, $handle, 157286400, 120);
            if ($result['status_code'] < 200 || $result['status_code'] >= 300 || !fflush($handle)) throw new RuntimeException('GitHub download failed: HTTP ' . $result['status_code']);
            $successful = true;
        } finally {
            fclose($handle);
            if (!$successful) @unlink($destination);
        }
    }

    protected function extractArchive(string $archivePath, string $extractPath): string
    {
        $zip = new \ZipArchive();
        if ($zip->open($archivePath) !== true) {
            throw new RuntimeException(return_translation('admin_update_extract_failed'));
        }

        try {
            $this->validateArchiveEntries($zip);
            if (!$zip->extractTo($extractPath)) throw new RuntimeException(return_translation('admin_update_extract_failed'));
        } finally { $zip->close(); }

        return $this->resolvePackageRoot($extractPath);
    }

    /**
     * Проверяет ZIP перед распаковкой, чтобы архив не мог писать вне workspace.
     */
    protected function validateArchiveEntries(\ZipArchive $zip): void
    {
        if ($zip->numFiles > 20000) throw new RuntimeException('Too many archive entries.');
        $total = 0;
        $names = [];
        for ($index = 0; $index < $zip->numFiles; $index++) {
            $stat = $zip->statIndex($index);
            $name = (string)$zip->getNameIndex($index);
            $normalized = str_replace('\\', '/', $name);
            $total += (int)($stat['size'] ?? 0);
            $attributes = 0;
            $system = 0;
            $zip->getExternalAttributesIndex($index, $system, $attributes);
            $type = ($attributes >> 16) & 0170000;
            if ($normalized === '' || preg_match('/[\x00-\x1f\x7f]/', $name) || str_contains($name, '\\') || str_starts_with($normalized, '/')
                || preg_match('~^[A-Za-z]:~', $normalized) || array_intersect(explode('/', $normalized), ['..', '.'])
                || isset($names[$normalized]) || ($type !== 0 && !in_array($type, [0100000, 0040000], true))
                || $total > 536870912 || (int)($stat['size'] ?? 0) > 157286400
                || (int)($stat['size'] ?? 0) > max(1048576, (int)($stat['comp_size'] ?? 0) * 200)) {
                throw new RuntimeException('Unsafe or oversized update archive.');
            }
            $names[$normalized] = true;
        }
        $free = @disk_free_space(ROOT . '/tmp');
        if ($free !== false && $free < $total + 104857600) throw new RuntimeException('Insufficient free space for update extraction.');
    }

    /**
     * Определяет корневую директорию распакованного релиза.
     */
    protected function resolvePackageRoot(string $extractPath): string
    {
        $currentPath = $extractPath;

        for ($depth = 0; $depth < 5; $depth++) {
            if ($this->looksLikeApplicationRoot($currentPath)) {
                return $currentPath;
            }

            $items = $this->listExtractedItems($currentPath);
            if (count($items) !== 1) {
                break;
            }

            $candidate = $currentPath . '/' . $items[0];
            if (!is_dir($candidate)) {
                break;
            }

            $currentPath = $candidate;
        }

        if ($this->looksLikeApplicationRoot($currentPath)) {
            return $currentPath;
        }

        return $extractPath;
    }

    /**
     * Возвращает значимые элементы распакованного архива без служебного мусора macOS.
     */
    protected function listExtractedItems(string $path): array
    {
        return array_values(array_filter(scandir($path) ?: [], function (string $item): bool {
            if ($item === '.' || $item === '..') {
                return false;
            }

            return !$this->shouldSkipExtractedPath($item);
        }));
    }

    /**
     * Определяет, похожа ли директория на корень пакета CMS.
     */
    protected function looksLikeApplicationRoot(string $path): bool
    {
        $requiredPaths = [
            'app',
            'config',
            'core',
            'public',
        ];

        foreach ($requiredPaths as $requiredPath) {
            if (!is_dir($path . '/' . $requiredPath)) {
                return false;
            }
        }

        return is_file($path . '/composer.json') || is_file($path . '/README.md');
    }

    /**
     * Обеспечивает наличие локального конфига до замены файлов релиза.
     */
    protected function ensureLocalConfigExists(): void
    {
        $localConfigPath = CONFIG . '/config.local.php';
        if (is_file($localConfigPath)) {
            return;
        }

        $payload = [
            'DEBUG' => DEBUG,
            'LAYOUT' => LAYOUT,
            'THEME' => THEME,
            'PATH' => PATH,
            'UPLOADS' => UPLOADS,
            'SITE_NAME' => SITE_NAME,
            'CHAT_ENCRYPTION_KEY' => CHAT_ENCRYPTION_KEY,
            'APP_TIMEZONE' => APP_TIMEZONE,
            'UPDATE_CHANNEL' => defined('UPDATE_CHANNEL') ? UPDATE_CHANNEL : 'stable',
            'TRUSTED_PROXIES' => defined('TRUSTED_PROXIES') ? TRUSTED_PROXIES : [],
            'MULTILANGS' => MULTILANGS,
            'LANGS' => LANGS,
            'DB_SETTINGS' => DB_SETTINGS,
            'MAIL_SETTINGS' => MAIL_SETTINGS,
            'PAGINATION_SETTINGS' => PAGINATION_SETTINGS,
        ];

        $content = "<?php\n\nreturn " . var_export($payload, true) . ";\n";
        if (@file_put_contents($localConfigPath, $content) === false) {
            throw new RuntimeException(return_translation('admin_update_local_config_write_failed'));
        }
    }

    /**
     * Копирует файлы из распакованного релиза в корень приложения, сохраняя локальные данные.
     */
    protected function copyPackageToRoot(string $packageRoot, string $targetRoot, array $manifest): void
    {
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($packageRoot, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            if ($item->isLink()) {
                continue;
            }

            $sourcePath = $item->getPathname();
            $relativePath = str_replace('\\', '/', substr($sourcePath, strlen($packageRoot) + 1));

            if (
                $relativePath === ''
                || $this->shouldSkipExtractedPath($relativePath)
                || $this->shouldPreservePath($relativePath, $manifest)
                || !$this->shouldUpdatePath($relativePath, $manifest)
            ) {
                continue;
            }

            $targetPath = $targetRoot . '/' . $relativePath;
            $this->assertUpdateDestination($targetRoot, $relativePath);

            if ($item->isDir()) {
                $this->ensureDirectory($targetPath);
                continue;
            }

            $this->ensureDirectory(dirname($targetPath));
            $parent = realpath(dirname($targetPath));
            $root = realpath($targetRoot);
            if ($parent === false || $root === false || ($parent !== $root && !str_starts_with($parent, $root . DIRECTORY_SEPARATOR)) || is_link($targetPath)) {
                throw new RuntimeException('Unsafe update destination: ' . $relativePath);
            }
            $temporary = tempnam($parent, '.fbl-update-');
            try {
                if ($temporary === false || !copy($sourcePath, $temporary) || !chmod($temporary, fileperms($sourcePath) & 0777) || !rename($temporary, $targetPath)) {
                    throw new RuntimeException(return_translation('admin_update_copy_failed') . ' ' . $relativePath);
                }
            } finally { if (is_string($temporary) && is_file($temporary)) @unlink($temporary); }
        }
        foreach ((array)($manifest['remove'] ?? []) as $relativePath) {
            $this->assertUpdateDestination($targetRoot, $relativePath);
            $target = $targetRoot . '/' . $relativePath;
            if (is_dir($target)) throw new RuntimeException('Update removal must name an individual file.');
            if (is_file($target) && !unlink($target)) throw new RuntimeException('Unable to remove obsolete file: ' . $relativePath);
        }
    }

    protected function assertUpdateDestination(string $targetRoot, string $relativePath): void
    {
        $root = realpath($targetRoot);
        if ($root === false || $relativePath === '' || str_starts_with($relativePath, '/')
            || preg_match('/[\x00-\x1f\x7f\\\\]/', $relativePath) || str_contains($relativePath, ':')
            || array_intersect(explode('/', $relativePath), ['..', '.', ''])) {
            throw new RuntimeException('Unsafe update destination.');
        }
        $current = $root;
        foreach (explode('/', $relativePath) as $segment) {
            $current .= DIRECTORY_SEPARATOR . $segment;
            if (is_link($current)) throw new RuntimeException('Symbolic link in update destination: ' . $relativePath);
            if (file_exists($current)) {
                $resolved = realpath($current);
                if ($resolved === false || !str_starts_with($resolved, $root . DIRECTORY_SEPARATOR)) {
                    throw new RuntimeException('Unsafe update destination: ' . $relativePath);
                }
            }
        }
    }

    /**
     * Возвращает true для путей, которые нельзя перезаписывать релизом.
     */
    protected function shouldPreservePath(string $relativePath, array $manifest = []): bool
    {
        $relativePath = ltrim(str_replace('\\', '/', $relativePath), '/');

        $preservePrefixes = [
            '.git',
            'tmp',
            'storage',
            'uploads',
            'public/uploads',
            'themes/custom',
            ...array_map(
                static fn($path): string => trim(str_replace('\\', '/', (string)$path), '/'),
                (array)($manifest['protected'] ?? [])
            ),
        ];

        foreach ($preservePrefixes as $prefix) {
            if ($relativePath === $prefix || str_starts_with($relativePath, $prefix . '/')) {
                return true;
            }
        }

        return in_array($relativePath, ['config/config.local.php'], true);
    }

    protected function isDevelopmentPath(string $path): bool
    {
        foreach (['docs', 'tests', 'tools', 'dist', '.github', 'README.md', 'LICENSE'] as $prefix) {
            if ($path === $prefix || str_starts_with($path, $prefix . '/')) return true;
        }
        return false;
    }

    protected function shouldUpdatePath(string $relativePath, array $manifest): bool
    {
        $relativePath = trim(str_replace('\\', '/', $relativePath), '/');
        foreach ((array)($manifest['update'] ?? []) as $allowedPath) {
            $allowedPath = trim(str_replace('\\', '/', (string)$allowedPath), '/');
            if ($allowedPath !== '' && ($relativePath === $allowedPath || str_starts_with($relativePath, $allowedPath . '/'))) {
                return true;
            }
        }

        return false;
    }

    protected function loadUpdateManifest(string $packageRoot): array
    {
        $path = rtrim($packageRoot, '/') . '/update.json';
        if (!is_file($path)) {
            throw new RuntimeException('Update manifest update.json is missing.');
        }

        $payload = json_decode((string)file_get_contents($path), true);
        if (!is_array($payload) || json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('Update manifest update.json is invalid.');
        }

        return $payload;
    }

    protected function validateUpdateManifest(array $manifest, ?string $packageRoot = null): void
    {
        $version = trim((string)($manifest['version'] ?? ''));
        $minVersion = trim((string)($manifest['minVersion'] ?? ''));
        if (!$this->isSemanticVersion($version) || !$this->isSemanticVersion($minVersion)) {
            throw new RuntimeException('Update manifest contains an invalid semantic version.');
        }
        if (!isset($manifest['protected'], $manifest['update'])
            || !is_array($manifest['protected'])
            || !is_array($manifest['update'])
            || $manifest['update'] === []
        ) {
            throw new RuntimeException('Update manifest must define protected and update paths.');
        }
        if (isset($manifest['remove']) && !is_array($manifest['remove'])) throw new RuntimeException('Invalid removal list.');
        foreach (array_merge($manifest['protected'], $manifest['update'], $manifest['remove'] ?? []) as $path) {
            if (!is_string($path) || !preg_match('~^[a-zA-Z0-9_.-]+(?:/[a-zA-Z0-9_.-]+)*$~D', $path) || array_intersect(explode('/', $path), ['..', '.'])) {
                throw new RuntimeException('Update manifest contains an unsafe path.');
            }
        }
        foreach ((array)($manifest['remove'] ?? []) as $path) {
            if ($this->shouldPreservePath($path, $manifest) || !$this->shouldUpdatePath($path, $manifest)) throw new RuntimeException('Unsafe removal path.');
            if ($packageRoot !== null && file_exists($packageRoot . '/' . $path)) throw new RuntimeException('Removed file is also present in update package.');
        }
        if (!in_array((string)($manifest['type'] ?? ''), ['patch', 'minor', 'major'], true)) {
            throw new RuntimeException('Update manifest contains an invalid update type.');
        }

        if ($packageRoot !== null) {
            $versionFile = rtrim($packageRoot, '/') . '/config/version.php';
            if (!is_file($versionFile)) {
                throw new RuntimeException('Update package version metadata is missing.');
            }
            $versionContents = (string)file_get_contents($versionFile);
            $packageVersion = preg_match("/['\"]version['\"]\s*=>\s*['\"]([^'\"]+)['\"]/", $versionContents, $matches) === 1
                ? trim((string)$matches[1])
                : '';
            if ($packageVersion !== $version) {
                throw new RuntimeException('Update manifest version does not match config/version.php.');
            }
        }

        if ($minVersion !== '' && version_compare((string)($this->engineRelease['version'] ?? '0.0.0'), $minVersion, '<')) {
            throw new RuntimeException('Update requires FIREBALL CMS ' . $minVersion . ' or newer.');
        }
    }

    protected function isSemanticVersion(string $version): bool
    {
        return preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/', $version) === 1;
    }

    protected function loadRemoteGitManifest(string $branch): array
    {
        $result = $this->runCommand(
            'git show ' . escapeshellarg('origin/' . $branch . ':update.json'),
            ROOT
        );
        if ($result['exit_code'] !== 0) {
            throw new RuntimeException('Remote update manifest update.json is missing.');
        }

        $manifest = json_decode((string)$result['stdout'], true);
        if (!is_array($manifest) || json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('Remote update manifest update.json is invalid.');
        }
        $versionResult = $this->runCommand(
            'git show ' . escapeshellarg('origin/' . $branch . ':config/version.php'),
            ROOT
        );
        $remoteVersion = preg_match(
            "/['\"]version['\"]\s*=>\s*['\"]([^'\"]+)['\"]/",
            (string)$versionResult['stdout'],
            $matches
        ) === 1 ? trim((string)$matches[1]) : '';
        if ($versionResult['exit_code'] !== 0 || $remoteVersion !== (string)($manifest['version'] ?? '')) {
            throw new RuntimeException('Remote update manifest version does not match config/version.php.');
        }

        return $manifest;
    }

    protected function loadGitManifestAtRef(string $ref): array
    {
        if (preg_match('/^[a-f0-9]{40}$/i', $ref) !== 1) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $manifestResult = $this->runCommand(
            'git show ' . escapeshellarg($ref . ':update.json'),
            ROOT
        );
        if ($manifestResult['exit_code'] !== 0) {
            throw new RuntimeException('Release update manifest update.json is missing.');
        }

        $manifest = json_decode((string)$manifestResult['stdout'], true);
        if (!is_array($manifest) || json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('Release update manifest update.json is invalid.');
        }

        $versionResult = $this->runCommand(
            'git show ' . escapeshellarg($ref . ':config/version.php'),
            ROOT
        );
        $remoteVersion = preg_match(
            "/['\"]version['\"]\s*=>\s*['\"]([^'\"]+)['\"]/",
            (string)$versionResult['stdout'],
            $matches
        ) === 1 ? trim((string)$matches[1]) : '';
        if ($versionResult['exit_code'] !== 0 || $remoteVersion !== (string)($manifest['version'] ?? '')) {
            throw new RuntimeException('Release update manifest version does not match config/version.php.');
        }

        return $manifest;
    }

    protected function validateGitDiffAgainstManifest(string $branch, array $manifest): void
    {
        $result = $this->runCommand(
            'git diff --name-only HEAD ' . escapeshellarg('origin/' . $branch),
            ROOT
        );
        if ($result['exit_code'] !== 0) {
            throw new RuntimeException('Unable to validate update files against update.json.');
        }

        foreach (preg_split('/\r\n|\r|\n/', trim((string)$result['stdout'])) ?: [] as $path) {
            $path = trim($path);
            if ($path === '') {
                continue;
            }
            if ($this->shouldPreservePath($path, $manifest)) {
                continue;
            }
            if (!$this->shouldUpdatePath($path, $manifest) && !$this->isDevelopmentPath($path)) {
                throw new RuntimeException('Update contains a path not allowed by update.json: ' . $path);
            }
        }
    }

    protected function validateGitDiffAgainstRef(string $ref, array $manifest): void
    {
        if (preg_match('/^[a-f0-9]{40}$/i', $ref) !== 1) {
            throw new RuntimeException(return_translation('admin_update_release_invalid'));
        }

        $result = $this->runCommand(
            'git diff --name-only HEAD ' . escapeshellarg($ref),
            ROOT
        );
        if ($result['exit_code'] !== 0) {
            throw new RuntimeException('Unable to validate stable release files against update.json.');
        }

        foreach (preg_split('/\r\n|\r|\n/', trim((string)$result['stdout'])) ?: [] as $path) {
            $path = trim($path);
            if ($path === '') {
                continue;
            }
            if ($this->shouldPreservePath($path, $manifest)) {
                continue;
            }
            if (!$this->shouldUpdatePath($path, $manifest) && !$this->isDevelopmentPath($path)) {
                throw new RuntimeException('Stable release contains a path not allowed by update.json: ' . $path);
            }
        }
    }

    protected function createPreUpdateBackups(): void
    {
        try {
            $this->prunePreUpdateBackups(max(0, self::PRE_UPDATE_BACKUP_RETENTION - 1));
            $maintenance = new DatabaseMaintenanceService();
            $databaseBackup = $maintenance->createBackup();
            if ($databaseBackup === '') {
                throw new RuntimeException($maintenance->backupFailure());
            }
            $fileBackup = $this->createFileBackup();
            if ($fileBackup === '') {
                throw new RuntimeException('File backup failed. Update aborted.');
            }
            $descriptor = ['git_commit' => trim((string)($this->getLocalGitState()['commit_hash'] ?? '')), 'database' => $databaseBackup, 'files' => $fileBackup, 'database_sha256' => hash_file('sha256', $databaseBackup), 'files_sha256' => hash_file('sha256', $fileBackup), 'created_at' => date('c')];
            $descriptorPath = STORAGE . '/update-recovery.json';
            $temporary = $descriptorPath . '.tmp';
            $handle = fopen($temporary, 'wb');
            if ($handle === false) throw new RuntimeException('Unable to create recovery descriptor.');
            try {
                if (!chmod($temporary, 0600)) throw new RuntimeException('Unable to protect recovery descriptor.');
                $json = json_encode($descriptor, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
                if (fwrite($handle, $json) !== strlen($json) || !fflush($handle)) throw new RuntimeException('Unable to save recovery descriptor.');
            } finally { fclose($handle); }
            if (!rename($temporary, $descriptorPath)) throw new RuntimeException('Unable to publish recovery descriptor.');
            $this->prunePreUpdateBackups(self::PRE_UPDATE_BACKUP_RETENTION);
        } catch (\Throwable $exception) {
            log_error_details('Pre-update backup failed', [], $exception);
            throw $exception;
        }
    }

    protected function restorePreservedGitPaths(string $from, string $to, array $manifest): void
    {
        $diff = $this->runCommand('git diff --name-only ' . escapeshellarg($from) . ' ' . escapeshellarg($to), ROOT);
        if ($diff['exit_code'] !== 0) throw new RuntimeException('Unable to enumerate preserved update paths.');
        $descriptor = json_decode((string)file_get_contents(STORAGE . '/update-recovery.json'), true, 512, JSON_THROW_ON_ERROR);
        $zip = new \ZipArchive();
        if ($zip->open($descriptor['files']) !== true) throw new RuntimeException('Unable to open preserved files snapshot.');
        try {
            foreach (preg_split('/\R/', trim((string)$diff['stdout'])) ?: [] as $path) {
                if ($path === '' || !$this->shouldPreservePath($path, $manifest)) continue;
                if (str_contains($path, '..') || str_starts_with($path, '/')) throw new RuntimeException('Unsafe preserved path.');
                $target = ROOT . '/' . $path;
                if ($zip->locateName($path) !== false) {
                    $stream = $zip->getStream($path);
                    $this->ensureDirectory(dirname($target));
                    $parent = realpath(dirname($target));
                    if ($parent === false || !str_starts_with($parent . '/', realpath(ROOT) . '/') || is_link($target)) throw new RuntimeException('Unsafe preserved destination.');
                    $temporary = tempnam($parent, '.fbl-preserve-');
                    $out = fopen($temporary, 'wb');
                    try {
                        if (!is_resource($stream) || !is_resource($out) || stream_copy_to_stream($stream, $out) === false || !fflush($out)) throw new RuntimeException('Unable to restore preserved file.');
                    } finally {
                        if (is_resource($stream)) fclose($stream);
                        if (is_resource($out)) fclose($out);
                    }
                    chmod($temporary, $path === 'config/config.local.php' ? 0600 : 0644);
                    if (!rename($temporary, $target)) throw new RuntimeException('Unable to publish preserved file.');
                } elseif (is_file($target) || is_link($target)) {
                    if (!unlink($target)) throw new RuntimeException('Unable to preserve absent local path.');
                }
            }
        } finally { $zip->close(); }
    }

    protected function createFileBackup(): string
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new RuntimeException('ZipArchive is required to create an update backup.');
        }

        $backupDir = STORAGE . '/backups';
        $this->ensureDirectory($backupDir);
        $path = $backupDir . '/files-backup-' . date('Y-m-d-H-i-s') . '-' . bin2hex(random_bytes(6)) . '.zip';
        $private = fopen($path, 'x+b');
        if ($private === false) throw new RuntimeException('Unable to reserve backup file.');
        fclose($private);
        if (!chmod($path, 0600)) throw new RuntimeException('Unable to protect backup file.');
        $zip = new \ZipArchive();
        if ($zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Unable to create the file backup archive.');
        }

        $closeAttempted = false;
        try {
            foreach (['app', 'core', 'helpers', 'vendor', 'config', 'database', 'plugins', 'themes', 'public', 'bin', 'storage', 'uploads', 'tmp/error.log', 'tmp/.htaccess', '.htaccess', '.gitattributes', '.gitignore', 'composer.json', 'composer.lock', 'update.json', 'release-plugins.json'] as $relative) {
                $absolute = ROOT . '/' . $relative;
                if (!file_exists($absolute)) {
                    continue;
                }
                $this->addPathToZip($zip, $absolute, $relative, ['storage/backups', 'storage/update.lock', 'storage/update.maintenance', 'storage/update-recovery.json', 'storage/plugin-updates', 'storage/update-checks']);
            }

            $closeAttempted = true;
            if (!@$zip->close() || !is_file($path) || filesize($path) === 0) {
                throw new RuntimeException('File backup archive was not written. Check disk quota and free space.');
            }
        } catch (\Throwable $exception) {
            if (!$closeAttempted) {
                try {
                    $zip->close();
                } catch (\Throwable) {
                    // Preserve the original backup error if cleanup also fails.
                }
            }
            @unlink($path);
            throw $exception;
        }

        if (!chmod($path, 0600)) throw new RuntimeException('Unable to protect file backup.');
        return $path;
    }

    protected function prunePreUpdateBackups(int $keep = self::PRE_UPDATE_BACKUP_RETENTION): void
    {
        $backupDir = STORAGE . '/backups';
        if (!is_dir($backupDir)) {
            return;
        }

        $keep = max(0, $keep);
        $recovery = json_decode((string)@file_get_contents(STORAGE . '/update-recovery.json'), true) ?: [];
        $pinned = array_filter([$recovery['database'] ?? '', $recovery['files'] ?? '']);
        foreach (self::PRE_UPDATE_BACKUP_PATTERNS as $pattern) {
            $files = glob($backupDir . '/' . $pattern) ?: [];
            if (count($files) <= $keep) {
                continue;
            }

            usort(
                $files,
                static fn(string $a, string $b): int => ((int)@filemtime($b)) <=> ((int)@filemtime($a))
            );

            foreach (array_slice($files, $keep) as $file) {
                if (is_file($file) && !in_array($file, $pinned, true)) {
                    @unlink($file);
                }
            }
        }
    }

    protected function addPathToZip(\ZipArchive $zip, string $absolute, string $relative, array $excluded = []): void
    {
        if (is_link($absolute)) throw new RuntimeException('Automatic recovery cannot back up symbolic links: ' . $relative);
        if (is_file($absolute)) {
            if (!$zip->addFile($absolute, $relative)) {
                throw new RuntimeException('Unable to add file to backup: ' . $relative);
            }
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($absolute, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $path = $item->getPathname();
            $local = $relative . '/' . str_replace('\\', '/', substr($path, strlen($absolute) + 1));
            foreach ($excluded as $excludedPath) {
                $excludedPath = trim(str_replace('\\', '/', $excludedPath), '/');
                if ($local === $excludedPath || str_starts_with($local, $excludedPath . '/')) {
                    continue 2;
                }
            }
            if ($item->isLink()) throw new RuntimeException('Automatic recovery cannot back up symbolic links: ' . $local);
            if ($item->isDir()) {
                if (!$zip->addEmptyDir($local)) {
                    throw new RuntimeException('Unable to add directory to backup: ' . $local);
                }
                continue;
            }
            if (!$zip->addFile($path, $local)) {
                throw new RuntimeException('Unable to add file to backup: ' . $local);
            }
        }
    }

    protected function runPendingMigrations(): void
    {
        (new MigrationRunner())->run();
        if (app()->plugins !== null) {
            app()->plugins->migrateInstalledPlugins();
        }
        SearchMaintenance::rebuild(null, search_registry());
    }

    protected function ensureUpdateLogTable(): void
    {
        db()->query(
            'CREATE TABLE IF NOT EXISTS cms_update_logs (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT(10) UNSIGNED NULL,
                user_name VARCHAR(255) NULL,
                from_version VARCHAR(50) NOT NULL,
                to_version VARCHAR(50) NULL,
                result VARCHAR(20) NOT NULL,
                error TEXT NULL,
                created_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                KEY result (result),
                KEY created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }

    protected function writeUpdateLog(
        array $user,
        string $fromVersion,
        ?string $toVersion,
        string $result,
        ?string $error = null
    ): void {
        try {
            $this->ensureUpdateLogTable();
            db()->query(
                'INSERT INTO cms_update_logs
                 (user_id, user_name, from_version, to_version, result, error, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    (int)($user['id'] ?? 0) ?: null,
                    (string)($user['name'] ?? ''),
                    $fromVersion,
                    $toVersion,
                    $result,
                    $error,
                    date('Y-m-d H:i:s'),
                ]
            );
        } catch (\Throwable $exception) {
            log_error_details('Update log write failed', ['Result' => $result], $exception);
        }
    }

    protected function clearRuntimeCache(): void
    {
        cache()->clear();
        SiteSetting::clearPublicCache();
        \FBL\AssetManifest::rebuild();
        if (function_exists('opcache_reset')) @opcache_reset();
    }

    protected function acquireUpdateLock()
    {
        if (is_resource($GLOBALS['fireball_runtime_lock'] ?? null)) {
            flock($GLOBALS['fireball_runtime_lock'], LOCK_UN);
            fclose($GLOBALS['fireball_runtime_lock']);
            $GLOBALS['fireball_runtime_lock'] = null;
        }
        $path = STORAGE . '/update.lock';
        $handle = @fopen($path, 'c+');
        if (!is_resource($handle) || !flock($handle, LOCK_EX | LOCK_NB)) {
            if (is_resource($handle)) {
                fclose($handle);
            }
            throw new RuntimeException('Another CMS update is already running.');
        }

        if (is_file(STORAGE . '/update.maintenance')) {
            flock($handle, LOCK_UN);
            fclose($handle);
            throw new RuntimeException('A previous update requires recovery before another update can start.');
        }
        $payload = json_encode(['started_at' => date('c'), 'pid' => getmypid()], JSON_THROW_ON_ERROR);
        if (!ftruncate($handle, 0) || fwrite($handle, $payload) !== strlen($payload) || !fflush($handle)) {
            $this->releaseUpdateLock($handle);
            throw new RuntimeException('Unable to persist update lock.');
        }

        return $handle;
    }

    protected function releaseUpdateLock($handle): void
    {
        if (is_resource($handle)) {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    protected function enableMaintenanceMode(array $user): void
    {
        $written = file_put_contents(STORAGE . '/update.maintenance', json_encode([
            'started_at' => date('c'),
            'user_id' => (int)($user['id'] ?? 0),
        ], JSON_UNESCAPED_SLASHES), LOCK_EX);
        if ($written === false) throw new RuntimeException('Unable to enable update maintenance.');
    }

    protected function disableMaintenanceMode(): void
    {
        $path = STORAGE . '/update.maintenance';
        if (is_file($path) && !unlink($path)) throw new RuntimeException('Unable to leave update maintenance.');
    }

    /**
     * Определяет служебные пути из архива, которые нельзя переносить в проект.
     */
    protected function shouldSkipExtractedPath(string $relativePath): bool
    {
        $relativePath = trim(str_replace('\\', '/', $relativePath), '/');
        if ($relativePath === '') {
            return false;
        }

        foreach (explode('/', $relativePath) as $segment) {
            if ($segment === '__MACOSX' || $segment === '.DS_Store' || str_starts_with($segment, '._')) {
                return true;
            }
        }

        return false;
    }

    /**
     * Создаёт директорию, если её ещё нет.
     */
    protected function ensureDirectory(string $path): void
    {
        if (is_dir($path)) {
            return;
        }

        if (!@mkdir($path, 0755, true) && !is_dir($path)) {
            throw new RuntimeException(return_translation('admin_update_workspace_failed'));
        }
    }

    /**
     * Удаляет временную директорию рекурсивно.
     */
    protected function deleteDirectory(string $path): void
    {
        if (!is_dir($path)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $item) {
            if ($item->isDir()) {
                @rmdir($item->getPathname());
            } else {
                @unlink($item->getPathname());
            }
        }

        @rmdir($path);
    }

    /**
     * Проверяет, что PHP может работать с ZIP-архивами.
     */
    protected function supportsZipUpdates(): bool
    {
        return class_exists(\ZipArchive::class);
    }

    /**
     * Проверяет, можно ли писать в путь или в его родительскую директорию.
     */
    protected function isWritablePath(string $path): bool
    {
        if (file_exists($path)) {
            return is_writable($path);
        }

        return is_writable(dirname($path));
    }

    /**
     * Возвращает локальное состояние git-репозитория.
     */
    protected function getLocalGitState(): array
    {
        $defaults = [
            'git_available' => false,
            'is_git_repo' => false,
            'origin_url' => '',
            'branch' => '',
            'commit_hash' => '',
            'short_commit' => '',
            'git_tag' => '',
            'git_describe' => '',
            'is_clean' => false,
            'is_update_clean' => true,
            'dirty_files' => [],
            'blocking_dirty_files' => [],
            'ignored_dirty_files' => [],
        ];

        $gitCheck = $this->runCommand('command -v git', ROOT);
        if ($gitCheck['exit_code'] !== 0) {
            return $defaults;
        }

        $repoCheck = $this->runCommand('git rev-parse --is-inside-work-tree', ROOT);
        if ($repoCheck['exit_code'] !== 0 || trim($repoCheck['stdout']) !== 'true') {
            return array_merge($defaults, [
                'git_available' => true,
            ]);
        }

        $originUrl = trim($this->runCommand('git config --get remote.origin.url', ROOT)['stdout']);
        $branch = trim($this->runCommand('git branch --show-current', ROOT)['stdout']);
        $commitHash = trim($this->runCommand('git rev-parse HEAD', ROOT)['stdout']);
        $exactTag = trim($this->runCommand('git describe --tags --exact-match', ROOT)['stdout']);
        $describe = trim($this->runCommand('git describe --tags --always', ROOT)['stdout']);
        $statusOutput = trim($this->runCommand('git status --porcelain', ROOT)['stdout']);
        $dirtyFiles = $statusOutput === '' ? [] : $this->normalizeDirtyFiles($statusOutput);
        $blockingDirtyFiles = $this->filterBlockingDirtyFiles($dirtyFiles);
        $ignoredDirtyFiles = array_values(array_diff($dirtyFiles, $blockingDirtyFiles));

        return [
            'git_available' => true,
            'is_git_repo' => true,
            'origin_url' => $originUrl,
            'branch' => $branch,
            'commit_hash' => $commitHash,
            'short_commit' => $commitHash !== '' ? substr($commitHash, 0, 7) : '',
            'git_tag' => $exactTag,
            'git_describe' => $describe !== '' ? $describe : ($commitHash !== '' ? substr($commitHash, 0, 7) : ''),
            'is_clean' => $statusOutput === '',
            'is_update_clean' => $blockingDirtyFiles === [],
            'dirty_files' => $dirtyFiles,
            'blocking_dirty_files' => $blockingDirtyFiles,
            'ignored_dirty_files' => $ignoredDirtyFiles,
        ];
    }

    /**
     * Определяет, нужен ли запуск Composer после обновления кода.
     */
    protected function runComposerIfNeeded(string $previousCommit, string $currentCommit): void
    {
        $diffResult = $this->runCommand(
            'git diff --name-only ' . escapeshellarg($previousCommit) . ' ' . escapeshellarg($currentCommit) . ' -- composer.json composer.lock',
            ROOT
        );

        if ($diffResult['exit_code'] !== 0 || trim($diffResult['stdout']) === '') {
            return;
        }

        if ($this->composerVendorMatchesLock(ROOT)) {
            return;
        }

        $composerBinary = $this->detectComposerBinary();
        if ($composerBinary === '') {
            throw new RuntimeException(return_translation('admin_update_composer_required'));
        }

        $installResult = $this->runCommand(
            $composerBinary . ' install --no-interaction --prefer-dist --optimize-autoloader',
            ROOT
        );

        if ($installResult['exit_code'] !== 0) {
            throw new RuntimeException(
                $this->formatCommandError($installResult, return_translation('admin_update_composer_failed'))
            );
        }

    }

    /**
     * Фиксирует текущее состояние composer-файлов для ZIP-обновления.
     */
    protected function captureDependencyFingerprint(): array
    {
        return [
            'composer_json' => is_file(ROOT . '/composer.json') ? sha1_file(ROOT . '/composer.json') : '',
            'composer_lock' => is_file(ROOT . '/composer.lock') ? sha1_file(ROOT . '/composer.lock') : '',
        ];
    }

    protected function assertPackageComposerReady(string $packageRoot, array $before): void
    {
        $packageJson = $packageRoot . '/composer.json';
        $packageLock = $packageRoot . '/composer.lock';
        $dependencyFilesChanged = (
            is_file($packageJson)
            && sha1_file($packageJson) !== ($before['composer_json'] ?? '')
        ) || (
            is_file($packageLock)
            && sha1_file($packageLock) !== ($before['composer_lock'] ?? '')
        );

        if (!$dependencyFilesChanged) {
            return;
        }

        if ($this->composerVendorMatchesLock($packageRoot)) {
            return;
        }

        if (!$this->canRunProcesses() || $this->detectComposerBinary() === '') {
            throw new RuntimeException(return_translation('admin_update_composer_required'));
        }
    }

    /**
     * При изменении composer-файлов запускает Composer или прерывает обновление.
     */
    protected function runComposerIfDependencyFilesChanged(array $before): void
    {
        $after = $this->captureDependencyFingerprint();
        if (($before['composer_json'] ?? '') === ($after['composer_json'] ?? '')
            && ($before['composer_lock'] ?? '') === ($after['composer_lock'] ?? '')
        ) {
            return;
        }

        if ($this->composerVendorMatchesLock(ROOT)) {
            return;
        }

        if (!$this->canRunProcesses()) {
            throw new RuntimeException(return_translation('admin_update_composer_required'));
        }

        $composerBinary = $this->detectComposerBinary();
        if ($composerBinary === '') {
            throw new RuntimeException(return_translation('admin_update_composer_required'));
        }

        $installResult = $this->runCommand(
            $composerBinary . ' install --no-interaction --prefer-dist --optimize-autoloader',
            ROOT
        );

        if ($installResult['exit_code'] !== 0) {
            throw new RuntimeException(
                $this->formatCommandError($installResult, return_translation('admin_update_composer_failed'))
            );
        }

    }

    /**
     * Проверяет, что production-зависимости из lock-файла уже включены в vendor.
     */
    protected function composerVendorMatchesLock(string $root): bool
    {
        $lockPath = rtrim($root, '/') . '/composer.lock';
        $installedPath = rtrim($root, '/') . '/vendor/composer/installed.json';
        $autoloadPath = rtrim($root, '/') . '/vendor/autoload.php';

        if (!is_file($lockPath) || !is_file($installedPath) || !is_file($autoloadPath)) {
            return false;
        }

        $lock = json_decode((string)file_get_contents($lockPath), true);
        $installed = json_decode((string)file_get_contents($installedPath), true);
        if (!is_array($lock) || !is_array($installed)) {
            return false;
        }

        $installedPackages = $installed['packages'] ?? $installed;
        if (!is_array($installedPackages)) {
            return false;
        }

        $installedVersions = [];
        foreach ($installedPackages as $package) {
            $name = trim((string)($package['name'] ?? ''));
            $version = trim((string)($package['version'] ?? ''));
            if ($name !== '' && $version !== '') {
                $installedVersions[$name] = $version;
            }
        }

        foreach ((array)($lock['packages'] ?? []) as $package) {
            $name = trim((string)($package['name'] ?? ''));
            $version = trim((string)($package['version'] ?? ''));
            if ($name === '' || $version === '' || ($installedVersions[$name] ?? null) !== $version) {
                return false;
            }
        }

        return true;
    }

    /**
     * Определяет доступную команду Composer в окружении.
     */
    protected function detectComposerBinary(): string
    {
        $composerCheck = $this->runCommand('command -v composer', ROOT);
        if ($composerCheck['exit_code'] === 0 && trim($composerCheck['stdout']) !== '') {
            return 'composer';
        }

        $localComposer = ROOT . '/composer.phar';
        if (is_file($localComposer)) {
            return escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($localComposer);
        }

        return '';
    }

    /**
     * Возвращает удалённую версию по release/tag или, если их нет, по ближайшему тегу и коммиту ветки.
     */
    protected function resolveRemoteVersion(?array $release, string $branch, string $remoteCommitHash): string
    {
        if (is_array($release)) {
            $releaseVersion = $this->extractReleaseVersion($release);
            if ($releaseVersion !== '0.0.0') {
                return $releaseVersion;
            }
        }

        $tagResult = $this->runCommand(
            'git describe --tags --abbrev=0 ' . escapeshellarg('origin/' . $branch),
            ROOT
        );
        $tag = trim($tagResult['stdout']);
        if ($tag !== '') {
            return $tag;
        }

        return $remoteCommitHash !== '' ? substr($remoteCommitHash, 0, 7) : '';
    }

    /**
     * Запускает shell-команду и возвращает stdout/stderr.
     */
    protected function runCommand(string $command, string $cwd): array
    {
        if (!$this->canRunProcesses()) {
            return [
                'command' => $command,
                'stdout' => '',
                'stderr' => return_translation('admin_update_process_disabled'),
                'exit_code' => 1,
            ];
        }

        $descriptorSpec = [
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $process = proc_open(['/bin/sh', '-lc', $command], $descriptorSpec, $pipes, $cwd);
        if (!is_resource($process)) {
            return [
                'command' => $command,
                'stdout' => '',
                'stderr' => return_translation('admin_update_process_start_failed'),
                'exit_code' => 1,
            ];
        }

        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        return [
            'command' => $command,
            'stdout' => trim((string)$stdout),
            'stderr' => trim((string)$stderr),
            'exit_code' => (int)proc_close($process),
        ];
    }

    /**
     * Проверяет, разрешены ли системные процессы в текущем PHP-окружении.
     */
    protected function canRunProcesses(): bool
    {
        if (!function_exists('proc_open')) {
            return false;
        }

        $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));

        return !in_array('proc_open', $disabled, true);
    }

    /**
     * Выбирает репозиторий из настроек или origin.
     */
    protected function resolveRepository(array $settings, string $originUrl = ''): string
    {
        $candidate = trim((string)($settings['updater_github_repository'] ?? ''));
        if ($candidate === '') {
            $candidate = $originUrl;
        }

        return $this->normalizeRepository($candidate);
    }

    /**
     * Выбирает ветку из настроек, локального репозитория или значения по умолчанию.
     */
    protected function resolveBranch(array $settings, string $localBranch = ''): string
    {
        $branch = $this->normalizeBranch((string)($settings['updater_github_branch'] ?? ''));
        if ($branch === '') {
            $branch = $this->normalizeBranch($localBranch);
        }

        return $branch !== '' ? $branch : 'main';
    }

    /**
     * Возвращает разрешённый канал обновлений. Stable используется по умолчанию.
     */
    protected function resolveUpdateChannel(array $settings): string
    {
        // Role policy is enforced on the server, including checks and installation.
        // Keep the site's legacy Dev setting for unauthenticated CLI workflows only.
        if (function_exists('get_user')) {
            $role = (string)(get_user()['role'] ?? '');
            if ($role === 'creator') return 'beta';
            if ($role !== '') return 'stable';
        }

        $channel = trim(mb_strtolower((string)($settings['update_channel'] ?? '')));
        if ($channel === '') {
            $configuredChannel = defined('UPDATE_CHANNEL') ? UPDATE_CHANNEL : getenv('UPDATE_CHANNEL');
            $channel = trim(mb_strtolower((string)($configuredChannel ?: 'stable')));
        }

        return in_array($channel, ['dev', 'beta'], true) ? $channel : 'stable';
    }

    /**
     * Приводит значение репозитория к формату owner/repo.
     */
    protected function normalizeRepository(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        $value = preg_replace('~^git@github\.com:~i', '', $value) ?? $value;
        $value = preg_replace('~^https?://github\.com/~i', '', $value) ?? $value;
        $value = preg_replace('~\.git$~i', '', $value) ?? $value;
        $value = trim($value, '/');

        if (preg_match('~^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$~', $value)) {
            return $value;
        }

        return '';
    }

    /**
     * Приводит имя ветки к безопасному формату для git-команд.
     */
    protected function normalizeBranch(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        if (preg_match('~^(?!-)[A-Za-z0-9._/-]+$~', $value) !== 1) {
            return '';
        }

        return $value;
    }

    /**
     * Сравнивает версии в стиле semver, если это возможно.
     */
    protected function compareVersions(string $localVersion, string $remoteVersion): ?int
    {
        $localComparable = $this->normalizeComparableVersion($localVersion);
        $remoteComparable = $this->normalizeComparableVersion($remoteVersion);

        if ($localComparable === '' || $remoteComparable === '') {
            return null;
        }

        return version_compare($localComparable, $remoteComparable);
    }

    /**
     * Нормализует строку версии для version_compare.
     */
    protected function normalizeComparableVersion(string $value): string
    {
        $value = trim(mb_strtolower($value));
        if ($value === '') {
            return '';
        }

        $value = preg_replace('~^v~', '', $value) ?? $value;
        $value = str_replace([' ', '_'], '-', $value);

        if (preg_match('~(\d+(?:\.\d+)+(?:-[a-z0-9.-]+)?)~', $value, $matches)) {
            return $matches[1];
        }

        return '';
    }

    /**
     * Выделяет строку версии из данных релиза.
     */
    protected function extractReleaseVersion(array $release): string
    {
        $candidates = [
            trim((string)($release['tag_name'] ?? '')),
            trim((string)($release['name'] ?? '')),
        ];

        foreach ($candidates as $candidate) {
            if ($this->normalizeComparableVersion($candidate) !== '') {
                return $candidate;
            }
        }

        return $candidates[0] !== '' ? $candidates[0] : ($candidates[1] !== '' ? $candidates[1] : '0.0.0');
    }

    /**
     * Сравнивает даты релизов, если версии не удалось распарсить.
     */
    protected function fallbackReleaseComparison(string $localReleasedAt, string $remotePublishedAt): bool
    {
        $localTime = $localReleasedAt !== '' ? strtotime($localReleasedAt) : false;
        $remoteTime = $remotePublishedAt !== '' ? strtotime($remotePublishedAt) : false;

        return $localTime !== false && $remoteTime !== false && $remoteTime > $localTime;
    }

    /**
     * Сохраняет результат последней проверки в таблицу настроек.
     */
    protected function persistLastCheck(array $payload): void
    {
        $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $channel = in_array($payload['channel'] ?? '', ['dev', 'beta'], true) ? $payload['channel'] : 'stable';
        $this->siteSettings->setMany([
            'updater_last_check_payload' => $encoded,
            'updater_last_check_payload_' . $channel => $encoded,
            'updater_last_checked_at' => (string)($payload['checked_at'] ?? date('Y-m-d H:i:s')),
        ]);
    }

    /**
     * Не смешивает результаты проверок Stable, Beta и Dev между ролями.
     */
    protected function lastCheckForChannel(array $settings): ?array
    {
        $channel = $this->resolveUpdateChannel($settings);
        // Keep the legacy key, but cache channels independently so simultaneous
        // admin/creator feeds do not trigger a GitHub check every eight seconds.
        foreach (['updater_last_check_payload', 'updater_last_check_payload_' . $channel] as $key) {
            $payload = $this->decodeLastCheck((string)($settings[$key] ?? ''));
            if (($payload['channel'] ?? '') !== $channel) continue;
            if (!empty($payload['local_version']) && $payload['local_version'] !== ($this->engineRelease['version'] ?? '')) continue;
            $repository = $this->normalizeRepository((string)($settings['updater_github_repository'] ?? ''));
            if ($repository !== '' && ($payload['repository'] ?? '') !== $repository) continue;
            return $payload;
        }

        return null;
    }

    /**
     * Декодирует сохранённый JSON последней проверки.
     */
    protected function decodeLastCheck(string $payload): ?array
    {
        if ($payload === '') {
            return null;
        }

        $decoded = json_decode($payload, true);

        return is_array($decoded) ? $decoded : null;
    }

    /**
     * Преобразует вывод git status в список путей.
     */
    protected function normalizeDirtyFiles(string $statusOutput): array
    {
        $files = [];

        foreach (preg_split('/\R/', $statusOutput) ?: [] as $line) {
            $line = rtrim($line);
            if ($line === '') {
                continue;
            }

            $path = strlen($line) > 3 ? substr($line, 3) : $line;
            if (str_contains($path, ' -> ')) {
                $parts = explode(' -> ', $path);
                $path = (string)end($parts);
            }

            $path = ltrim(trim($path), './');
            if ($path === '') {
                continue;
            }

            $files[] = $path;
        }

        return array_values(array_unique($files));
    }

    /**
     * Отбрасывает runtime-файлы и служебные vendor-объекты, которые не должны блокировать обновление.
     */
    protected function filterBlockingDirtyFiles(array $dirtyFiles): array
    {
        return array_values(array_filter($dirtyFiles, function (string $path): bool {
            return !$this->shouldIgnoreDirtyFile($path);
        }));
    }

    /**
     * Определяет, можно ли игнорировать локальное изменение для целей автообновления.
     */
    protected function shouldIgnoreDirtyFile(string $path): bool
    {
        $normalizedPath = ltrim(str_replace('\\', '/', trim($path)), '/');
        if ($this->shouldPreservePath($normalizedPath)) return true;

        $ignoredExact = [
            '.DS_Store',
            'tmp/error.log',
            'vendor/symfony/var-dumper/Resources/bin/var-dump-server',
        ];

        if (in_array($normalizedPath, $ignoredExact, true)) {
            return true;
        }

        $ignoredPrefixes = [
            '__MACOSX/',
            'tmp/',
            'vendor/bin/',
        ];

        foreach ($ignoredPrefixes as $prefix) {
            if (str_starts_with($normalizedPath, $prefix)) {
                return true;
            }
        }

        foreach (explode('/', $normalizedPath) as $segment) {
            if ($segment !== '' && str_starts_with($segment, '._')) {
                return true;
            }
        }

        return false;
    }

    /**
     * Строит короткое описание релиза для UI.
     */
    protected function buildReleaseExcerpt(string $body): string
    {
        $body = preg_replace('/[`#>*_-]+/u', ' ', $body) ?? $body;
        $body = preg_replace('/\s+/u', ' ', trim($body)) ?? trim($body);

        return mb_substr($body, 0, 240);
    }

    /**
     * Собирает понятное сообщение по итогу проверки обновлений.
     */
    protected function resolveCheckMessage(string $branchStatus, bool $updateAvailable): string
    {
        return match ($branchStatus) {
            'behind' => return_translation('admin_update_check_available'),
            'no_local_commit' => $updateAvailable
                ? return_translation('admin_update_check_available')
                : return_translation('admin_update_check_none'),
            'ahead' => return_translation('admin_update_branch_ahead'),
            'diverged' => return_translation('admin_update_branch_diverged'),
            'not_applicable' => $updateAvailable
                ? return_translation('admin_update_check_available')
                : return_translation('admin_update_check_none'),
            'identical' => $updateAvailable
                ? return_translation('admin_update_check_available')
                : return_translation('admin_update_check_none'),
            default => $updateAvailable
                ? return_translation('admin_update_check_available')
                : return_translation('admin_update_check_none'),
        };
    }

    /**
     * Собирает URL GitHub API для конкретного репозитория.
     */
    protected function buildGithubApiUrl(string $repository, string $path): string
    {
        return 'https://api.github.com/repos/' . str_replace('%2F', '/', rawurlencode($repository)) . $path;
    }

    /**
     * Собирает URL текстового файла публичной ветки без обращения к GitHub REST API.
     */
    protected function buildGithubRawUrl(string $repository, string $branch, string $path): string
    {
        return 'https://raw.githubusercontent.com/'
            . str_replace('%2F', '/', rawurlencode($repository))
            . '/refs/heads/'
            . $this->encodeGithubPath($branch)
            . '/'
            . $this->encodeGithubPath($path);
    }

    /**
     * Собирает прямой URL ZIP-архива публичной ветки без квоты GitHub REST API.
     */
    protected function buildGithubCodeloadUrl(string $repository, string $branch): string
    {
        return 'https://codeload.github.com/'
            . str_replace('%2F', '/', rawurlencode($repository))
            . '/zip/refs/heads/'
            . $this->encodeGithubPath($branch);
    }

    /**
     * Кодирует отдельные сегменты пути, сохраняя разделители веток и файлов.
     */
    protected function encodeGithubPath(string $path): string
    {
        return implode('/', array_map('rawurlencode', explode('/', trim($path, '/'))));
    }

    /**
     * Собирает стандартные заголовки GitHub API.
     */
    protected function buildGithubHeaders(string $token = ''): array
    {
        $headers = [
            'Accept: application/vnd.github+json',
            'X-GitHub-Api-Version: 2022-11-28',
            'User-Agent: FIREBALL_CMS-Updater',
        ];

        if ($token !== '') {
            $headers[] = 'Authorization: Bearer ' . $token;
        }

        return $headers;
    }

    /**
     * Возвращает сохранённый commit последнего успешного ZIP/git-обновления.
     */
    protected function getStoredInstalledCommit(array $settings): string
    {
        return trim((string)($settings['updater_last_installed_commit'] ?? ''));
    }

    /**
     * Собирает заголовки для скачивания ZIP-архива релиза.
     */
    protected function buildGithubDownloadHeaders(string $token = '', string $downloadMode = 'direct'): array
    {
        $headers = [
            'User-Agent: FIREBALL_CMS-Updater',
        ];

        if ($downloadMode === 'release_asset_api') {
            $headers[] = 'Accept: application/octet-stream';
            $headers[] = 'X-GitHub-Api-Version: 2022-11-28';
        } elseif ($downloadMode === 'repository_zipball_api') {
            $headers[] = 'Accept: application/vnd.github+json';
            $headers[] = 'X-GitHub-Api-Version: 2022-11-28';
        }

        if ($token !== '') {
            $headers[] = 'Authorization: Bearer ' . $token;
        }

        return $headers;
    }

    /**
     * Извлекает HTTP-код из массива ответных заголовков stream wrapper.
     */
    protected function extractHttpStatusCode(array $headers): int
    {
        foreach ($headers as $header) {
            if (preg_match('~^HTTP/\S+\s+(\d{3})~', $header, $matches)) {
                return (int)$matches[1];
            }
        }

        return 200;
    }

    /**
     * Формирует удобное текстовое сообщение по ошибке системной команды.
     */
    protected function formatCommandError(array $result, string $fallbackMessage): string
    {
        $details = trim($result['stderr'] !== '' ? $result['stderr'] : $result['stdout']);

        return $details !== '' ? $fallbackMessage . ' ' . $details : $fallbackMessage;
    }

}
