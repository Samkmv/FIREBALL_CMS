<?php

/** @var \FBL\Router $router */

$toyRentalRedirect = static function (string $path = '/admin/toy-rental'): void {
    response()->redirect(base_href($path));
};

$toyRentalHistoryRedirect = static function () use ($toyRentalRedirect): void {
    $returnTo = trim((string)request()->post('return_to', ''));
    $path = (string)(parse_url($returnTo, PHP_URL_PATH) ?: '');
    $expectedPath = (string)(parse_url(base_href('/admin/toy-rental/rides'), PHP_URL_PATH) ?: '/admin/toy-rental/rides');
    if ($returnTo !== '' && str_starts_with($path, $expectedPath)) {
        response()->redirect($returnTo);
    }

    $toyRentalRedirect('/admin/toy-rental/rides');
};

$router->get('/admin/toy-rental/assets/(?P<file>[a-z0-9._-]+)', static function (): never {
    $file = (string)get_route_param('file');
    if (!in_array($file, ['toy-rental.css', 'toy-rental.js', 'settings.js'], true)) {
        abort();
    }

    $path = __DIR__ . '/assets/' . $file;
    $real = realpath($path);
    $base = realpath(__DIR__ . '/assets');
    if ($real === false || $base === false || !str_starts_with($real, rtrim($base, '/') . '/')) {
        abort();
    }

    header('Content-Type: ' . (str_ends_with($file, '.css') ? 'text/css' : 'application/javascript') . '; charset=utf-8');
    header('Cache-Control: public, max-age=3600');
    readfile($real);
    exit;
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/sound', static function (): never {
    FireballPluginToyCarRental::serveCustomSound();
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental', static function (): string {
    $settings = FireballPluginToyCarRental::settings();

    return plugin_view('toy-car-rental', 'admin-dashboard', FireballPluginToyCarRental::viewData('dashboard', [
        'title' => FireballPluginToyCarRental::t('toy_rental_dashboard_title'),
        'cars' => FireballPluginToyCarRental::carsForOperator(),
        'stats' => FireballPluginToyCarRental::todayStats(),
        'settings' => $settings,
    ]));
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/state', static function (): void {
    header('Cache-Control: no-store');
    response()->json(FireballPluginToyCarRental::operatorState());
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/rides/start', static function () use ($toyRentalRedirect): void {
    try {
        FireballPluginToyCarRental::startRide(request()->getData());
        if (request()->isAjax()) {
            response()->json(array_merge(FireballPluginToyCarRental::operatorState(), [
                'message' => FireballPluginToyCarRental::t('toy_rental_flash_ride_started'),
            ]));
        }
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_ride_started'));
    } catch (Throwable $exception) {
        log_error_details('Toy rental start ride failed', [], $exception);
        if (request()->isAjax()) {
            response()->json(['status' => false, 'message' => $exception->getMessage()], 422);
        }
        session()->setFlash('error', $exception->getMessage());
    }

    $toyRentalRedirect('/admin/toy-rental');
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/rides/complete', static function () use ($toyRentalRedirect): void {
    try {
        FireballPluginToyCarRental::completeRide((int)request()->post('id'), request()->getData());
        if (request()->isAjax()) {
            response()->json(array_merge(FireballPluginToyCarRental::operatorState(), [
                'message' => FireballPluginToyCarRental::t('toy_rental_flash_ride_completed'),
            ]));
        }
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_ride_completed'));
    } catch (Throwable $exception) {
        log_error_details('Toy rental complete ride failed', ['Ride' => request()->post('id')], $exception);
        if (request()->isAjax()) {
            response()->json(['status' => false, 'message' => $exception->getMessage()], 422);
        }
        session()->setFlash('error', $exception->getMessage());
    }

    $toyRentalRedirect('/admin/toy-rental');
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/rides/sync-overdue', static function (): void {
    try {
        $updated = FireballPluginToyCarRental::markOverdueRides();
        response()->json([
            'status' => true,
            'updated' => $updated,
        ]);
    } catch (Throwable $exception) {
        log_error_details('Toy rental overdue sync failed', [], $exception);
        response()->json([
            'status' => false,
            'message' => FireballPluginToyCarRental::t('toy_rental_error_overdue_sync'),
        ], 500);
    }
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/rides/pay', static function () use ($toyRentalHistoryRedirect): void {
    try {
        FireballPluginToyCarRental::markRidePaid((int)request()->post('id'), request()->getData());
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_ride_paid'));
    } catch (Throwable $exception) {
        log_error_details('Toy rental mark ride paid failed', ['Ride' => request()->post('id')], $exception);
        session()->setFlash('error', $exception->getMessage());
    }

    $toyRentalHistoryRedirect();
})->middleware(['auth', 'admin']);

foreach (['delete', 'recalculate'] as $action) {
    $router->post('/admin/toy-rental/rides/' . $action, static function () use ($action, $toyRentalHistoryRedirect): void {
        try {
            $id = (int)request()->post('id');
            if ($action === 'delete') {
                FireballPluginToyCarRental::deleteRideFromHistory($id);
                $message = FireballPluginToyCarRental::t('toy_rental_flash_history_deleted');
            } else {
                FireballPluginToyCarRental::recalculateRide($id);
                $message = FireballPluginToyCarRental::t('toy_rental_flash_ride_recalculated');
            }
            session()->setFlash('success', $message);
        } catch (Throwable $exception) {
            log_error_details('Toy rental history action failed', ['Action' => $action, 'Ride' => request()->post('id')], $exception);
            session()->setFlash('error', $exception->getMessage());
        }
        $toyRentalHistoryRedirect();
    })->middleware(['auth', 'admin']);
}

$router->post('/admin/toy-rental/rides/clear-history', static function () use ($toyRentalRedirect): void {
    try {
        $count = FireballPluginToyCarRental::clearRideHistory();
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_history_cleared', ['count' => $count]));
    } catch (Throwable $exception) {
        log_error_details('Toy rental history clear failed', [], $exception);
        session()->setFlash('error', $exception->getMessage());
    }
    $toyRentalRedirect('/admin/toy-rental/rides?date_filter=all');
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/cars', static function (): string {
    return plugin_view('toy-car-rental', 'cars-list', FireballPluginToyCarRental::viewData('cars', [
        'title' => FireballPluginToyCarRental::t('toy_rental_cars_title'),
        'cars' => FireballPluginToyCarRental::cars(true),
    ]));
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/cars/create', static function (): string {
    return plugin_view('toy-car-rental', 'car-form', FireballPluginToyCarRental::viewData('cars', [
        'title' => FireballPluginToyCarRental::t('toy_rental_car_create_title'),
        'car' => null,
    ]));
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/cars/create', static function () use ($toyRentalRedirect): void {
    try {
        FireballPluginToyCarRental::saveCar(request()->getData());
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_car_created'));
        $toyRentalRedirect('/admin/toy-rental/cars');
    } catch (Throwable $exception) {
        log_error_details('Toy rental car create failed', [], $exception);
        session()->setFlash('error', $exception->getMessage());
        $toyRentalRedirect('/admin/toy-rental/cars/create');
    }
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/cars/edit/(?P<id>\d+)/?', static function (): string {
    $car = FireballPluginToyCarRental::car((int)get_route_param('id'));
    if (!$car) {
        abort();
    }

    return plugin_view('toy-car-rental', 'car-form', FireballPluginToyCarRental::viewData('cars', [
        'title' => FireballPluginToyCarRental::t('toy_rental_car_edit_title'),
        'car' => $car,
    ]));
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/cars/edit/(?P<id>\d+)/?', static function () use ($toyRentalRedirect): void {
    $id = (int)get_route_param('id');
    try {
        FireballPluginToyCarRental::saveCar(request()->getData(), $id);
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_car_saved'));
        $toyRentalRedirect('/admin/toy-rental/cars');
    } catch (Throwable $exception) {
        log_error_details('Toy rental car update failed', ['Car' => $id], $exception);
        session()->setFlash('error', $exception->getMessage());
        $toyRentalRedirect('/admin/toy-rental/cars/edit/' . $id);
    }
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/cars/hide', static function () use ($toyRentalRedirect): void {
    try {
        FireballPluginToyCarRental::hideCar((int)request()->post('id'));
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_car_hidden'));
    } catch (Throwable $exception) {
        log_error_details('Toy rental car hide failed', ['Car' => request()->post('id')], $exception);
        session()->setFlash('error', $exception->getMessage());
    }

    $toyRentalRedirect('/admin/toy-rental/cars');
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/cars/delete', static function () use ($toyRentalRedirect): void {
    try {
        FireballPluginToyCarRental::deleteCar((int)request()->post('id'));
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_car_deleted'));
    } catch (Throwable $exception) {
        log_error_details('Toy rental car delete failed', ['Car' => request()->post('id')], $exception);
        session()->setFlash('error', $exception->getMessage());
    }

    $toyRentalRedirect('/admin/toy-rental/cars');
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/active', static function (): string {
    return plugin_view('toy-car-rental', 'rides-active', FireballPluginToyCarRental::viewData('active', [
        'title' => FireballPluginToyCarRental::t('toy_rental_active_title'),
        'cars' => FireballPluginToyCarRental::carsForOperator(),
    ]));
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/rides', static function (): string {
    $filters = [
        'date_filter' => (string)request()->get('date_filter', 'today'),
        'date_from' => (string)request()->get('date_from', ''),
        'date_to' => (string)request()->get('date_to', ''),
        'car_id' => (int)request()->get('car_id', 0),
        'billing_type' => (string)request()->get('billing_type', ''),
        'ride_status' => (string)request()->get('ride_status', ''),
        'payment_method' => (string)request()->get('payment_method', ''),
        'payment_status' => (string)request()->get('payment_status', ''),
    ];

    return plugin_view('toy-car-rental', 'rides-history', FireballPluginToyCarRental::viewData('history', [
        'title' => FireballPluginToyCarRental::t('toy_rental_history_title'),
        'rides' => FireballPluginToyCarRental::history($filters),
        'cars' => FireballPluginToyCarRental::cars(true, true),
        'filters' => $filters,
    ]));
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/stats', static function (): string {
    return plugin_view('toy-car-rental', 'stats', FireballPluginToyCarRental::viewData('stats', [
        'title' => FireballPluginToyCarRental::t('toy_rental_stats_title'),
        'stats' => FireballPluginToyCarRental::todayStats(),
    ]));
})->middleware(['auth', 'admin']);

$router->get('/admin/toy-rental/settings', static function (): string {
    $users = FireballPluginToyCarRental::notificationUsers();
    return plugin_view('toy-car-rental', 'settings', FireballPluginToyCarRental::viewData('settings', [
        'title' => FireballPluginToyCarRental::t('toy_rental_settings_title'),
        'operatorRoles' => FireballPluginToyCarRental::operatorRoles(),
        'notificationUsers' => $users,
        'selectedNotificationUserIds' => FireballPluginToyCarRental::selectedNotificationUserIds($users),
        'customSoundUrl' => FireballPluginToyCarRental::customSoundUrl(),
        'footer_scripts' => [base_href('/admin/toy-rental/assets/settings.js?v=' . filemtime(__DIR__ . '/assets/settings.js'))],
    ]));
})->middleware(['auth', 'admin']);

$router->post('/admin/toy-rental/settings', static function () use ($toyRentalRedirect): void {
    try {
        FireballPluginToyCarRental::saveSettings(request()->getData(), request()->files);
        session()->setFlash('success', FireballPluginToyCarRental::t('toy_rental_flash_settings_saved'));
    } catch (Throwable $exception) {
        log_error_details('Toy rental settings failed', [], $exception);
        session()->setFlash('error', $exception->getMessage());
    }

    $toyRentalRedirect('/admin/toy-rental/settings');
})->middleware(['auth', 'admin']);
