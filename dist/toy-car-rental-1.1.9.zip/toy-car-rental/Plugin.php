<?php

use App\Services\SqlFileRunner;
use FBL\Plugins\PluginInterface;

final class FireballPluginToyCarRental implements PluginInterface
{
    public const SLUG = 'toy-car-rental';
    public const PAYMENT_METHODS = ['cash', 'transfer'];

    public function install(): void
    {
        self::ensureDatabaseSchema();
        self::ensureCarSchema();
        self::ensureRideSchema();

        foreach (self::defaultSettings() as $key => $value) {
            if (plugin_setting(self::SLUG, $key, null) === null) {
                if ($key === 'fixed_durations') {
                    $value = self::fixedDurations(array_merge($value, [(int)plugin_setting(self::SLUG, 'default_duration', 10)]));
                }
                if ($key === 'max_ride_minutes') {
                    $value = max($value, max(self::fixedDurations(plugin_setting(self::SLUG, 'fixed_durations', [5, 10, 15, 30]))));
                }
                plugin_setting_set(self::SLUG, $key, $value);
            }
        }
    }

    public function uninstall(): void
    {
        self::closeOpenRides();
    }

    public function activate(): void
    {
        self::ensureDatabaseSchema();
        self::ensureCarSchema();
        self::ensureRideSchema();
        self::expireLongRides(false);
        fireball_event('toy_rental.activated', ['slug' => self::SLUG]);
    }

    public function deactivate(): void
    {
        self::closeOpenRides();
        fireball_event('toy_rental.deactivated', ['slug' => self::SLUG]);
    }

    public function boot(): void
    {
        add_filter('profile_menu', static function (array $items, array $user = []): array {
            if (self::canOperate($user)) {
                $items[] = [
                    'key' => self::SLUG,
                    'label' => self::t('toy_rental_menu'),
                    'href' => base_href('/profile/toy-rental'),
                    'icon' => 'ci-ticket',
                    'order' => 35,
                ];
            }
            return $items;
        });

        add_filter('admin_menu', function (array $menu): array {
            $menu[] = [
                'group' => 'applications',
                'label' => self::t('toy_rental_menu'),
                'href' => base_href('/admin/toy-rental'),
                'icon' => 'ci-ticket',
                'plugin_menu' => true,
                'order' => 10,
            ];

            return $menu;
        });

        add_filter('fireball_scheduled_jobs', static function (array $jobs): array {
            $jobs['toy_rental_expiry'] = [
                'class' => self::class,
                'schedule' => '* * * * *',
                'plugin' => self::SLUG,
            ];
            return $jobs;
        });
        add_filter('admin_dashboard_widgets', [self::class, 'dashboardWidgets'], 10);
        add_filter('notification_feed_item', [self::class, 'localizeNotificationSource']);
    }

    public function handle(): array
    {
        return ['updated' => self::markOverdueRides()];
    }

    public static function dashboardWidgets(array $widgets, array $context = []): array
    {
        try {
            $stats = self::todayStats();
            $settings = self::settings();
            $widgets[] = [
                'plugin' => self::SLUG,
                'title' => self::t('toy_rental_dashboard_title'),
                'subtitle' => self::t('toy_rental_stats_subtitle'),
                'icon' => 'ci-ticket',
                'href' => base_href('/admin/toy-rental'),
                'metrics' => [
                    ['label' => self::t('toy_rental_stat_rides_today'), 'value' => (int)$stats['rides_total'], 'tone' => 'info'],
                    ['label' => self::t('toy_rental_stat_active'), 'value' => (int)$stats['active'] + (int)$stats['overdue'], 'tone' => (int)$stats['overdue'] > 0 ? 'warning' : 'success'],
                    ['label' => self::t('toy_rental_stat_revenue'), 'value' => number_format((float)$stats['revenue_total'], 0, '.', ' ') . ' ' . (string)$settings['currency'], 'tone' => 'success'],
                ],
            ];
        } catch (Throwable $exception) {
            log_error_details('Toy rental dashboard widget failed', [], $exception);
        }

        return $widgets;
    }

    public static function defaultSettings(): array
    {
        return [
            'default_duration' => 10,
            'fixed_durations' => [5, 10, 15, 30],
            'max_ride_minutes' => 120,
            'default_minute_price' => 50,
            'currency' => '₽',
            'sound_enabled' => true,
            'overdue_push_enabled' => true,
            'creator_notifications_enabled' => true,
            'auto_refresh_seconds' => 0,
            'operator_role_id' => 0,
        ];
    }

    public static function settings(): array
    {
        $settings = [];
        foreach (self::defaultSettings() as $key => $default) {
            $settings[$key] = plugin_setting(self::SLUG, $key, $default);
        }

        $settings['fixed_durations'] = self::fixedDurations($settings['fixed_durations']);
        $settings['default_duration'] = max(1, min(1440, (int)$settings['default_duration']));
        if (plugin_setting(self::SLUG, 'fixed_durations', null) === null) {
            $settings['fixed_durations'] = self::fixedDurations(array_merge($settings['fixed_durations'], [$settings['default_duration']]));
        }
        if (!in_array($settings['default_duration'], $settings['fixed_durations'], true)) {
            $settings['default_duration'] = $settings['fixed_durations'][0];
        }
        $settings['default_minute_price'] = self::money($settings['default_minute_price']);
        $settings['max_ride_minutes'] = max(1, min(1440, (int)$settings['max_ride_minutes']));
        if (plugin_setting(self::SLUG, 'max_ride_minutes', null) === null) {
            $settings['max_ride_minutes'] = max($settings['max_ride_minutes'], max($settings['fixed_durations']));
        }
        $settings['currency'] = trim((string)$settings['currency']) ?: '₽';
        $settings['sound_enabled'] = (bool)$settings['sound_enabled'];
        $settings['overdue_push_enabled'] = (bool)$settings['overdue_push_enabled'];
        $settings['creator_notifications_enabled'] = (bool)$settings['creator_notifications_enabled'];
        $settings['auto_refresh_seconds'] = max(0, (int)$settings['auto_refresh_seconds']);
        $settings['operator_role_id'] = max(0, (int)$settings['operator_role_id']);

        return $settings;
    }

    public static function saveSettings(array $data): void
    {
        $roleId = filter_var($data['operator_role_id'] ?? 0, FILTER_VALIDATE_INT);
        if ($roleId === false || $roleId < 0 || ($roleId > 0 && !self::operatorRole($roleId))) {
            throw new RuntimeException(self::t('toy_rental_error_operator_role'));
        }
        $durations = self::fixedDurations($data['fixed_durations'] ?? [5, 10, 15, 30], true);
        $defaultDuration = max(1, min(1440, (int)($data['default_duration'] ?? 10)));
        if (!in_array($defaultDuration, $durations, true)) {
            throw new RuntimeException(self::t('toy_rental_error_default_duration'));
        }
        $maxMinutes = max(1, min(1440, (int)($data['max_ride_minutes'] ?? 120)));
        if (max($durations) > $maxMinutes) {
            throw new RuntimeException(self::t('toy_rental_error_ride_limit'));
        }
        $settings = [
            'default_duration' => $defaultDuration,
            'fixed_durations' => $durations,
            'max_ride_minutes' => $maxMinutes,
            'default_minute_price' => self::money($data['default_minute_price'] ?? 0),
            'currency' => mb_substr(trim((string)($data['currency'] ?? '₽')), 0, 12),
            'sound_enabled' => !empty($data['sound_enabled']),
            'overdue_push_enabled' => !empty($data['overdue_push_enabled']),
            'creator_notifications_enabled' => !empty($data['creator_notifications_enabled']),
            'auto_refresh_seconds' => max(0, min(3600, (int)($data['auto_refresh_seconds'] ?? 0))),
            'operator_role_id' => $roleId,
        ];

        if ($settings['currency'] === '') {
            $settings['currency'] = '₽';
        }

        foreach ($settings as $key => $value) {
            plugin_setting_set(self::SLUG, $key, $value);
        }
    }

    public static function operatorRoles(): array
    {
        return db()->query("SELECT id, name, slug FROM user_roles WHERE slug NOT IN ('creator', 'admin') ORDER BY name ASC, id ASC")->get() ?: [];
    }

    public static function operatorRoleLabel(array $role): string
    {
        return match ((string)($role['slug'] ?? '')) {
            'moderator' => self::t('toy_rental_role_moderator'),
            'user' => self::t('toy_rental_role_user'),
            default => (string)($role['name'] ?? ''),
        };
    }

    public static function operatorRole(?int $id = null): ?array
    {
        $id ??= max(0, (int)plugin_setting(self::SLUG, 'operator_role_id', 0));
        if ($id <= 0) return null;
        $role = db()->query("SELECT id, name, slug FROM user_roles WHERE id = ? AND slug NOT IN ('creator', 'admin') LIMIT 1", [$id])->getOne();
        return is_array($role) ? $role : null;
    }

    public static function canOperate(?array $user = null): bool
    {
        $user ??= get_user() ?: [];
        if ((int)($user['id'] ?? 0) <= 0) return false;
        if (in_array((string)($user['role'] ?? ''), ['creator', 'admin'], true)) return true;
        $role = self::operatorRole();
        return $role !== null && (string)($user['role'] ?? '') === (string)$role['slug'];
    }

    public static function requireOperator(): void
    {
        if (!self::canOperate()) {
            if (request()->isAjax()) response()->json(['status' => false, 'message' => self::t('toy_rental_error_operator_access')], 403);
            abort(self::t('toy_rental_error_operator_access'), 403);
        }
    }

    public static function operatorBasePath(): string
    {
        $path = '/' . ltrim((string)uri_without_lang(), '/');
        return $path === '/profile/toy-rental' || str_starts_with($path, '/profile/toy-rental/')
            ? '/profile/toy-rental' : '/admin/toy-rental';
    }

    public static function operatorViewData(array $data = []): array
    {
        $assetPath = __DIR__ . '/assets';
        $assetBase = base_href('/profile/toy-rental/assets/');
        return array_merge([
            'title' => self::t('toy_rental_dashboard_title'),
            'rentalSettings' => self::settings(),
            'operatorProfile' => true,
            'styles' => [$assetBase . 'toy-rental.css?v=' . filemtime($assetPath . '/toy-rental.css')],
            'footer_scripts' => [$assetBase . 'toy-rental.js?v=' . filemtime($assetPath . '/toy-rental.js')],
        ], $data);
    }

    public static function fixedDurations(mixed $value, bool $strict = false): array
    {
        $items = is_array($value) ? $value : preg_split('/[\s,;]+/u', trim((string)$value), -1, PREG_SPLIT_NO_EMPTY);
        $durations = [];
        foreach ($items ?: [] as $item) {
            $minute = filter_var($item, FILTER_VALIDATE_INT);
            if ($minute === false || $minute < 1 || $minute > 1440) {
                if ($strict) {
                    throw new RuntimeException(self::t('toy_rental_error_fixed_durations'));
                }
                continue;
            }
            $durations[] = $minute;
        }
        $durations = array_values(array_unique($durations));
        sort($durations);
        if (!$durations && $strict) {
            throw new RuntimeException(self::t('toy_rental_error_fixed_durations'));
        }
        return $durations ?: [5, 10, 15, 30];
    }

    public static function minutePrice(array $car, ?array $settings = null): float
    {
        $price = self::money($car['price_per_minute'] ?? 0);
        return $price > 0 ? $price : self::money(($settings ?? self::settings())['default_minute_price']);
    }

    public static function operatorState(): array
    {
        $settings = self::settings();
        $cards = [];
        foreach (self::carsForOperator() as $car) {
            $cards[] = [
                'car_id' => (int)$car['id'],
                'ride_id' => (int)($car['active_ride']['id'] ?? 0),
                'status' => (string)($car['active_ride']['status'] ?? $car['status']),
                'html' => plugin_view(self::SLUG, 'car-card', ['car' => $car, 'settings' => $settings], false),
            ];
        }
        $state = ['status' => true, 'cards' => $cards, 'max_ride_minutes' => $settings['max_ride_minutes']];
        if (check_admin()) $state['stats'] = self::todayStats();
        return $state;
    }

    public static function tabs(string $active): array
    {
        $items = [
            'dashboard' => [self::t('toy_rental_tab_dashboard'), '/admin/toy-rental', 'ci-layout'],
            'cars' => [self::t('toy_rental_tab_cars'), '/admin/toy-rental/cars', 'ci-settings'],
            'active' => [self::t('toy_rental_tab_active'), '/admin/toy-rental/active', 'ci-activity'],
            'history' => [self::t('toy_rental_tab_history'), '/admin/toy-rental/rides', 'ci-calendar'],
            'stats' => [self::t('toy_rental_tab_stats'), '/admin/toy-rental/stats', 'ci-bar-chart'],
            'settings' => [self::t('toy_rental_tab_settings'), '/admin/toy-rental/settings', 'ci-settings'],
        ];

        foreach ($items as $key => $item) {
            $items[$key] = [
                'key' => $key,
                'label' => $item[0],
                'href' => base_href($item[1]),
                'icon' => $item[2],
                'active' => $key === $active,
            ];
        }

        return array_values($items);
    }

    public static function viewData(string $active, array $data = []): array
    {
        $assetBase = base_href('/admin/toy-rental/assets/');
        $assetPath = __DIR__ . '/assets';
        $cssVersion = is_file($assetPath . '/toy-rental.css') ? (string)filemtime($assetPath . '/toy-rental.css') : (string)time();
        $jsVersion = is_file($assetPath . '/toy-rental.js') ? (string)filemtime($assetPath . '/toy-rental.js') : (string)time();

        return array_merge([
            'tabs' => self::tabs($active),
            'settings' => self::settings(),
            'styles' => [$assetBase . 'toy-rental.css?v=' . $cssVersion],
            'footer_scripts' => [$assetBase . 'toy-rental.js?v=' . $jsVersion],
        ], $data);
    }

    public static function cars(bool $includeHidden = false, bool $includeDeleted = false): array
    {
        $conditions = [];
        if (!$includeDeleted) {
            $conditions[] = 'deleted_at IS NULL';
        }
        if (!$includeHidden) {
            $conditions[] = "status <> 'hidden'";
        }
        $where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

        return db()->query(
            "SELECT * FROM toy_rental_cars {$where} ORDER BY sort_order ASC, id ASC"
        )->get() ?: [];
    }

    public static function carsForOperator(): array
    {
        self::markOverdueRides();
        $cars = self::cars();
        $rides = self::activeRidesByCar();

        foreach ($cars as &$car) {
            $car['active_ride'] = $rides[(int)$car['id']] ?? null;
        }
        unset($car);

        return $cars;
    }

    public static function car(int $id): ?array
    {
        $row = db()->query('SELECT * FROM toy_rental_cars WHERE id = ? AND deleted_at IS NULL LIMIT 1', [$id])->getOne();

        return is_array($row) ? $row : null;
    }

    public static function saveCar(array $data, ?int $id = null): int
    {
        $now = date('Y-m-d H:i:s');
        $normalized = [
            'name' => trim((string)($data['name'] ?? '')),
            'number' => trim((string)($data['number'] ?? '')),
            'color' => trim((string)($data['color'] ?? '')),
            'status' => self::carStatus((string)($data['status'] ?? 'available')),
            'price_per_minute' => self::money($data['price_per_minute'] ?? 0),
            'sort_order' => max(0, (int)($data['sort_order'] ?? 0)),
        ];

        if ($normalized['name'] === '' || $normalized['number'] === '') {
            throw new RuntimeException(self::t('toy_rental_error_car_required'));
        }

        if ($id !== null) {
            if (!self::car($id)) {
                throw new RuntimeException(self::t('toy_rental_error_car_not_found'));
            }
            db()->query(
                'UPDATE toy_rental_cars
                 SET name = ?, number = ?, color = ?, status = ?, price_per_minute = ?, sort_order = ?, updated_at = ?
                 WHERE id = ? AND deleted_at IS NULL',
                [
                    $normalized['name'],
                    $normalized['number'],
                    $normalized['color'],
                    $normalized['status'],
                    $normalized['price_per_minute'],
                    $normalized['sort_order'],
                    $now,
                    $id,
                ]
            );

            return $id;
        }

        db()->query(
            'INSERT INTO toy_rental_cars (name, number, color, status, price_per_minute, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $normalized['name'],
                $normalized['number'],
                $normalized['color'],
                $normalized['status'],
                $normalized['price_per_minute'],
                $normalized['sort_order'],
                $now,
                $now,
            ]
        );

        return (int)db()->getInsertId();
    }

    public static function hideCar(int $id): void
    {
        $car = self::car($id);
        if (!$car) {
            throw new RuntimeException(self::t('toy_rental_error_car_not_found'));
        }
        if ((string)$car['status'] === 'rented') {
            throw new RuntimeException(self::t('toy_rental_error_hide_rented_car'));
        }

        db()->query(
            "UPDATE toy_rental_cars SET status = 'hidden', updated_at = ? WHERE id = ?",
            [date('Y-m-d H:i:s'), $id]
        );
    }

    public static function deleteCar(int $id): void
    {
        db()->beginTransaction();
        try {
            // Starting a ride locks the same car first, so deletion cannot race a start.
            $car = db()->query('SELECT * FROM toy_rental_cars WHERE id = ? AND deleted_at IS NULL FOR UPDATE', [$id])->getOne();
            if (!$car) {
                throw new RuntimeException(self::t('toy_rental_error_car_not_found'));
            }
            $activeRide = db()->query("SELECT id FROM toy_rental_rides WHERE car_id = ? AND status IN ('active', 'overdue') LIMIT 1 FOR UPDATE", [$id])->getOne();
            if ($car['status'] === 'rented' || $activeRide) {
                throw new RuntimeException(self::t('toy_rental_error_delete_rented_car'));
            }
            $now = date('Y-m-d H:i:s');
            db()->query(
                "UPDATE toy_rental_cars SET deleted_at = ?, status = 'hidden', updated_at = ? WHERE id = ? AND deleted_at IS NULL",
                [$now, $now, $id]
            );
            db()->commit();
        } catch (Throwable $exception) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            throw $exception;
        }
    }

    public static function activeRides(): array
    {
        self::markOverdueRides();

        return db()->query(
            "SELECT r.*, c.name AS car_name, c.number AS car_number, c.color AS car_color
             FROM toy_rental_rides r
             INNER JOIN toy_rental_cars c ON c.id = r.car_id
             WHERE r.status IN ('active', 'overdue')
             ORDER BY CASE WHEN r.billing_type = 'fixed' THEN r.planned_end_at ELSE r.started_at END ASC"
        )->get() ?: [];
    }

    public static function activeRidesByCar(): array
    {
        $items = [];
        foreach (self::activeRides() as $ride) {
            $items[(int)$ride['car_id']] = $ride;
        }

        return $items;
    }

    public static function startRide(array $data): void
    {

        $carId = (int)($data['car_id'] ?? 0);
        $car = self::car($carId);
        if (!$car || (string)$car['status'] !== 'available') {
            throw new RuntimeException(self::t('toy_rental_error_car_unavailable'));
        }

        $settings = self::settings();
        $billingType = self::billingType((string)($data['billing_type'] ?? 'fixed'));
        $now = time();
        $startedAt = date('Y-m-d H:i:s', $now);
        $duration = max(1, min(1440, (int)($data['duration_minutes'] ?? $settings['default_duration'])));
        if ($billingType === 'fixed' && !in_array($duration, $settings['fixed_durations'], true)) {
            throw new RuntimeException(self::t('toy_rental_error_fixed_durations'));
        }
        if ($billingType === 'fixed' && $duration > $settings['max_ride_minutes']) {
            throw new RuntimeException(self::t('toy_rental_error_ride_limit'));
        }
        $estimatedMinutes = isset($data['estimated_minutes']) && (string)$data['estimated_minutes'] !== ''
            ? max(1, min(1440, (int)$data['estimated_minutes']))
            : null;
        $pricePerMinute = self::money($data['price_per_minute'] ?? self::minutePrice($car, $settings));

        if ($billingType === 'metered') {
            $plannedMinutes = $estimatedMinutes ?: (int)$settings['default_duration'];
            $plannedEndAt = date('Y-m-d H:i:s', $now + $plannedMinutes * 60);
            $amount = 0.0;
            $finalAmount = null;
            $paymentMethod = self::paymentMethod((string)($data['payment_method'] ?? 'cash'));
            $paymentStatus = self::paymentStatus((string)($data['payment_status'] ?? 'unpaid'));
            if ($paymentStatus === 'paid') {
                $paymentStatus = 'unpaid';
            }
        } else {
            $estimatedMinutes = $duration;
            $plannedEndAt = date('Y-m-d H:i:s', $now + $duration * 60);
            $amount = self::money($duration * $pricePerMinute);
            $finalAmount = $amount;
            $paymentMethod = self::paymentMethod((string)($data['payment_method'] ?? 'cash'));
            $paymentStatus = self::paymentStatus((string)($data['payment_status'] ?? 'paid'));
        }

        db()->beginTransaction();
        try {
            $lockedCar = db()->query('SELECT * FROM toy_rental_cars WHERE id = ? FOR UPDATE', [$carId])->getOne();
            $activeRide = db()->query("SELECT id FROM toy_rental_rides WHERE car_id = ? AND status IN ('active', 'overdue') LIMIT 1 FOR UPDATE", [$carId])->getOne();
            if (!$lockedCar || !empty($lockedCar['deleted_at']) || $lockedCar['status'] !== 'available' || $activeRide) {
                throw new RuntimeException(self::t('toy_rental_error_car_unavailable'));
            }
            db()->query(
                "INSERT INTO toy_rental_rides
                    (car_id, billing_type, price_per_minute, estimated_minutes, customer_name, customer_phone, started_at, planned_end_at, payment_amount, final_amount, payment_method, payment_status, status, notes, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?)",
                [
                    $carId,
                    $billingType,
                    $pricePerMinute,
                    $estimatedMinutes,
                    trim((string)($data['customer_name'] ?? '')),
                    trim((string)($data['customer_phone'] ?? '')),
                    $startedAt,
                    $plannedEndAt,
                    $amount,
                    $finalAmount,
                    $paymentMethod,
                    $paymentStatus,
                    trim((string)($data['notes'] ?? '')),
                    $startedAt,
                    $startedAt,
                ]
            );
            db()->query(
                "UPDATE toy_rental_cars SET status = 'rented', updated_at = ? WHERE id = ?",
                [$startedAt, $carId]
            );
            db()->commit();
        } catch (Throwable $exception) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            throw $exception;
        }
    }

    public static function completeRide(int $rideId, array $data = [], ?int $endedAtOverride = null): bool
    {

        $ride = db()->query(
            "SELECT * FROM toy_rental_rides WHERE id = ? AND status IN ('active', 'overdue') LIMIT 1",
            [$rideId]
        )->getOne();
        if (!$ride) {
            if ($endedAtOverride !== null) {
                return false;
            }
            throw new RuntimeException(self::t('toy_rental_error_ride_not_found'));
        }

        db()->beginTransaction();
        try {
            db()->query('SELECT id FROM toy_rental_cars WHERE id = ? FOR UPDATE', [(int)$ride['car_id']])->getOne();
            $ride = db()->query("SELECT * FROM toy_rental_rides WHERE id = ? AND status IN ('active', 'overdue') LIMIT 1 FOR UPDATE", [$rideId])->getOne();
            if (!$ride) {
                db()->commit();
                return false;
            }
            $endedAt = min(time(), $endedAtOverride ?? time());
            $startedAt = strtotime((string)$ride['started_at']) ?: $endedAt;
            $endedAt = max($startedAt, min($endedAt, $startedAt + self::settings()['max_ride_minutes'] * 60));
            $duration = max(1, (int)ceil(($endedAt - $startedAt) / 60));
            $billingType = self::billingType((string)($ride['billing_type'] ?? 'fixed'));
            $pricePerMinute = self::money($ride['price_per_minute'] ?? 0);
            $calculatedAmount = $billingType === 'metered'
                ? self::money($duration * $pricePerMinute)
                : self::money($ride['payment_amount']);
            $amount = array_key_exists('final_amount', $data)
                ? self::money($data['final_amount'])
                : (array_key_exists('payment_amount', $data) ? self::money($data['payment_amount']) : $calculatedAmount);
            // Keep a historical payment method when completion does not change it.
            $method = array_key_exists('payment_method', $data)
                ? self::paymentMethod((string)$data['payment_method'])
                : (string)$ride['payment_method'];
            $paymentStatus = self::paymentStatus((string)($data['payment_status'] ?? $ride['payment_status']));

            db()->query(
                "UPDATE toy_rental_rides
                 SET ended_at = ?, duration_minutes = ?, payment_amount = ?, final_amount = ?, payment_method = ?, payment_status = ?, status = 'completed', updated_at = ?
                 WHERE id = ?",
                [date('Y-m-d H:i:s', $endedAt), $duration, $amount, $calculatedAmount, $method, $paymentStatus, date('Y-m-d H:i:s', $endedAt), $rideId]
            );
            db()->query(
                "UPDATE toy_rental_cars SET status = 'available', updated_at = ? WHERE id = ?",
                [date('Y-m-d H:i:s', $endedAt), (int)$ride['car_id']]
            );
            db()->commit();
            return true;
        } catch (Throwable $exception) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            throw $exception;
        }
    }

    public static function markRidePaid(int $rideId, array $data = []): void
    {

        $ride = db()->query(
            "SELECT * FROM toy_rental_rides WHERE id = ? AND status = 'completed' AND payment_status = 'unpaid' LIMIT 1",
            [$rideId]
        )->getOne();
        if (!$ride) {
            $paid = db()->query("SELECT id FROM toy_rental_rides WHERE id = ? AND status = 'completed' AND payment_status = 'paid' LIMIT 1", [$rideId])->getOne();
            if ($paid) return;
            throw new RuntimeException(self::t('toy_rental_error_ride_payment_not_found'));
        }

        $method = self::paymentMethod((string)($data['payment_method'] ?? $ride['payment_method']));
        $amount = array_key_exists('payment_amount', $data)
            ? self::money($data['payment_amount'])
            : self::money($ride['payment_amount'] ?? 0);
        if ($amount <= 0) {
            $amount = self::money($ride['final_amount'] ?? 0);
        }

        db()->query(
            "UPDATE toy_rental_rides
             SET payment_amount = ?, payment_method = ?, payment_status = 'paid', updated_at = ?
             WHERE id = ? AND status = 'completed' AND payment_status = 'unpaid'",
            [$amount, $method, date('Y-m-d H:i:s'), $rideId]
        );
    }

    public static function history(array $filters = []): array
    {

        $where = [];
        $params = [];
        $dateFilter = (string)($filters['date_filter'] ?? 'today');

        if ($dateFilter === 'today') {
            $where[] = 'r.started_at >= ? AND r.started_at < ?';
            $params[] = date('Y-m-d 00:00:00');
            $params[] = date('Y-m-d 00:00:00', strtotime('+1 day'));
        } elseif ($dateFilter === 'yesterday') {
            $where[] = 'r.started_at >= ? AND r.started_at < ?';
            $params[] = date('Y-m-d 00:00:00', strtotime('-1 day'));
            $params[] = date('Y-m-d 00:00:00');
        } elseif ($dateFilter === 'period') {
            $from = trim((string)($filters['date_from'] ?? ''));
            $to = trim((string)($filters['date_to'] ?? ''));
            if ($from !== '') {
                $where[] = 'r.started_at >= ?';
                $params[] = $from . ' 00:00:00';
            }
            if ($to !== '') {
                $where[] = 'r.started_at <= ?';
                $params[] = $to . ' 23:59:59';
            }
        }

        foreach (['payment_method', 'payment_status'] as $field) {
            if (!empty($filters[$field])) {
                $where[] = 'r.' . $field . ' = ?';
                $params[] = (string)$filters[$field];
            }
        }

        if (!empty($filters['billing_type'])) {
            $where[] = 'r.billing_type = ?';
            $params[] = self::billingType((string)$filters['billing_type']);
        }

        if (!empty($filters['ride_status']) && in_array((string)$filters['ride_status'], ['active', 'completed', 'cancelled', 'overdue'], true)) {
            $where[] = 'r.status = ?';
            $params[] = (string)$filters['ride_status'];
        }

        if (!empty($filters['car_id'])) {
            $where[] = 'r.car_id = ?';
            $params[] = (int)$filters['car_id'];
        }

        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        return db()->query(
            "SELECT r.*, c.name AS car_name, c.number AS car_number
             FROM toy_rental_rides r
             INNER JOIN toy_rental_cars c ON c.id = r.car_id
             {$whereSql}
             ORDER BY r.started_at DESC
             LIMIT 300",
            $params
        )->get() ?: [];
    }

    public static function todayStats(): array
    {
        self::markOverdueRides();
        $start = date('Y-m-d 00:00:00');
        $end = date('Y-m-d 00:00:00', strtotime('+1 day'));
        $rows = db()->query(
            "SELECT r.*, c.name AS car_name, c.number AS car_number
             FROM toy_rental_rides r
             INNER JOIN toy_rental_cars c ON c.id = r.car_id
             WHERE r.started_at >= ? AND r.started_at < ?",
            [$start, $end]
        )->get() ?: [];

        $stats = [
            'rides_total' => count($rows),
            'fixed' => 0,
            'metered' => 0,
            'active' => 0,
            'completed' => 0,
            'overdue' => 0,
            'paid' => 0,
            'unpaid' => 0,
            'revenue_total' => 0.0,
            'revenue_cash' => 0.0,
            'revenue_transfer' => 0.0,
            'avg_duration' => 0,
            'popular_car' => '—',
        ];
        $durations = [];
        $cars = [];

        foreach ($rows as $row) {
            $status = (string)$row['status'];
            if (isset($stats[$status])) {
                $stats[$status]++;
            }
            $billingType = self::billingType((string)($row['billing_type'] ?? 'fixed'));
            $stats[$billingType]++;
            $paymentStatus = self::paymentStatus((string)($row['payment_status'] ?? 'unpaid'));
            if (isset($stats[$paymentStatus])) {
                $stats[$paymentStatus]++;
            }
            if ((string)$row['payment_status'] === 'paid') {
                $amount = self::money($row['payment_amount'] ?? 0);
                $stats['revenue_total'] += $amount;
                if ((string)$row['payment_method'] === 'cash') {
                    $stats['revenue_cash'] += $amount;
                }
                if ((string)$row['payment_method'] === 'transfer') {
                    $stats['revenue_transfer'] += $amount;
                }
            }
            if (!empty($row['duration_minutes'])) {
                $durations[] = (int)$row['duration_minutes'];
            }
            $carKey = (string)$row['car_id'];
            $cars[$carKey]['count'] = ($cars[$carKey]['count'] ?? 0) + 1;
            $cars[$carKey]['label'] = trim((string)$row['car_name'] . ' #' . (string)$row['car_number']);
        }

        if ($durations) {
            $stats['avg_duration'] = (int)round(array_sum($durations) / count($durations));
        }
        if ($cars) {
            uasort($cars, static fn(array $a, array $b): int => $b['count'] <=> $a['count']);
            $stats['popular_car'] = (string)reset($cars)['label'];
        }

        return $stats;
    }

    public static function markOverdueRides(): int
    {
        $updated = self::expireLongRides();
        $now = date('Y-m-d H:i:s');
        $newlyOverdue = db()->query(
            "SELECT r.id, r.car_id, r.planned_end_at, c.name AS car_name, c.number AS car_number
             FROM toy_rental_rides r
             INNER JOIN toy_rental_cars c ON c.id = r.car_id
             WHERE r.status = 'active' AND r.billing_type = 'fixed' AND r.planned_end_at <= ?",
            [$now]
        )->get() ?: [];

        foreach ($newlyOverdue as $ride) {
            db()->query(
                "UPDATE toy_rental_rides SET status = 'overdue', updated_at = ? WHERE id = ? AND status = 'active'",
                [$now, (int)$ride['id']]
            );
            if (db()->rowCount() > 0) {
                $updated++;
                self::notifyOperatorsAboutOverdueRide($ride);
            }
        }
        return $updated;
    }

    public static function expireLongRides(bool $notify = true): int
    {
        $limit = self::settings()['max_ride_minutes'];
        $rows = db()->query(
            "SELECT r.*, c.name AS car_name, c.number AS car_number FROM toy_rental_rides r
             INNER JOIN toy_rental_cars c ON c.id = r.car_id
             WHERE r.status IN ('active', 'overdue') AND r.started_at <= ?",
            [date('Y-m-d H:i:s', time() - $limit * 60)]
        )->get() ?: [];
        $updated = 0;
        foreach ($rows as $ride) {
            $end = (strtotime((string)$ride['started_at']) ?: time()) + $limit * 60;
            if (self::completeRide((int)$ride['id'], [], $end)) {
                $updated++;
                if ($notify) {
                    self::notifyOperatorsAboutOverdueRide($ride, true);
                }
            }
        }
        return $updated;
    }

    private static function closeOpenRides(): void
    {
        if (!self::tableExists('toy_rental_rides')) {
            return;
        }
        foreach (db()->query("SELECT id FROM toy_rental_rides WHERE status IN ('active', 'overdue')")->get() ?: [] as $ride) {
            self::completeRide((int)$ride['id'], [], time());
        }
    }

    protected static function notifyOperatorsAboutOverdueRide(array $ride, bool $limitReached = false): void
    {
        try {
            $carLabel = trim((string)($ride['car_name'] ?? '') . ' №' . (string)($ride['car_number'] ?? ''));

            $role = self::operatorRole();
            $settings = self::settings();
            $conditions = $role ? ['role = ?'] : [];
            if ($settings['creator_notifications_enabled']) $conditions[] = "role = 'creator'";
            if (!$conditions) return;
            $operators = db()->query('SELECT id, locale FROM users WHERE ' . implode(' OR ', $conditions) . ' ORDER BY id ASC', $role ? [$role['slug']] : [])->get() ?: [];
            $byLocale = [];
            foreach ($operators as $operator) {
                $locale = \FBL\Localization::normalizeLocale((string)($operator['locale'] ?? '')) ?: \FBL\Localization::siteLocale();
                $byLocale[$locale][] = (int)$operator['id'];
            }
            foreach ($byLocale as $locale => $userIds) {
                \App\Services\NotificationService::createForUsers($userIds, [
                    'title' => self::t($limitReached ? 'toy_rental_notification_limit_title' : 'toy_rental_notification_overdue_title', [], $locale),
                    'message' => self::t($limitReached ? 'toy_rental_notification_limit_text' : 'toy_rental_time_up_message', ['car' => $carLabel], $locale),
                    'type' => 'toy_rental',
                    'action_url' => '/profile/toy-rental',
                    'source' => self::SLUG,
                    'priority' => 'high',
                    'metadata' => [
                        'ride_id' => (int)($ride['id'] ?? 0),
                        'car_id' => (int)($ride['car_id'] ?? 0),
                        'event' => $limitReached ? 'limit_reached' : 'time_up',
                        'car_label' => $carLabel,
                    ],
                    'store_unread' => true,
                    'push_notification' => (bool)$settings['overdue_push_enabled'],
                ]);
            }
        } catch (Throwable $exception) {
            log_error_details('Toy rental overdue notification dispatch failed', [
                'ride_id' => (int)($ride['id'] ?? 0),
            ], $exception);
        }
    }

    public static function localizeNotificationSource(array $item, array $row): array
    {
        if ((string)($row['source'] ?? $item['source'] ?? '') === self::SLUG) {
            $item['source_label'] = self::t('toy_rental_notification_source');
            $item['url'] = base_href('/profile/toy-rental');
            $metadata = $row['metadata'] ?? [];
            if (is_string($metadata)) $metadata = json_decode($metadata, true);
            if (is_array($metadata) && in_array($metadata['event'] ?? '', ['time_up', 'limit_reached'], true) && isset($metadata['car_label'])) {
                $limitReached = $metadata['event'] === 'limit_reached';
                $item['title'] = self::t($limitReached ? 'toy_rental_notification_limit_title' : 'toy_rental_notification_overdue_title');
                $item['text'] = self::t($limitReached ? 'toy_rental_notification_limit_text' : 'toy_rental_time_up_message', ['car' => (string)$metadata['car_label']]);
            }
        }
        return $item;
    }

    public static function notificationFeedItems(array $items, int $userId, bool $isAdmin, int $limit): array
    {
        if (!$isAdmin) {
            return $items;
        }

        try {
            self::markOverdueRides();
            $limit = max(1, min(10, $limit));
            $rows = db()->query(
                "SELECT r.id, r.planned_end_at, c.name AS car_name, c.number AS car_number
                 FROM toy_rental_rides r
                 INNER JOIN toy_rental_cars c ON c.id = r.car_id
                 WHERE r.status = 'overdue' AND r.billing_type = 'fixed'
                 ORDER BY r.planned_end_at ASC, r.id ASC
                 LIMIT {$limit}"
            )->get() ?: [];
        } catch (Throwable $exception) {
            log_error_details('Toy rental notification feed failed', [
                'user_id' => $userId,
            ], $exception);

            return $items;
        }

        foreach ($rows as $row) {
            $plannedAt = strtotime((string)($row['planned_end_at'] ?? '')) ?: time();
            $minutesOverdue = max(1, (int)floor((time() - $plannedAt) / 60));
            $carLabel = trim((string)($row['car_name'] ?? '') . ' №' . (string)($row['car_number'] ?? ''));

            $items[] = [
                'type' => 'toy_rental',
                'source_label' => self::t('toy_rental_notification_source'),
                'title' => self::t('toy_rental_notification_overdue_title'),
                'text' => self::t('toy_rental_notification_overdue_text', [
                    'car' => $carLabel,
                    'minutes' => $minutesOverdue,
                ]),
                'url' => base_href('/admin/toy-rental'),
                'created_at' => (string)($row['planned_end_at'] ?? date('Y-m-d H:i:s')),
                'time' => date('H:i', $plannedAt),
                'sort_id' => (int)($row['id'] ?? 0),
            ];
        }

        return $items;
    }

    public static function statusLabel(string $status): string
    {
        return [
            'available' => self::t('toy_rental_status_available'),
            'rented' => self::t('toy_rental_status_rented'),
            'maintenance' => self::t('toy_rental_status_maintenance'),
            'hidden' => self::t('toy_rental_status_hidden'),
            'active' => self::t('toy_rental_status_active'),
            'completed' => self::t('toy_rental_status_completed'),
            'cancelled' => self::t('toy_rental_status_cancelled'),
            'overdue' => self::t('toy_rental_status_overdue'),
        ][$status] ?? $status;
    }

    public static function billingTypeLabel(string $type): string
    {
        return [
            'fixed' => self::t('toy_rental_billing_fixed'),
            'metered' => self::t('toy_rental_billing_metered'),
        ][self::billingType($type)] ?? $type;
    }

    public static function paymentMethodLabel(string $method): string
    {
        return [
            'cash' => self::t('toy_rental_payment_method_cash'),
            'card' => self::t('toy_rental_payment_method_card'),
            'transfer' => self::t('toy_rental_payment_method_transfer'),
            'other' => self::t('toy_rental_payment_method_other'),
        ][$method] ?? $method;
    }

    public static function paymentStatusLabel(string $status): string
    {
        return [
            'unpaid' => self::t('toy_rental_payment_status_unpaid'),
            'paid' => self::t('toy_rental_payment_status_paid'),
            'refunded' => self::t('toy_rental_payment_status_refunded'),
        ][self::paymentStatus($status)] ?? $status;
    }

    public static function t(string $key, array $replace = [], ?string $locale = null): string
    {
        $value = $locale === null ? \FBL\Language::get($key) : $key;
        if ($value === $key) {
            $translations = self::translations($locale);
            $value = (string)($translations[$key] ?? $key);
        }

        foreach ($replace as $name => $replacement) {
            $value = str_replace(':' . $name, (string)$replacement, $value);
        }

        return $value;
    }

    protected static function translations(?string $code = null): array
    {
        static $cache = [];

        $code ??= \FBL\Localization::currentLocale();
        $cacheKey = $code !== '' ? $code : 'fallback';
        if (array_key_exists($cacheKey, $cache)) {
            return $cache[$cacheKey];
        }

        $translations = [];
        $candidates = array_reverse(\FBL\Localization::localeCandidates($code, ['ru', 'en']));
        foreach ($candidates as $candidate) {
            $file = __DIR__ . '/lang/' . basename($candidate) . '.php';
            if (!is_file($file)) {
                continue;
            }

            try {
                $data = require $file;
                if (is_array($data)) {
                    $translations = array_merge($translations, $data);
                }
            } catch (Throwable $exception) {
                log_error_details('Toy rental language file failed', ['file' => $file], $exception);
            }
        }

        return $cache[$cacheKey] = $translations;
    }

    public static function cssColorStyle(string $color): string
    {
        $color = trim($color);
        if ($color === '') {
            return '';
        }

        $cssColorNames = [
            'aliceblue', 'antiquewhite', 'aqua', 'aquamarine', 'azure', 'beige', 'bisque', 'black',
            'blue', 'brown', 'coral', 'cyan', 'gold', 'gray', 'green', 'lime', 'magenta', 'orange',
            'pink', 'purple', 'red', 'silver', 'violet', 'white', 'yellow',
        ];

        if (preg_match('/^#[0-9a-f]{3,8}$/i', $color) === 1
            || preg_match('/^(rgb|rgba|hsl|hsla)\([0-9\s.,%+-]+\)$/i', $color) === 1
            || in_array(strtolower($color), $cssColorNames, true)
        ) {
            return 'background-color: ' . htmlSC($color);
        }

        return '';
    }

    public static function money(mixed $value): float
    {
        return max(0, round((float)str_replace(',', '.', (string)$value), 2));
    }

    private static function carStatus(string $status): string
    {
        return in_array($status, ['available', 'rented', 'maintenance', 'hidden'], true) ? $status : 'available';
    }

    private static function paymentMethod(string $method): string
    {
        if (!in_array($method, self::PAYMENT_METHODS, true)) {
            throw new RuntimeException(self::t('toy_rental_error_payment_method'));
        }
        return $method;
    }

    private static function paymentStatus(string $status): string
    {
        return in_array($status, ['unpaid', 'paid', 'refunded'], true) ? $status : 'paid';
    }

    private static function billingType(string $type): string
    {
        if ($type === 'per_minute') {
            return 'metered';
        }

        return in_array($type, ['fixed', 'metered'], true) ? $type : 'fixed';
    }

    private static function ensureDatabaseSchema(): void
    {
        $runner = new SqlFileRunner();
        foreach ([
            'toy_rental_cars' => '001_create_toy_rental_cars_table.sql',
            'toy_rental_rides' => '002_create_toy_rental_rides_table.sql',
        ] as $table => $migration) {
            if (self::tableExists($table)) {
                continue;
            }
            $file = __DIR__ . '/migrations/' . $migration;
            $sql = is_file($file) ? (string)file_get_contents($file) : '';
            if (trim($sql) === '') {
                throw new RuntimeException('Toy rental schema migration is missing: ' . $migration);
            }
            $runner->executeDatabase($sql);
        }

    }

    private static function tableExists(string $table): bool
    {
        return (int)db()->query(
            'SELECT COUNT(*) FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?',
            [$table]
        )->getColumn() === 1;
    }

    private static function ensureCarSchema(): void
    {
        foreach (db()->query('SHOW COLUMNS FROM toy_rental_cars')->get() ?: [] as $column) {
            if ($column['Field'] === 'deleted_at') {
                return;
            }
        }
        db()->query('ALTER TABLE toy_rental_cars ADD COLUMN deleted_at DATETIME NULL AFTER updated_at');
    }

    private static function ensureRideSchema(): void
    {
        static $ensured = false;
        if ($ensured) {
            return;
        }

        $columns = [];
        try {
            foreach (db()->query('SHOW COLUMNS FROM toy_rental_rides')->get() ?: [] as $column) {
                $columns[(string)$column['Field']] = true;
            }
        } catch (Throwable) {
            return;
        }

        $definitions = [
            'billing_type' => "ALTER TABLE toy_rental_rides ADD COLUMN billing_type ENUM('fixed', 'metered') NOT NULL DEFAULT 'fixed' AFTER car_id",
            'price_per_minute' => 'ALTER TABLE toy_rental_rides ADD COLUMN price_per_minute DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER billing_type',
            'estimated_minutes' => 'ALTER TABLE toy_rental_rides ADD COLUMN estimated_minutes INT(10) UNSIGNED NULL AFTER price_per_minute',
            'final_amount' => 'ALTER TABLE toy_rental_rides ADD COLUMN final_amount DECIMAL(10,2) NULL AFTER payment_amount',
        ];

        foreach ($definitions as $column => $sql) {
            if (isset($columns[$column])) {
                continue;
            }
            try {
                db()->query($sql);
            } catch (Throwable $exception) {
                log_error_details('Toy rental schema migration failed', ['column' => $column], $exception);
            }
        }

        try {
            db()->query(
                "UPDATE toy_rental_rides
                 SET billing_type = 'fixed', final_amount = payment_amount
                 WHERE billing_type = 'fixed' AND final_amount IS NULL"
            );
        } catch (Throwable $exception) {
            log_error_details('Toy rental schema backfill failed', [], $exception);
        }

        $ensured = true;
    }
}
