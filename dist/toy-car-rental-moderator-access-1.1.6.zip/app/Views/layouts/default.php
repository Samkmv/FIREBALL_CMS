<?php

$requiredAssets = \App\Services\FrontendAssets::requirements((string)$this->content, (array)($assets ?? []));
extract((new \App\Services\PublicLayoutContext())->navigation(), EXTR_SKIP);
$defaultAsset = static fn(string $path): string => asset_versioned_url(base_url($path), WWW . $path);
$currentPostCategorySlug = trim((string)request()->get('category', ''));
$siteTitle = site_setting('site_title', SITE_NAME);
$siteDescription = site_setting('site_description', '');
$socialLinks = site_social_links();
$seoHomeTitle = site_setting('seo_home_title', '');
$seoDefaultTitleSuffix = site_setting('seo_default_title_suffix', '');
$seoMetaDescription = site_setting('seo_meta_description', '');
$seoMetaKeywords = site_setting('seo_meta_keywords', '');
$seoMetaAuthor = site_setting('seo_meta_author', '');
$seoRobots = site_setting('seo_robots', 'index,follow');
$seoOgImage = site_setting('seo_og_image', '');
$seoTwitterCard = site_setting('seo_twitter_card', 'summary_large_image');
$pageTitle = trim((string)($title ?? ''));
$pageSeoTitle = trim((string)($seo_title ?? ''));
$pageSeoDescription = trim((string)($seo_description ?? ''));
$pageSeoKeywords = trim((string)($seo_keywords ?? ''));
$pageSeoImage = trim((string)($seo_image ?? ''));
$pageSeoImageWidth = max(0, (int)($seo_image_width ?? 0));
$pageSeoImageHeight = max(0, (int)($seo_image_height ?? 0));
$pageSeoImageAlt = trim((string)($seo_image_alt ?? ''));
$pageSeoType = trim((string)($seo_type ?? 'website'));
$pageSeoArticlePublishedTime = trim((string)($seo_article_published_time ?? ''));
$pageSeoArticleSection = trim((string)($seo_article_section ?? ''));
$pageSeoRobots = trim((string)($seo_robots ?? ''));
$pageSeoCanonical = trim((string)($seo_canonical ?? ''));
$isHomePage = uri_without_lang() === '';
$homePageTitle = $pageTitle !== '' ? $pageTitle : return_translation('home_index_title');
$homeTitleBase = ($seoHomeTitle !== '' && $seoHomeTitle !== $siteTitle)
    ? $seoHomeTitle
    : ($homePageTitle !== 'home_index_title' ? $homePageTitle : $siteTitle);
$resolvedTitleBase = $pageSeoTitle !== ''
    ? $pageSeoTitle
    : ($isHomePage ? $homeTitleBase : ($pageTitle !== '' ? $pageTitle : $siteTitle));
$resolvedTitleSuffix = $seoDefaultTitleSuffix !== '' ? $seoDefaultTitleSuffix : $siteTitle;
$documentTitle = $resolvedTitleBase !== $resolvedTitleSuffix
    ? $resolvedTitleBase . ' - ' . $resolvedTitleSuffix
    : $resolvedTitleBase;
$metaDescription = $pageSeoDescription !== ''
    ? $pageSeoDescription
    : ($seoMetaDescription !== '' ? $seoMetaDescription : ($siteDescription !== '' ? $siteDescription : $siteTitle));
$metaKeywords = $pageSeoKeywords !== '' ? $pageSeoKeywords : $seoMetaKeywords;
$metaAuthor = $seoMetaAuthor !== '' ? $seoMetaAuthor : $siteTitle;
$metaRobots = $pageSeoRobots !== '' ? $pageSeoRobots : $seoRobots;
$canonicalUrl = $pageSeoCanonical !== '' ? $pageSeoCanonical : base_href(uri_without_lang());
$languageSwitchPath = uri_without_lang();
$homeCanonicalUrls = array_unique(array_map(
    static fn(string $url): string => rtrim($url, '/'),
    [base_href('/'), base_url('/')]
));
if ($languageSwitchPath === '' || ($canonicalUrl !== '' && in_array(rtrim($canonicalUrl, '/'), $homeCanonicalUrls, true))) {
    $languageSwitchPath = '/';
}
$languageSwitchHref = static function (string $key, array $language) use ($languageSwitchPath): string {
    return locale_switch_url($key, $languageSwitchPath);
};
$metaImageData = social_image_metadata(
    $pageSeoImage !== '' ? $pageSeoImage : $seoOgImage,
    $pageSeoImageWidth,
    $pageSeoImageHeight
);
$metaImage = (string)$metaImageData['url'];
$metaImageAlt = $pageSeoImageAlt !== '' ? $pageSeoImageAlt : $resolvedTitleBase;
$metaType = $pageSeoType !== '' ? $pageSeoType : 'website';
$currentLangCode = current_locale();
$ogLocale = match ($currentLangCode) {
    'en' => 'en_US',
    'de' => 'de_DE',
    'zh-cn' => 'zh_CN',
    default => 'ru_RU',
};
$currentUser = check_auth() ? get_user() : null;
if ($currentUser) {
    \FBL\Auth::touchPresence();
}
$isAdmin = check_admin();
$adminAreaPath = '/' . ltrim((string)uri_without_lang(), '/');
$adminAreaPath = rtrim($adminAreaPath, '/') ?: '/';
$isAdminArea = $adminAreaPath === '/admin' || str_starts_with($adminAreaPath, '/admin/');
$hasMobileSidebarToggle = str_contains((string)$this->content, 'data-bs-target="#adminSidebar"')
    || str_contains((string)$this->content, 'data-bs-target="#blogSidebar"')
    || str_contains((string)$this->content, 'data-bs-target="#accountSidebar"');
$canViewVideoStatus = can_view_video_diagnostics();
$forceHlsJsOnApple = site_setting('player_apple_force_hlsjs', '0') === '1';
$streamConfig = stream_config();
$frontendStreamConfig = [
    'readyTimeoutMs' => (int)$streamConfig['ready_timeout_seconds'] * 1000,
    'readyIntervalMs' => (int)$streamConfig['ready_interval_ms'],
    'httpTimeoutMs' => (int)$streamConfig['http_timeout_seconds'] * 1000,
];
$currentUserAvatar = get_user_avatar($currentUser['avatar'] ?? null, 'sm');
$currentUserHasActiveSubscription = !$isAdminArea && (new \App\Services\PublicLayoutContext())->hasActiveSubscription((int)($currentUser['id'] ?? 0));
$logoutAction = base_href('/logout');
$pwaHeadData = pwa_head_data();
$footerDescription = $siteDescription !== ''
    ? $siteDescription
    : return_translation('footer_description_fallback');
$footerNavigationLinks = [
    [
        'href' => base_href('/'),
        'label' => return_translation('tpl_menu_nav_index'),
    ],
    [
        'href' => base_href('/posts'),
        'label' => return_translation('footer_nav_posts'),
    ],
    [
        'href' => base_href('/contacts'),
        'label' => return_translation('tpl_menu_nav_contacts'),
    ],
];
$footerNavigationLinks = array_merge($footerNavigationLinks, $footerPageLinks);
if (site_setting('support_public_enabled', '1') === '1') {
    $footerNavigationLinks[] = [
        'href' => base_href('/support'),
        'label' => return_translation('tpl_menu_nav_support'),
    ];
}
$footerCategoryLinks = $postNavigationCategories;
$postCategoryUrl = static function (?string $slug = null): string {
    $url = base_href('/posts');
    if ($slug === null || $slug === '') {
        return $url;
    }

    return $url . '?category=' . rawurlencode($slug);
};
?>
<!DOCTYPE html><html lang="<?= htmlSC(current_locale()) ?>" data-bs-theme="light" data-pwa="true" data-video-status="<?= $canViewVideoStatus ? '1' : '0' ?>"><head>
    <meta charset="utf-8">
    <script>
        (function () {
            var standalone = window.matchMedia('(display-mode: standalone)').matches
                || window.navigator.standalone === true;
            ['pwa', 'standalone', 'pwa-standalone'].forEach(function (className) {
                document.documentElement.classList.toggle(className, standalone);
            });
        })();
    </script>

    <?= get_csrf_meta() ?>

    <!-- Viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

    <!-- SEO Meta Tags -->
    <title><?= htmlSC($documentTitle) ?></title>
    <meta name="description" content="<?= htmlSC($metaDescription) ?>">
    <?php if ($metaKeywords !== ''): ?>
        <meta name="keywords" content="<?= htmlSC($metaKeywords) ?>">
    <?php endif; ?>
    <meta name="author" content="<?= htmlSC($metaAuthor) ?>">
    <meta name="robots" content="<?= htmlSC($metaRobots) ?>">
    <link rel="canonical" href="<?= htmlSC($canonicalUrl) ?>">
    <meta property="og:locale" content="<?= htmlSC($ogLocale) ?>">
    <meta property="og:type" content="<?= htmlSC($metaType) ?>">
    <meta property="og:site_name" content="<?= htmlSC($siteTitle) ?>">
    <meta property="og:title" content="<?= htmlSC($documentTitle) ?>">
    <meta property="og:description" content="<?= htmlSC($metaDescription) ?>">
    <meta property="og:url" content="<?= htmlSC($canonicalUrl) ?>">
    <?php if ($metaImage !== ''): ?>
        <meta property="og:image" content="<?= htmlSC($metaImage) ?>">
        <meta property="og:image:url" content="<?= htmlSC($metaImage) ?>">
        <?php if ($metaImageData['secure_url'] !== ''): ?>
            <meta property="og:image:secure_url" content="<?= htmlSC((string)$metaImageData['secure_url']) ?>">
        <?php endif; ?>
        <?php if ($metaImageData['type'] !== ''): ?>
            <meta property="og:image:type" content="<?= htmlSC((string)$metaImageData['type']) ?>">
        <?php endif; ?>
        <?php if ($metaImageData['width'] > 0 && $metaImageData['height'] > 0): ?>
            <meta property="og:image:width" content="<?= (int)$metaImageData['width'] ?>">
            <meta property="og:image:height" content="<?= (int)$metaImageData['height'] ?>">
        <?php endif; ?>
        <meta property="og:image:alt" content="<?= htmlSC($metaImageAlt) ?>">
    <?php endif; ?>
    <?php if ($metaType === 'article' && $pageSeoArticlePublishedTime !== ''): ?>
        <meta property="article:published_time" content="<?= htmlSC($pageSeoArticlePublishedTime) ?>">
    <?php endif; ?>
    <?php if ($metaType === 'article' && $pageSeoArticleSection !== ''): ?>
        <meta property="article:section" content="<?= htmlSC($pageSeoArticleSection) ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="<?= htmlSC($seoTwitterCard !== '' ? $seoTwitterCard : 'summary_large_image') ?>">
    <meta name="twitter:title" content="<?= htmlSC($documentTitle) ?>">
    <meta name="twitter:description" content="<?= htmlSC($metaDescription) ?>">
    <?php if ($metaImage !== ''): ?>
        <meta name="twitter:image" content="<?= htmlSC($metaImage) ?>">
        <meta name="twitter:image:alt" content="<?= htmlSC($metaImageAlt) ?>">
    <?php endif; ?>

    <!-- Webmanifest + Favicon / App icons -->
    <?= pwa_head_tags() ?>

    <!-- Theme switcher (color modes) -->
    <script src="<?= $defaultAsset('/assets/default/js/theme-switcher.js') ?>"></script>
    <?php if ($isAdminArea): ?>
        <script>
            (() => {
                try {
                    document.documentElement.dataset.fbSidebarCollapsed =
                        window.localStorage.getItem('fireball.admin.sidebar.collapsed') === '1' ? 'true' : 'false';
                } catch (error) {
                    document.documentElement.dataset.fbSidebarCollapsed = 'false';
                }
                document.documentElement.dataset.fbAdminHydrated = 'false';
            })();
        </script>
    <?php endif; ?>

    <!-- Font icons -->
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/icons/cartzilla-icons.min.css') ?>">

    <!-- Vendor styles -->
<?php if ($isAdminArea || !empty($requiredAssets['choices'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/choices.js/choices.min.css') ?>">
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['simplebar'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/simplebar/simplebar.min.css') ?>">
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['swiper'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/swiper/swiper-bundle.min.css') ?>">
<?php endif; ?>
<?php if (!empty($requiredAssets['glightbox'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/glightbox/glightbox.min.css') ?>">
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/plyr/plyr.css') ?>">
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/fireplayer.css') ?>">
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['highlight'])): ?>
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/highlight.js/styles/atom-one-dark.min.css') ?>">
<?php endif; ?>

    <?php if (!empty($styles)): ?>
        <?php foreach ($styles as $style): ?>

            <link rel="stylesheet" href="<?= $style; ?>">

        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Bootstrap + Theme styles -->
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/theme.min.css') ?>" id="theme-styles">

    <?php if (isset($is_settings)): ?>
        <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/profile.css') ?>">
    <?php endif; ?>

    <!-- Customs styles -->
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/vendor/toastr/toastr.min.css') ?>">
    <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/style.css') ?>">
    <?php if (!empty($requiredAssets['favorites'])): ?>
        <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/favorites.css') ?>">
    <?php endif; ?>
    <?php if (!$isAdminArea): ?>
        <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/back-to-top.css') ?>">
    <?php endif; ?>
    <?php if ($isAdminArea): ?>
        <link rel="stylesheet" href="<?= $defaultAsset('/assets/default/css/admin-ui.css') ?>">
    <?php endif; ?>
    <?php if (!$canViewVideoStatus): ?>
        <style id="fb-video-status-privacy">
            .fb-plyr-hls-message--info,
            .fb-plyr-hls-message--success,
            .fb-plyr-hls-message--warning,
            .fb-plyr-hls-message:not(.fb-plyr-hls-message--error) {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
            }
        </style>
    <?php endif; ?>

    <!-- Header scripts -->
    <?php if (!empty($header_scripts)): ?>
        <?php foreach ($header_scripts as $header_script): ?>

            <script src="<?= $header_script; ?>"></script>

        <?php endforeach; ?>
    <?php endif; ?>

</head>


<!-- Body -->
<body
    class="<?= $isAdminArea ? 'fb-admin-body' : '' ?>"
    data-admin-area="<?= $isAdminArea ? '1' : '0' ?>"
    data-toast-success-title="<?= htmlSC(return_translation('toast_success_title')) ?>"
    data-toast-error-title="<?= htmlSC(return_translation('toast_error_title')) ?>"
    data-toast-info-title="<?= htmlSC(return_translation('toast_info_title')) ?>"
    data-toast-warning-title="<?= htmlSC(return_translation('toast_warning_title')) ?>"
    data-toast-close-label="<?= htmlSC(return_translation('notification_close')) ?>"
    data-code-copy-label="<?= htmlSC(return_translation('code_copy_button')) ?>"
    data-code-copied-label="<?= htmlSC(return_translation('code_copied_button')) ?>"
    data-admin-table-error-title="<?= htmlSC(return_translation('admin_table_error_title')) ?>"
    data-admin-table-error-text="<?= htmlSC(return_translation('admin_table_error_text')) ?>"
    data-admin-table-retry-label="<?= htmlSC(return_translation('admin_table_retry')) ?>"
    data-pwa-enabled="<?= !empty($pwaHeadData['enabled']) ? '1' : '0' ?>"
    data-pwa-push-enabled="<?= !empty($pwaHeadData['push_enabled']) ? '1' : '0' ?>"
    data-pwa-auth-user-id="<?= (int)($currentUser['id'] ?? 0) ?>"
    data-pwa-vapid-public-key="<?= htmlSC((string)($pwaHeadData['vapid_public_key'] ?? '')) ?>"
    data-pwa-service-worker-url="<?= htmlSC((string)($pwaHeadData['service_worker_url'] ?? base_url('/service-worker.js'))) ?>"
    data-pwa-subscribe-url="<?= htmlSC(base_url('/api/pwa/subscriptions')) ?>"
    data-pwa-unsubscribe-url="<?= htmlSC(base_url('/api/pwa/subscriptions/delete')) ?>"
    data-pwa-status-url="<?= htmlSC(base_url('/api/pwa/status')) ?>"
    data-pwa-badge-clear-url="<?= htmlSC(base_url('/api/pwa/badge/clear')) ?>"
    data-pwa-safari-hint="<?= htmlSC(return_translation('pwa_safari_install_hint')) ?>"
>

<?php if (!$isAdminArea): ?>
<nav class="offcanvas offcanvas-start" id="navbarNav" tabindex="-1" aria-labelledby="navbarNavLabel">
    <div class="offcanvas-header py-3">
        <h5 class="offcanvas-title" id="navbarNavLabel"><?= print_translation('tpl_menu_nav') ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body pt-0 pb-3">

        <!-- Navbar nav -->
        <div class="accordion" id="navigation">

            <!-- Categories collapse visible on screens < 992px wide (lg breakpoint) -->
            <div class="accordion-item border-0 d-lg-none">
                <div class="accordion-header" id="headingCategories">
                    <button type="button" class="accordion-button animate-underline fw-medium collapsed py-2" data-bs-toggle="collapse" data-bs-target="#categoriesMenu" aria-expanded="false" aria-controls="categoriesMenu">
                        <i class="ci-grid fs-lg me-2"></i>
                        <span class="d-block animate-target py-1"><?= print_translation('tpl_menu_btn_catalog') ?></span>
                    </button>
                </div>
                <div class="accordion-collapse collapse" id="categoriesMenu" aria-labelledby="headingCategories" data-bs-parent="#navigation">
                    <div class="accordion-body pb-3">
                        <div class="dropdown-menu show position-static d-flex flex-column gap-2 shadow-none p-4">
                            <a class="nav-link animate-underline d-inline-flex justify-content-between gap-3 p-0 <?= $currentPostCategorySlug === '' ? 'fw-semibold' : '' ?>" href="<?= $postCategoryUrl() ?>">
                                <span class="animate-target"><?= print_translation('tpl_menu_all_posts') ?></span>
                            </a>
                            <?php foreach ($postNavigationCategories as $category): ?>
                                <a class="nav-link animate-underline d-inline-flex justify-content-between gap-3 p-0 <?= $currentPostCategorySlug === $category['slug'] ? 'fw-semibold' : '' ?>" href="<?= $postCategoryUrl($category['slug']) ?>">
                                    <span class="animate-target"><?= htmlSC($category['label']) ?></span>
                                    <span class="text-body-tertiary fs-xs"><?= (int)$category['total'] ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main menu -->
        <?php echo view()->renderPartial('incs/main_menu_tpl', [
            'headerPageLinks' => $headerPageLinks,
        ]) ?>

    </div>

    <!-- Account button visible on screens < 768px wide (md breakpoint) -->
    <div class="offcanvas-header flex-column align-items-start d-md-none">
        <?php if (check_auth()): ?>
            <a class="btn btn-lg btn-outline-secondary w-100 rounded-pill mb-2 d-inline-flex align-items-center justify-content-center gap-2" href="<?= base_href('/profile') ?>">
                <img
                    src="<?= $currentUserAvatar ?>"
                    alt="<?= htmlSC($currentUser['name'] ?? '') ?>"
                    class="rounded-circle object-fit-cover ms-n1<?= !empty($currentUserHasActiveSubscription) ? ' nav-account-avatar--subscribed' : '' ?>"
                    style="width: 28px; height: 28px;"
                >
                <?= print_translation('tpl_auth_profile') ?>
            </a>
            <?php if (can_access_admin_panel()): ?>
                <a class="btn btn-lg btn-outline-secondary w-100 rounded-pill mb-2 d-inline-flex align-items-center justify-content-center gap-2" href="<?= base_href(admin_home_path()) ?>">
                    <i class="ci-layout fs-lg ms-n1"></i>
                    <?= print_translation('tpl_auth_admin') ?>
                </a>
            <?php endif; ?>
            <a class="btn btn-lg btn-outline-secondary w-100 rounded-pill mb-2 d-inline-flex align-items-center justify-content-center gap-2" href="<?= base_href('/chat') ?>">
                <i class="ci-chat fs-lg ms-n1"></i>
                <?= print_translation('tpl_auth_chat') ?>
            </a>
            <form action="<?= $logoutAction ?>" method="post" class="w-100">
                <?= get_csrf_field() ?>
                <button class="btn btn-lg btn-dark w-100 rounded-pill d-inline-flex align-items-center justify-content-center gap-2" type="submit">
                    <i class="ci-log-out fs-lg ms-n1"></i>
                    <?= print_translation('tpl_auth_logout') ?>
                </button>
            </form>
        <?php else: ?>
            <a class="btn btn-lg btn-outline-secondary w-100 rounded-pill mb-2 d-inline-flex align-items-center justify-content-center gap-2" href="<?= base_href('/login') ?>">
                <i class="ci-log-in fs-lg ms-n1"></i>
                <?= print_translation('tpl_auth_login') ?>
            </a>
            <a class="btn btn-lg btn-dark w-100 rounded-pill d-inline-flex align-items-center justify-content-center gap-2" href="<?= base_href('/register') ?>">
                <i class="ci-user-plus fs-lg ms-n1"></i>
                <?= print_translation('tpl_auth_register') ?>
            </a>
        <?php endif; ?>
    </div>
</nav>

<!-- Shopping cart offcanvas -->
<div class="offcanvas offcanvas-end pb-sm-2 px-sm-2" id="shoppingCart" tabindex="-1" aria-labelledby="shoppingCartLabel" style="width: 500px">

    <!-- Header -->
    <div class="offcanvas-header flex-column align-items-start py-3 pt-lg-4">
        <div class="d-flex align-items-center justify-content-between w-100 mb-3 mb-lg-4">
            <h4 class="offcanvas-title" id="shoppingCartLabel"><?= print_translation('tpl_menu_cart') ?></h4>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
    </div>

    <!-- Items -->
    <div class="offcanvas-body d-flex flex-column gap-4 pt-2">

        <?= view()->renderPartial('incs/mini-cart') ?>

    </div>

</div>

<header class="navbar public-navbar navbar-expand navbar-sticky sticky-top d-block bg-body z-fixed py-1 py-lg-0 py-xl-1 px-0" data-sticky-element="">
    <div class="container justify-content-start py-2 py-lg-3">

        <!-- Offcanvas menu toggler (Hamburger) -->
        <button type="button" class="navbar-toggler d-block flex-shrink-0 me-3 me-sm-4" data-bs-toggle="offcanvas" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar brand (Logo) -->
        <a class="navbar-brand site-brand fs-2 p-0 pe-lg-2 pe-xxl-0 me-0 me-sm-3 me-md-4 me-xxl-5" href="<?= base_href('/')?>">
            <span class="site-brand__title"><?= htmlSC($siteTitle) ?></span>
        </a>

        <!-- Categories dropdown visible on screens > 991px wide (lg breakpoint) -->
        <div class="dropdown public-navbar-categories d-none d-lg-block w-100 me-4" style="max-width: 200px">
            <button type="button" class="btn btn-lg btn-secondary w-100 border-0 rounded-pill" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ci-grid fs-lg me-2 ms-n1"></i>
                <?= print_translation('tpl_menu_btn_catalog') ?>
                <i class="ci-chevron-down fs-lg me-2 ms-auto me-n1"></i>
            </button>

            <div class="dropdown-menu rounded-4 p-4" style="--cz-dropdown-spacer: .75rem; min-width: 280px;">
                <div class="d-flex flex-column gap-2 public-navbar-category-list">
                    <a class="nav-link animate-underline d-flex justify-content-between gap-3 p-0 <?= $currentPostCategorySlug === '' ? 'fw-semibold' : '' ?>" href="<?= $postCategoryUrl() ?>">
                        <span class="animate-target"><?= print_translation('tpl_menu_all_posts') ?></span>
                    </a>
                    <?php foreach ($postNavigationCategories as $category): ?>
                        <a class="nav-link animate-underline d-flex justify-content-between gap-3 p-0 <?= $currentPostCategorySlug === $category['slug'] ? 'fw-semibold' : '' ?>" href="<?= $postCategoryUrl($category['slug']) ?>">
                            <span class="animate-target text-truncate"><?= htmlSC($category['label']) ?></span>
                            <span class="text-body-tertiary fs-xs"><?= (int)$category['total'] ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>

        <!-- Search bar visible on screens > 768px wide (md breakpoint) -->
        <form action="<?= base_href('/search') ?>" method="get" class="public-navbar-search position-relative w-100 d-none d-md-block me-3 me-xl-4" data-search-suggest data-suggest-url="<?= base_href('/search/suggest') ?>">
            <input
                type="search"
                name="q"
                value="<?= htmlSC((string)request()->get('q', '')) ?>"
                class="form-control form-control-lg rounded-pill"
                placeholder="<?= print_translation('tpl_menu_search') ?>"
                aria-label="<?= htmlSC(return_translation('tpl_menu_search')) ?>"
                autocomplete="off"
                data-search-suggest-input
            >
            <button type="submit" class="btn btn-icon btn-ghost fs-lg btn-secondary text-bo border-0 position-absolute top-0 end-0 rounded-circle mt-1 me-1" aria-label="<?= htmlSC(return_translation('tpl_menu_search')) ?>">
                <i class="ci-search"></i>
            </button>
            <div class="position-absolute top-100 start-0 end-0 mt-2 d-none z-3" data-search-suggest-results></div>
        </form>

        <!-- Button group -->
        <div class="public-navbar-actions d-flex align-items-center gap-md-1 gap-lg-2 ms-auto">

            <!-- Theme switcher (light/dark/auto) -->
            <div class="dropdown">
                <button type="button" class="theme-switcher btn btn-icon btn-outline-secondary fs-lg border-0 rounded-circle animate-scale" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Toggle theme (light)">
              <span class="theme-icon-active d-flex animate-target">
                <i class="ci-sun"></i>
              </span>
                </button>
                <ul class="dropdown-menu" style="--cz-dropdown-min-width: 9rem">
                    <li>
                        <button type="button" class="dropdown-item active" data-bs-theme-value="light" aria-pressed="true">
                  <span class="theme-icon d-flex fs-base me-2">
                    <i class="ci-sun"></i>
                  </span>
                            <span class="theme-label"><?= print_translation('tpl_menu_btn_switch_light') ?></span>
                            <i class="item-active-indicator ci-check ms-auto"></i>
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item" data-bs-theme-value="dark" aria-pressed="false">
                  <span class="theme-icon d-flex fs-base me-2">
                    <i class="ci-moon"></i>
                  </span>
                            <span class="theme-label"><?= print_translation('tpl_menu_btn_switch_dark') ?></span>
                            <i class="item-active-indicator ci-check ms-auto"></i>
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item" data-bs-theme-value="auto" aria-pressed="false">
                  <span class="theme-icon d-flex fs-base me-2">
                    <i class="ci-auto"></i>
                  </span>
                            <span class="theme-label"><?= print_translation('tpl_menu_btn_switch_auto') ?></span>
                            <i class="item-active-indicator ci-check ms-auto"></i>
                        </button>
                    </li>
                </ul>
            </div>

            <!-- Search toggle button visible on screens < 768px wide (md breakpoint) -->
            <button type="button" class="btn btn-icon fs-xl btn-outline-secondary border-0 rounded-circle animate-shake d-md-none" data-bs-toggle="collapse" data-bs-target="#searchBar" aria-controls="searchBar" aria-label="Toggle search bar">
                <i class="ci-search animate-target"></i>
            </button>

            <!-- Language switcher -->
            <?php if (MULTILANGS): ?>

                <div class="dropdown">
                    <button type="button" class="btn btn-icon btn-outline-secondary fs-lg border-0 rounded-circle animate-scale" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="d-flex animate-target">
                            <i class="ci-globe"></i>
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">

                <?php foreach (LANGS as $key => $val): ?>

                    <?php if (current_locale() == $key) continue; ?>

                    <li>
                        <a class="dropdown-item" href="<?= htmlSC($languageSwitchHref((string)$key, $val)); ?>"><?= htmlSC($val['title']); ?></a>
                    </li>

                <?php endforeach; ?>

                    </ul>
                </div>

            <?php endif; ?>

            <?php if (check_auth()): ?>
                <div
                    class="dropdown"
                    data-notifications-center
                    data-feed-url="<?= base_href('/notifications/feed') ?>"
                    data-read-url="<?= base_href('/notifications/read') ?>"
                    data-clear-url="<?= base_href('/notifications/clear') ?>"
                    data-clear-confirm="<?= htmlSC(return_translation('notification_clear_confirm')) ?>"
                    data-clear-success="<?= htmlSC(return_translation('notification_cleared')) ?>"
                    data-empty-text="<?= htmlSC(return_translation('notification_empty')) ?>"
                    data-chat-source-label="<?= htmlSC(return_translation('notification_source_chat')) ?>"
                    data-open-label="<?= htmlSC(return_translation('notification_open')) ?>"
                    data-mark-read-label="<?= htmlSC(return_translation('notification_mark_read')) ?>"
                    data-load-error="<?= htmlSC(return_translation('notification_load_error')) ?>"
                    data-retry-label="<?= htmlSC(return_translation('notification_retry')) ?>"
                >
                    <button
                        type="button"
                        class="btn btn-icon fs-xl btn-outline-secondary border-0 rounded-circle animate-scale position-relative"
                        data-bs-toggle="dropdown"
                        data-bs-auto-close="outside"
                        aria-controls="notification-feed-panel"
                        aria-expanded="false"
                        aria-label="<?= htmlSC(return_translation('tpl_notifications')) ?>"
                    >
                        <i class="ci-bell animate-target"></i>
                        <span
                            class="position-absolute top-0 start-100 badge fs-xs text-bg-danger rounded-pill ms-n3 z-2 d-none"
                            style="--cz-badge-padding-y: .25em; --cz-badge-padding-x: .42em"
                            data-notifications-badge
                        >0</span>
                    </button>
                    <div id="notification-feed-panel" class="dropdown-menu dropdown-menu-end p-0 notification-feed-panel">
                        <div class="notification-feed-header px-3 py-3 border-bottom bg-body d-flex align-items-center justify-content-between gap-3">
                            <strong id="notification-feed-title" class="d-block"><?= print_translation('tpl_notifications') ?></strong>
                            <button type="button" class="btn btn-sm btn-link text-decoration-none p-0 d-none" data-notifications-clear>
                                <i class="ci-trash me-1" aria-hidden="true"></i><?= print_translation('notification_clear_all') ?>
                            </button>
                        </div>
                        <div class="list-group list-group-flush notification-feed-list" data-notifications-list tabindex="0" role="region" aria-labelledby="notification-feed-title" aria-busy="true">
                            <div class="px-3 py-3 text-body-secondary small"><?= print_translation('notification_loading') ?></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Account button visible on screens > 768px wide (md breakpoint) -->
            <div class="dropdown d-none d-md-block">
                <button type="button" class="btn btn-icon fs-lg btn-outline-secondary border-0 rounded-circle animate-shake position-relative" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php if (check_auth()): ?>
                        <span class="d-block w-100 h-100 rounded-circle overflow-hidden<?= !empty($currentUserHasActiveSubscription) ? ' nav-account-avatar--subscribed' : '' ?>">
                            <img
                                src="<?= $currentUserAvatar ?>"
                                alt="<?= htmlSC($currentUser['name'] ?? '') ?>"
                                class="w-100 h-100 object-fit-cover rounded-circle"
                            >
                        </span>
                    <?php else: ?>
                        <i class="ci-user animate-target"></i>
                    <?php endif; ?>
                    <span class="visually-hidden"><?= print_translation('tpl_auth_account') ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <?php if (check_auth()): ?>
                        <li>
                            <div class="dropdown-header d-flex align-items-center gap-2">
                                <img
                                    src="<?= $currentUserAvatar ?>"
                                    alt="<?= htmlSC($currentUser['name'] ?? '') ?>"
                                    class="rounded-circle object-fit-cover border"
                                    style="width: 32px; height: 32px;"
                                >
                                <div><?= htmlSC($currentUser['name'] ?? '') ?><?= render_public_verified_badge($currentUser['role'] ?? null) ?></div>
                            </div>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2" href="<?= base_href('/profile') ?>">
                                <i class="ci-user fs-base"></i>
                                <span><?= print_translation('tpl_auth_profile') ?></span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2" href="<?= base_href('/chat') ?>">
                                <i class="ci-chat fs-base"></i>
                                <span><?= print_translation('tpl_auth_chat') ?></span>
                            </a>
                        </li>
                        <?php if (can_access_admin_panel()): ?>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2" href="<?= base_href(admin_home_path()) ?>">
                                    <i class="ci-layout fs-base"></i>
                                    <span><?= print_translation('tpl_auth_admin') ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <form action="<?= $logoutAction ?>" method="post">
                                <?= get_csrf_field() ?>
                                <button class="dropdown-item d-flex align-items-center gap-2 w-100" type="submit">
                                    <i class="ci-log-out fs-base"></i>
                                    <span><?= print_translation('tpl_auth_logout') ?></span>
                                </button>
                            </form>
                        </li>
                    <?php else: ?>
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2" href="<?= base_href('/login') ?>">
                                <i class="ci-log-in fs-base"></i>
                                <span><?= print_translation('tpl_auth_login') ?></span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2" href="<?= base_href('/register') ?>">
                                <i class="ci-user-plus fs-base"></i>
                                <span><?= print_translation('tpl_auth_register') ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Cart button -->
<!--            <button type="button" class="btn btn-icon fs-xl btn-outline-secondary position-relative border-0 rounded-circle animate-scale" data-bs-toggle="offcanvas" data-bs-target="#shoppingCart" aria-controls="shoppingCart" aria-label="Shopping cart">-->
<!--                <span id="countCart" class="position-absolute top-0 start-100 badge fs-xs text-bg-primary rounded-pill ms-n3 z-2" style="--cz-badge-padding-y: .25em; --cz-badge-padding-x: .42em">-->
<!--                    --><?php //= \App\Helpers\Cart\Cart::getCartQuantityTotal() ?>
<!--                </span>-->
<!--                <i class="ci-shopping-cart animate-target"></i>-->
<!--            </button>-->

        </div>
    </div>

    <!-- Search collapse available on screens < 768px wide (md breakpoint) -->
    <div class="collapse d-md-none" id="searchBar">
        <div class="container pt-2 pb-3">
            <form action="<?= base_href('/search') ?>" method="get" class="position-relative" data-search-suggest data-suggest-url="<?= base_href('/search/suggest') ?>">
                <button type="submit" class="search-submit btn btn-icon btn-ghost fs-lg border-0 position-absolute top-50 start-0 translate-middle-y rounded-circle ms-1" aria-label="<?= print_translation('tpl_menu_search') ?>">
                    <i class="ci-search" aria-hidden="true"></i>
                </button>
                <input
                    type="search"
                    name="q"
                    value="<?= htmlSC((string)request()->get('q', '')) ?>"
                    class="form-control form-icon-start rounded-pill"
                    placeholder="<?= print_translation('tpl_menu_search') ?>"
                    aria-label="<?= htmlSC(return_translation('tpl_menu_search')) ?>"
                    autocomplete="off"
                    data-search-suggest-input
                >
                <div class="position-absolute top-100 start-0 end-0 mt-2 d-none z-3" data-search-suggest-results></div>
            </form>
        </div>
    </div>
</header>
<?php endif; ?>

<!-- Вызов быстрых flash уведомлений -->
<?php if (!$isAdminArea) { get_alerts(); } ?>

<?= $this->content; ?>

<?php if (!$isAdminArea): ?>
<!-- Page footer -->
<footer class="footer position-relative bg-dark<?= $hasMobileSidebarToggle ? ' mobile-sidebar-layout-footer' : '' ?>">
    <span class="position-absolute top-0 start-0 w-100 h-100 bg-body d-none d-block-dark"></span>
    <div class="container position-relative z-1 pt-sm-2 pt-md-3 pt-lg-4" data-bs-theme="dark">
        <div class="accordion py-5" id="footerLinks">
            <div class="row gy-4 gy-lg-0">
                <div class="col-lg-4 pe-lg-5">
                    <a class="d-inline-flex align-items-center text-dark-emphasis text-decoration-none fs-3 fw-semibold mb-3" href="<?= base_href('/') ?>">
                        <?= htmlSC($siteTitle) ?>
                    </a>
                    <p class="text-body mb-0"><?= htmlSC($footerDescription) ?></p>
                    <?php if (!empty($socialLinks)): ?>
                        <div class="pt-4">
                            <div class="text-dark-emphasis small text-uppercase fw-semibold mb-3" style="letter-spacing: .08em;"><?= print_translation('footer_heading_social') ?></div>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach ($socialLinks as $link): ?>
                                    <a
                                        class="btn btn-icon btn-outline-secondary rounded-circle"
                                        href="<?= htmlSC((string)$link['href']) ?>"
                                        <?= !empty($link['external']) ? 'target="_blank" rel="noopener noreferrer"' : '' ?>
                                        aria-label="<?= htmlSC((string)$link['label']) ?>"
                                    >
                                        <i class="<?= htmlSC((string)$link['icon']) ?>"></i>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-8">
                    <div class="row row-cols-1 row-cols-sm-2 <?= !empty($legalInformationLinks) ? 'row-cols-lg-3' : 'row-cols-lg-2' ?> gx-3 gx-md-4">
                        <div class="accordion-item col border-0">
                            <h6 class="accordion-header" id="footerNavHeading">
                                <span class="text-dark-emphasis d-none d-sm-block"><?= print_translation('footer_heading_navigation') ?></span>
                                <button type="button" class="accordion-button py-3 d-sm-none collapsed" data-bs-toggle="collapse" data-bs-target="#footerNavLinks" aria-expanded="false" aria-controls="footerNavLinks"><?= print_translation('footer_heading_navigation') ?></button>
                            </h6>
                            <div class="accordion-collapse d-sm-block collapse" id="footerNavLinks" aria-labelledby="footerNavHeading" data-bs-parent="#footerLinks">
                                <ul class="nav flex-column gap-2 pt-sm-3 pb-3 mt-n1 mb-1">
                                    <?php foreach ($footerNavigationLinks as $link): ?>
                                        <li class="d-flex w-100 pt-1">
                                            <a class="nav-link footer-link animate-underline animate-target d-inline fw-normal p-0" href="<?= htmlSC($link['href']) ?>"><?= htmlSC($link['label']) ?></a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <hr class="d-sm-none my-0">
                        </div>
                        <div class="accordion-item col border-0">
                            <h6 class="accordion-header" id="footerCategoryHeading">
                                <span class="text-dark-emphasis d-none d-sm-block"><?= print_translation('footer_heading_categories') ?></span>
                                <button type="button" class="accordion-button py-3 d-sm-none collapsed" data-bs-toggle="collapse" data-bs-target="#footerCategoryLinks" aria-expanded="false" aria-controls="footerCategoryLinks"><?= print_translation('footer_heading_categories') ?></button>
                            </h6>
                            <div class="accordion-collapse d-sm-block collapse" id="footerCategoryLinks" aria-labelledby="footerCategoryHeading" data-bs-parent="#footerLinks">
                                <ul class="nav flex-column gap-2 pt-sm-3 pb-3 mt-n1 mb-1">
                                    <li class="d-flex w-100 pt-1">
                                        <a class="nav-link footer-link animate-underline animate-target d-inline fw-normal p-0" href="<?= $postCategoryUrl() ?>"><?= print_translation('tpl_menu_all_posts') ?></a>
                                    </li>
                                    <?php foreach ($footerCategoryLinks as $category): ?>
                                        <li class="d-flex w-100 pt-1">
                                            <a class="nav-link footer-link animate-underline animate-target d-inline fw-normal p-0" href="<?= $postCategoryUrl($category['slug']) ?>"><?= htmlSC($category['label']) ?></a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <hr class="d-sm-none my-0">
                        </div>
                        <?php if (!empty($legalInformationLinks)): ?>
                            <div class="accordion-item col border-0">
                                <h6 class="accordion-header" id="footerLegalHeading">
                                    <span class="text-dark-emphasis d-none d-sm-block"><?= print_translation('footer_heading_legal_information') ?></span>
                                    <button type="button" class="accordion-button py-3 d-sm-none collapsed" data-bs-toggle="collapse" data-bs-target="#footerLegalLinks" aria-expanded="false" aria-controls="footerLegalLinks"><?= print_translation('footer_heading_legal_information') ?></button>
                                </h6>
                                <div class="accordion-collapse d-sm-block collapse" id="footerLegalLinks" aria-labelledby="footerLegalHeading" data-bs-parent="#footerLinks">
                                    <ul class="nav flex-column gap-2 pt-sm-3 pb-3 mt-n1 mb-1">
                                        <?php foreach ($legalInformationLinks as $link): ?>
                                            <li class="d-flex w-100 pt-1">
                                                <a class="nav-link footer-link animate-underline animate-target d-inline fw-normal p-0" href="<?= htmlSC($link['href']) ?>"><?= htmlSC($link['label']) ?></a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <hr class="d-sm-none my-0">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 border-top py-4">
            <p class="text-body fs-sm text-center text-md-start mb-0">
                <?= str_replace(
                    [':year', ':site'],
                    [(string)date('Y'), $siteTitle],
                    return_translation('footer_copyright')
                ) ?>
            </p>
        </div>
    </div>
</footer>
<?php endif; ?>

<?php if ($isAdminArea): ?>
    <div class="modal fade" id="adminDeleteModal" tabindex="-1" aria-hidden="true" data-admin-delete-modal>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-5 overflow-hidden">
                <div class="modal-body p-4 p-md-5 text-center">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-danger-subtle text-danger mb-4" style="width: 72px; height: 72px;" data-admin-delete-modal-icon-wrap>
                        <i class="ci-trash fs-2" data-admin-delete-modal-icon></i>
                    </div>
                    <h2 class="h4 mb-2" data-admin-delete-modal-title><?= print_translation('admin_delete_modal_title') ?></h2>
                    <p class="text-body-secondary mb-3" data-admin-delete-modal-message><?= print_translation('admin_delete_modal_default_message') ?></p>
                    <div class="rounded-4 bg-body-tertiary px-3 py-3 mb-3 d-none" data-admin-delete-modal-item-wrap>
                        <div class="text-uppercase small fw-semibold text-body-tertiary mb-1" style="letter-spacing: .08em;" data-admin-delete-modal-item-label><?= print_translation('admin_delete_modal_item_label') ?></div>
                        <div class="fw-semibold text-break" data-admin-delete-modal-item></div>
                    </div>
                    <p class="small text-body-secondary mb-0" data-admin-delete-modal-hint><?= print_translation('admin_delete_modal_hint') ?></p>
                </div>
                <div class="modal-footer border-0 justify-content-center gap-2 px-4 pb-4 pt-0">
                    <button type="button" class="btn btn-outline-secondary rounded-pill d-inline-flex align-items-center gap-2" data-bs-dismiss="modal">
                        <i class="ci-close"></i><?= print_translation('admin_btn_cancel') ?>
                    </button>
                    <button type="button" class="btn btn-danger rounded-pill d-inline-flex align-items-center gap-2" data-admin-delete-modal-confirm>
                        <i class="ci-trash" data-admin-delete-modal-confirm-icon></i><span data-admin-delete-modal-confirm-label><?= print_translation('admin_btn_delete') ?></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (!$isAdminArea): ?>
<!-- Back to top button -->
<button type="button" class="public-back-to-top" data-back-to-top hidden tabindex="-1" aria-hidden="true"
        aria-label="<?= htmlSC(return_translation('tpl_back_to_top_label')) ?>" title="<?= htmlSC(return_translation('tpl_back_to_top_label')) ?>">
    <svg class="public-back-to-top__icon" viewBox="0 0 44 44" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true" focusable="false">
        <circle class="public-back-to-top__track" cx="22" cy="22" r="18" />
        <circle class="public-back-to-top__progress" cx="22" cy="22" r="18" pathLength="100" stroke-linecap="round" />
        <path class="public-back-to-top__arrow" d="M22 29V15m-6 6 6-6 6 6" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
    <span class="public-back-to-top__label"><?= htmlSC(return_translation('tpl_back_to_top')) ?></span>
</button>
<?php endif; ?>

<script>
    const baseUrl = '<?= base_url(); ?>';
    window.canViewVideoStatus = <?= $canViewVideoStatus ? 'true' : 'false'; ?>;
    window.canViewVideoDiagnostics = window.canViewVideoStatus;
    document.documentElement.dataset.videoStatus = window.canViewVideoStatus ? '1' : '0';
    window.hlsStreamConfig = <?= json_encode($frontendStreamConfig, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.firePlayerConfig = {
        assetBase: <?= json_encode(base_url('/assets/default'), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        hlsScriptUrl: <?= json_encode($defaultAsset('/assets/default/vendor/hls.js/hls.min.js'), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        forceHlsJsOnApple: <?= $forceHlsJsOnApple ? 'true' : 'false'; ?>
    };
    if (!window.canViewVideoStatus) {
        (function () {
            const diagnosticTextPattern = /Загрузка видео|Подключение|Повторное подключение|Loading video|Connecting|Reconnecting/i;
            const isDiagnosticMessage = function (node) {
                if (!(node instanceof Element)) {
                    return false;
                }

                return node.classList.contains('fb-plyr-hls-message--info')
                    || node.classList.contains('fb-plyr-hls-message--success')
                    || node.classList.contains('fb-plyr-hls-message--warning')
                    || diagnosticTextPattern.test(node.textContent || '');
            };
            const clearDiagnosticMessage = function (node) {
                if (!(node instanceof Element) || !isDiagnosticMessage(node)) {
                    return;
                }

                const playerRoot = node.closest('.plyr');
                const playerWrap = node.closest('[data-plyr-player-wrap]');

                [playerRoot, playerWrap].forEach(function (container) {
                    if (!container) {
                        return;
                    }

                    container.classList.remove('has-hls-status');
                    delete container.dataset.plyrHlsStatus;
                });

                node.className = 'fb-plyr-hls-message';
                node.onclick = null;
                node.onkeydown = null;
                node.removeAttribute('tabindex');
                if (node.parentNode) {
                    node.parentNode.removeChild(node);
                    return;
                }

                node.hidden = true;
                node.textContent = '';
            };
            const clearVideoDiagnostics = function () {
                document
                    .querySelectorAll('[data-plyr-hls-message], .fb-plyr-hls-message')
                    .forEach(clearDiagnosticMessage);
            };

            window.fbClearVideoDiagnostics = clearVideoDiagnostics;
            clearVideoDiagnostics();

            if (typeof MutationObserver === 'function') {
                new MutationObserver(clearVideoDiagnostics).observe(document.documentElement, {
                    subtree: true,
                    childList: true,
                    attributes: true,
                    attributeFilter: ['class', 'hidden'],
                    characterData: true
                });
            }
        })();
    }
</script>
<script src="<?= $defaultAsset('/assets/default/js/jquery-3.7.1.min.js') ?>"></script>

<!-- Vendor scripts -->
<?php if ($isAdminArea || !empty($requiredAssets['choices'])): ?>
<script src="<?= $defaultAsset('/assets/default/vendor/choices.js/choices.min.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['simplebar'])): ?>
<script src="<?= $defaultAsset('/assets/default/vendor/simplebar/simplebar.min.js') ?>"></script>
<?php endif; ?>
<script>
    if (window.Choices && !window.Choices.__fireballHardened) {
        const FireballChoicesBase = window.Choices;
        const FireballChoices = function (element, options) {
            const allowHtml = element && element.getAttribute && element.getAttribute('data-select-allow-html') === 'true';
            return new FireballChoicesBase(element, Object.assign({}, options || {}, {
                allowHTML: allowHtml
            }));
        };
        FireballChoices.prototype = FireballChoicesBase.prototype;
        Object.keys(FireballChoicesBase).forEach(function (key) {
            FireballChoices[key] = FireballChoicesBase[key];
        });
        FireballChoices.__fireballHardened = true;
        window.Choices = FireballChoices;
    }
</script>
<?php if ($isAdminArea || !empty($requiredAssets['swiper'])): ?>
<script src="<?= $defaultAsset('/assets/default/vendor/swiper/swiper-bundle.min.js') ?>"></script>
<?php endif; ?>
<?php if (!empty($requiredAssets['glightbox'])): ?>
<script src="<?= $defaultAsset('/assets/default/vendor/glightbox/glightbox.min.js') ?>"></script>
<?php endif; ?>
<script src="<?= $defaultAsset('/assets/default/vendor/toastr/toastr.min.js') ?>"></script>
<?php if ($isAdminArea || !empty($requiredAssets['player'])): ?>
<script src="<?= $defaultAsset('/assets/default/vendor/plyr/plyr.polyfilled.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['highlight'])): ?>
<script src="<?= $defaultAsset('/assets/default/vendor/highlight.js/highlight.min.js') ?>"></script>
<?php endif; ?>

<?php if (!empty($footer_scripts)): ?>
    <?php foreach ($footer_scripts as $footer_script): ?>

        <script src="<?= $footer_script; ?>"></script>

    <?php endforeach; ?>
<?php endif; ?>

<!-- Bootstrap + Theme scripts -->
<script src="<?= $defaultAsset('/assets/default/js/bootstrap-guard.js') ?>"></script>
<script src="<?= $defaultAsset('/assets/default/js/theme.min.js') ?>"></script>

<!-- Customs scripts -->
<script src="<?= $defaultAsset('/assets/default/js/password-field.js') ?>"></script>
<?php if ($isAdminArea || !empty($requiredAssets['choices'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/select-init.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player_video'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer-video.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player_audio'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer-audio.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player_hls'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer-hls.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player_live'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer-live.js') ?>"></script>
<?php endif; ?>
<?php if ($canViewVideoStatus && ($isAdminArea || !empty($requiredAssets['player']))): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer-diagnostics.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/fireplayer-init.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea || !empty($requiredAssets['player'])): ?>
<script src="<?= $defaultAsset('/assets/default/js/plyr-init.js') ?>"></script>
<?php endif; ?>
<script src="<?= $defaultAsset('/assets/default/js/pwa.js') ?>"></script>
<?php if ($isAdminArea): ?>
    <script src="<?= $defaultAsset('/assets/default/js/admin-delete-modal.js') ?>"></script>
    <script src="<?= $defaultAsset('/assets/default/js/datatable.js') ?>"></script>
<?php endif; ?>
<script src="<?= $defaultAsset('/assets/default/js/main.js') ?>"></script>
<?php if (!$isAdminArea): ?>
    <script src="<?= $defaultAsset('/assets/default/js/back-to-top.js') ?>"></script>
<?php endif; ?>
<?php if ($isAdminArea): ?>
    <script src="<?= $defaultAsset('/assets/default/js/admin-ui.js') ?>"></script>
<?php endif; ?>


</body></html>
