<?php

namespace FBL\Middleware;

/**
 * Проверяет полный или ограниченный доступ к административному маршруту.
 */
class Admin
{

    /**
     * Проверяет роль пользователя и перенаправляет его при отсутствии прав администратора.
     */
    public function handle(): void
    {
        $path = \FBL\AdminAccess::normalizePath(request()->getPath());
        if (!check_admin() && $path === '/admin' && request()->isGet()) {
            $home = \FBL\AdminAccess::homePath();
            if ($home !== null) {
                response()->redirect(base_href($home));
            }
        }
        if (\FBL\AdminAccess::allowsPath($path)) {
            return;
        }

        if (!check_admin()) {
            session()->setFlash('error', \FBL\Language::get('tpl_auth_required_admin'));
            response()->redirect(base_href('/profile'));
        }
    }

}
