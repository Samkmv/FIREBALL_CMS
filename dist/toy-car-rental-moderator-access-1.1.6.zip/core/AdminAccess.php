<?php

namespace FBL;

/** Limited admin access granted by active plugins, without administrator privileges. */
final class AdminAccess
{
    public static function homePath(): ?string
    {
        if (Auth::isAdmin()) {
            return '/admin';
        }

        return self::moderatorPaths()[0] ?? null;
    }

    public static function allowsPath(string $path): bool
    {
        if (Auth::isAdmin()) {
            return true;
        }

        $path = self::normalizePath($path);
        foreach (self::moderatorPaths() as $prefix) {
            if ($path === $prefix || str_starts_with($path, $prefix . '/')) {
                return true;
            }
        }

        return false;
    }

    private static function moderatorPaths(): array
    {
        if (!Auth::hasRole('moderator')) {
            return [];
        }

        $paths = apply_filters_safe('admin_moderator_paths', []);
        if (!is_array($paths)) {
            return [];
        }

        return array_values(array_unique(array_filter($paths, static fn($path): bool =>
            is_string($path) && (bool)preg_match('#^/admin/[a-z0-9_-]+(?:/[a-z0-9_-]+)*$#D', $path)
        )));
    }

    public static function normalizePath(string $path): string
    {
        $path = (string)(parse_url($path, PHP_URL_PATH) ?: '');
        if ($path === '' || str_contains($path, '\\') || str_contains($path, '%')
            || preg_match('#(?:^|/)\.{1,2}(?:/|$)#', $path)) {
            return '';
        }

        return '/' . Localization::pathWithoutLocale($path);
    }
}
